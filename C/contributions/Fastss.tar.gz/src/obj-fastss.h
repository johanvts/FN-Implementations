/*  
 *  FastSS - Fast Similarity Search for dictionaries
 *  Copyright (C) 2007 University of Zurich, Thomas Bocek, Fabio Hecht
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 * Authors: Thomas Bocek, Fabio Hecht
 * 
 * Fast Similarity Search (FastSS) performs an exhaustive similarity 
 * search in a dictionary, based on the edit distance model of string 
 * similarity.
 * 
 */

#ifndef OBJFASTSS_H_
#define OBJFASTSS_H_

//we need this function to access the loaded dictionary
char* getDB (int nr);

#endif /*OBJFASTSS_H_*/

