/*  
 *  FastSS - Fast Similarity Search for dictionaries
 *  Copyright (C) 2007 University of Zurich, Thomas Bocek, Fabio Hecht
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 * Authors: Thomas Bocek, Fabio Hecht
 * 
 * Fast Similarity Search (FastSS) performs an exhaustive similarity 
 * search in a dictionary, based on the edit distance model of string 
 * similarity.
 * 
 */

#ifndef FASTSS_H_
#define FASTSS_H_

#endif /*FASTSS_H_*/
#include "crc32.h"
#include "hashtable/hashtable.h"
#include "hashtable/hashtable_itr.c"
#include <stdlib.h>
#include "../../obj.h"
#include "../../index.h"
#include "../../basics.h"
#include "../../obj-fastss.h"

#define MAX_K 7

typedef struct fastssIndex_st fastssIndex;
struct fastssIndex_st
{
    //the hashtable stores the number of the word, which is retrieved using getDB (int nr). 
	//Therefore, we need to load the db for the search as well.
	char *dbname;
	int k;
    struct hashtable *h;
};


//typedef struct key_st key;
//struct key_st
//{
	//We might extend this in future...
//	char *key;
//};

typedef char * key;

typedef struct value_st value;
struct value_st
{
	//The wordkey points to the word, that is accessed by getDB (int nr)
	int wordkey;
	value * next_value;
	unsigned char delete_position_length;
	unsigned char delete_position[MAX_K];
};


typedef struct item_st item;
struct item_st
{
	item * next;
	char* precalc;
	unsigned char delete_position_length;
	unsigned char delete_position[MAX_K];
};

typedef struct hashtable hashtable;
typedef struct hashtable_itr hashtable_itr;
// functions

item * normalize(char* string, int k);
int distpos(byte * positons1, byte length1, byte * positons2, byte length2);
int * search_intern(Index S, Obj obj, Tdist r, bool show, 
		int limit, int * result, int * result_count, int * sum_dist);
void printHashtable(struct hashtable *S);
