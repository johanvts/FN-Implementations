/*  
 *  FastSS - Fast Similarity Search for dictionaries
 *  Copyright (C) 2007 University of Zurich, Thomas Bocek, Fabio Hecht
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/**
 * Authors: Thomas Bocek, Fabio Hecht
 * 
 * Fast Similarity Search (FastSS) performs an exhaustive similarity 
 * search in a dictionary, based on the edit distance model of string 
 * similarity.
 * 
 */

#include "fastss.h"
#include <malloc.h>

static void mem_info()
{
	struct	mallinfo mem;
	mem = mallinfo();
	printf("size %iMB, %iKB, %iB used\n", (mem.arena/1024/1024), (mem.arena/1024), (mem.arena));
}

static unsigned int hashfromkey(void *key)
{
	return crc32((char *)key);
}

static int equalkeys(void *ky1, void *ky2)
{
	char *k1 = (char *)ky1;
	char *k2 = (char *)ky2;
	return (0 == memcmp(ky1, ky2, strlen(k1)) && strcmp(k1, k2)==0);
}

DEFINE_HASHTABLE_INSERT(insert_some, key, value)
;
DEFINE_HASHTABLE_SEARCH(search_some, key, value)
;
DEFINE_HASHTABLE_REMOVE(remove_some, key, value)
;

void * ht_search_some(struct hashtable *h, char *k);
int ht_insert_some(struct hashtable *h, char *k, void *v);
void * ht_hashtable_iterator_key(struct hashtable_itr *itr);

//#define DEBUG_BUILD true;
//#define DEBUG_SEARCH true;
//#define DEBUG_INDEX true;

Index build(char *dbname, int n, int *argc, char ***argv)
{
	int ns, i, d, j, l=0;
	value *v, *found;
	hashtable *h;
	fastssIndex *index;
	item * list;

	if (*argc > 0)
	{
		d = atoi(argv[0][0]);
		//printf("indexing dictionary with edit distance %i\n", d);
		*argc=0;
	} else
	{
		fprintf(stderr,"Usage: %s db-name size idxfile edit-distance\n",argv[0]);
		exit(-1);
	}

#ifdef DEBUG_BUILD
	printf("in build\n");
#endif

	ns=openDB(dbname);
	if (n<ns)
		ns = n;

	h = create_hashtable(16, hashfromkey, equalkeys);
	index = (fastssIndex *)malloc(sizeof(fastssIndex));
	index->h = h;
	index->k = d;
	index->dbname = dbname;
	//fill the index
	for (i=0; i<ns; i++)
	{
		list=normalize(getDB(i+1), d);

		while (list!=NULL)
		{
			key k=list->precalc;
			v = (value *)malloc(sizeof(value));
			//printf("size %i\n",sizeof(value));
			l+=16;
			//fill v
			v->wordkey=i+1;
			v->next_value=NULL;
			v->delete_position_length=list->delete_position_length;
			for (j=0; j<v->delete_position_length; j++)
			{
				v->delete_position[j]= list->delete_position[j];
			}

			//search for key
			found = ht_search_some(h, k);
			if (found)
			{
#ifdef DEBUG_BUILD
				printf("  append to %s\n", k);
#endif
				if (list->delete_position_length>0)free(k);

				while (found->next_value!=NULL)
				{
					found=found->next_value;
				}
				found->next_value=v;
			} else
			{
#ifdef DEBUG_BUILD
				printf("  insert %s,%i\n", k, i);
#endif
				ht_insert_some(h, k, v);
				l+=strlen(k);
			}
			item * tmp=list->next;
			free(list);
			list=tmp;

		}

#ifdef DEBUG_BUILD
		mem_info();
		printf("nr %i, should be %i\n",i,l);
#endif
	}

	//searchNN(index,"viru",4,true);
	return index;
}

int find_and_update_rec(int * result, int value, int min, int max)
{
	int total=(max+min)/2;
	if (result[total]<value)
	{
		if (total+1>=max)
			return max;
		else
		{
			if (result[total+1]>value)
				return total+1;
			else
				return find_and_update_rec(result, value, total, max);
		}
	} else if (result[total]>value)
	{
		if (total==0)
			return 0;
		else
		{
			if (result[total-1]<value)
				return total;
			else
				return find_and_update_rec(result, value, min, total);
		}
	} else
		return -1;
}

int find_and_update(int * result, int count, int value)
{
	int ret= find_and_update_rec(result, value, 0, count);
	return ret;
}

int * search_intern(Index S, Obj obj, Tdist r, bool show, int limit,
		int * result, int * result_count, int * sum_dist)
{
	fastssIndex *index=S;
	hashtable *h=index->h;
	//key *k = (key *)malloc(sizeof(key));
	value *found;
	item *list;
	char * search_word=(char *)obj;
	bool knn=limit<0 ? false : true;
	int dist=(int)r, i;
	/*
	 if(dist>=strlen(search_word))
	 {
	 printf("Cannot search for edit distance larger than or equal to keyword length (%i,%s)!\n",dist,search_word);
	 exit(-1);
	 }*/
#ifdef DEBUG_SEARCH
	printf("in search_intern, will normalize (%s) with distance (%i)\n",search_word,dist);
#endif

	list=normalize(search_word, dist);
	while (list!=NULL && limit!=0)
	{

		key k=list->precalc;
#ifdef DEBUG_SEARCH
		printf("  go for word %s\n",k);
#endif
		found = ht_search_some(h, k);
		while (found!=NULL && (limit>0 || limit<0))
		{
			int dist2=distpos(found->delete_position,
					found->delete_position_length, list->delete_position,
					list->delete_position_length);
#ifdef DEBUG_SEARCH
			printf("  found key %i, with dist=%i\n",found->wordkey,dist2);
#endif
			if (dist>=dist2)
			{
				int n=find_and_update(result, (*result_count), found->wordkey);
				if (n>=0)
				{
					result=realloc(result,(1+(*result_count))*sizeof(int));
					int i2=0;
					for (i2=(*result_count)-1; i2>=n; i2--)
						result[i2+1]=result[i2];
					result[n]=found->wordkey;
					(*result_count)++;
					(*sum_dist)+=dist2;

					if (show)
						printf("Found similar word: %s, k=%i\n",
								getDB(found->wordkey), dist2);
					limit--;
				}
			}
			found=found->next_value;
		}

		item * tmp=list->next;
		if (list->delete_position_length>0)free(list->precalc);
		free(list);
		list=tmp;
	}
	return result;
}

int search(Index S, Obj obj, Tdist r, bool show)
{
	int * result, * result_count, * sum_dist;
	int ret;

#ifdef DEBUG_SEARCH
	printf("in search (%i,%i,%i,%i)\n",S,obj,r,show);
#endif

	result=malloc(sizeof(int));
	//result[0]=0;
	result_count=malloc(sizeof(int));
	sum_dist=malloc(sizeof(int));
	*result_count=0;

#ifdef DEBUG_SEARCH
	printf("    allocated/initialized values\n");
#endif
	result=search_intern(S, obj, r, show, -1, result, result_count, sum_dist);
#ifdef DEBUG_SEARCH
	printf("    returned from search_intern\n");
#endif
	ret=*result_count;
	free(result_count);
	free(sum_dist);
	free(result);
	return ret;
}

//Returns at least k results. This means that more than k will be returned!
Tdist searchNN(Index S, Obj obj, int k, bool show)
{
	int i, ret_int;
	float ret_float;
	int * result, * result_count, * sum_dist;
	fastssIndex *index=S;
	int dist=index->k;

#ifdef DEBUG_SEARCH
	printf("in searchNN (%i,%i,%i,%i)\n",S,obj,k,show);
#endif
	result=malloc(sizeof(int));
	//result[0]=0;
	result_count=malloc(sizeof(int));
	sum_dist=malloc(sizeof(int));
	*result_count=0;
	*sum_dist=0;
	for (i=0; i<(2*dist)+1 && k-(*result_count)>0; i++)
	{
		result
				=search_intern(S, obj, i, show, k, result, result_count,
						sum_dist);
	}

	if (*result_count>0)
	{
#ifdef DISCR
		ret_int=(*sum_dist)/(*result_count);
#else
		ret_float=(float)(*sum_dist)/(float)(*result_count);
#endif
	}
	free(result_count);
	free(sum_dist);
	free(result);

#ifdef DISCR
	return ret_int;
#else
	return ret_float;
#endif

}

void freeIndex(Index S, bool libobj)
{
	fastssIndex *index=S;
	hashtable_destroy(index->h, true);
}

/* saveIndex
 * files have the following structure:
 * {key_length}{key}{2value_count}{{4wordkey}{1delete_position_length}{1delete_position+}+}
 * LIMITS (should be enforced): 
 *   - up to 2^16 words per precalc (enforced)
 *   - up to 2^32 words
 *   - words of up to 255 characters (enforced)
 *   - up to 255 delete positions (enforced)
 *   - no support for multibyte characters
 *   - 
 */
void saveIndex(Index S, char *fname)
{
	int l;
	//key *k;
	value *v, *v0;
	hashtable_itr *itr;
	fastssIndex *index = S;
	hashtable *h = index->h;
	FILE *fp;

#ifdef DEBUG_INDEX
	printf("in saveIndex\n");
#endif

	if ( (fp=fopen(fname, "w")) == NULL)
	{
		fprintf(stderr,"Error opening output file\n");
		exit(-1);
	}
	fwrite(index->dbname, strlen(index->dbname)+1, 1, fp);
	fwrite(&index->k, 1, 1, fp);
	itr = hashtable_iterator(h);
	while (hashtable_iterator_advance(itr))
	{
		char * k = ht_hashtable_iterator_key(itr);
		int keylength = strlen(k);

		if (keylength>255)
		{ //checks limit
			printf("Error: key length limit reached (%i)\n", keylength);
			exit(-1);
		}
		fwrite(&keylength, 1, 1, fp);
		fwrite(k, strlen(k), 1, fp);
		//fetches values
		v0 = v = hashtable_iterator_value(itr);
		//writes number of values
		l=0;
		do
		{
			l++;
		} while (v = v->next_value);
		if (l>65535)
		{ //checks limit
			printf("Error: values per key limit reached (key %s, %i values)\n",
					k, l);
			exit(-1);
		}
		fwrite(&l, 2, 1, fp);
		//loops through values
		v = v0;
		while (v!=NULL)
		{
			//writes wordkey (word-id)
			fwrite(&v->wordkey, 4, 1, fp);
			//writes number of delete_positions
			fwrite(&v->delete_position_length, 1, 1, fp);
			//writes delete_positions
			for (l=0; l<v->delete_position_length; l++)
			{
				int dp = v->delete_position[l];
				fwrite(&dp, 1, 1, fp);
			}
			v = v->next_value;
		}
	}
}
Index loadIndex(char *fname)
{
	long int j, i;
	int value_count, l, length;
	//key *k;
	value *v, *v0, *found;
	hashtable *h;
	fastssIndex *index;
	char str2[1024], *dbname = str2, *str;
	FILE *fp;

#ifdef DEBUG_INDEX
	printf("in loadIndex\n");
#endif
	//opens file
	if ( (fp=fopen(fname, "r")) == NULL)
	{
		fprintf(stderr,"Error opening input file\n");
		exit(-1);
	}
	while (*dbname++ = getc(fp))
		;
	index = malloc(sizeof(index));
	index->dbname = malloc (dbname-str2);
	strcpy(index->dbname, str2);
	//reads k
	fread(&index->k, 1, 1, fp);

	//creates hash table
	h = create_hashtable(16, hashfromkey, equalkeys);
	index->h = h;

	length = 0;
	while (fread(&length, 1, 1, fp))
	{
		//k = (key *)malloc(sizeof(key));
		//reads key (precalc)
		str = malloc((length+1)*sizeof(char));
		fread(str, sizeof(char), length, fp);
		str[length] = '\0'; // Append null terminator
		key k = str;
		//reads value_count
		value_count = 0;
		fread(&value_count, 2, 1, fp);
		v = v0 = NULL;
		l = 0;
		while (l++<value_count)
		{
			//reads word
			v = (value *)malloc(sizeof(value));
			fread(&v->wordkey, 4, 1, fp);
			//reads delete positions
			v->delete_position_length = 0;
			fread(&v->delete_position_length, 1, 1, fp);
			//v->delete_position = malloc(v->delete_position_length*sizeof(int));
			for (i=0; i<v->delete_position_length; i++)
			{
				v->delete_position[i]=0;
				fread(&v->delete_position[i], 1, 1, fp);
			}
			//pointer to the next
			v->next_value=v0;
			v0 = v;
		}

		//consistency check: if this key has no value, it's a problem and reading can go out of sync
		if (v == NULL)
		{
			printf("ERROR: input file is corrupted on key %s", k);
			exit(-1);
		}

		insert_some(h, k, v);
	}
	fclose(fp);
	openDB(index->dbname);
	//prints out whole hashtable
	//printHashtable(h);
	return index;
}

int distpos(byte * positons1, byte length1, byte * positons2, byte length2)
{
	int updates = 0, i, j;
	for (i = 0, j = 0; i < length1 && j < length2;)
	{
		if (positons1[i] == positons2[j])
		{
			updates++;
			j++;
			i++;
		} else if (positons1[i] < positons2[j])
			i++;
		else if (positons1[i] > positons2[j])
			j++;
	}
	return length1 + length2 - updates;
}

char * delpos(char * string, int pos)
{
	int len=strlen(string), i;
	char * output=malloc((len)*sizeof(char));
	for (i=0; i<len; i++)
	{
		if (i<pos)
			output[i]=string[i];
		else if (i>pos)
			output[i-1]=string[i];
		else
			output[i]=0;
	}
	output[i-1]=0;
	return output;
}

item * normalizeRecursive(char * string, item * head, int nr, int counter,
		int k, int dp[])
{
	item * tail=head;
	int i, j, len;
	char * precalc;

	if (nr>0)
	{
		len=strlen(string);
		for (i=counter; i<len; i++)
		{
			tail = (item *)malloc(sizeof(item));
			//tail->delete_position= malloc(((k-nr)+1)*sizeof(byte));
			precalc = delpos(string, i);
			tail->delete_position_length=(k-nr)+1;
			tail->next=NULL;
			tail->precalc=precalc;
			dp[k-nr]=i;
			//copy old dp and add new
			for (j=0; j<(k-nr)+1; j++)
			{
				tail->delete_position[j]=dp[j];
			}
			head->next=tail;
			head=normalizeRecursive(precalc, tail, nr-1, i, k, dp);
		}
	}
	return tail;
}

item * normalize(char* string, int k)
{
	item * head;
	int dp[k];
	head = (item *)malloc(sizeof(item));
	head->precalc = string;
	head->delete_position_length=0;
	head->next=NULL;
	normalizeRecursive(string, head, k, 0, k, dp);
	return head;
}
/*
 void printHashtable(struct hashtable *S) 
 {
 long int j, max, i;
 int dp, l;
 key *k;
 value *v;
 hashtable_itr *itr;
 hashtable *h = S;
 
 //  if (DEBUG_DEBUGGER) printf("in printHashtable\n");
 
 itr = hashtable_iterator(h);
 //   if (DEBUG_DEBUGGER) printf(" iterator created\n");
 
 i = 0;
 if (hashtable_count(h) > 0)
 {
 //      if (DEBUG_DEBUGGER) printf(" in conditional\n");
 
 do {
 //          if (DEBUG_DEBUGGER) printf(" looping in main loop\n");
 
 //fetches key
 k = hashtable_iterator_key(itr);
 
 //writes key
 printf("%s|",k);
 
 //fetches values
 v = hashtable_iterator_value(itr);
 
 //values might point to other values
 do {
 //           if (DEBUG_DEBUGGER) printf("  looping in inner loop\n");
 
 //writes wordkey (word-id)
 printf("%i:",v->wordkey);
 
 //writes delete_positions
 for (l=0; l<v->delete_position_length; l++)  {
 
 //           if (DEBUG_DEBUGGER) printf("   in for dp (%i)\n",l);
 dp = v->delete_position[l];
 
 printf("%i,",dp);
 }
 
 } while (v = v->next_value);
 
 i++;
 printf("\n");

 } while (hashtable_iterator_advance(itr));
 }
 
 //  if (DEBUG_DEBUGGER) printf("out printHashtable\n");

 }
 */

void * ht_search_some(struct hashtable *h, char *k)
{
	if (k[0]==0)
		return search_some(h, "#\0");
	else
		return search_some(h, k);
}

int ht_insert_some(struct hashtable *h, char *k, void *v)
{
	if (k[0]==0)
		return insert_some(h, "#\0", v);
	else
		return insert_some(h, k, v);
}

void * ht_hashtable_iterator_key(struct hashtable_itr *itr)
{
	char * k = hashtable_iterator_key(itr);
	if (k[0]==0)
		return "\0";
	else
		return k;
}
