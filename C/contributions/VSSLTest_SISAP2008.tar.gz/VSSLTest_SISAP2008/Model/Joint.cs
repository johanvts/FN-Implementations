/*
Copyright 2005 Alan Eckhardt, Vojt�ch Fried, Mat�j Hoffmann, David Hoksza, Martina Mat�skov�
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


/*
 * NOTE:
 * 
 * The following code is reused from dictionary mentioned above. 
 * 
 * This part of code is used for transformation signs represented by instance 
 * of Notation class into 3D model.
 * As this is not part of similarity evaluation algorithm the comments were 
 * not translated English (all the comments are done in Czech).
 * 
 * 2008, Jan Ulrych
 */


using System;   
using System.Text;


	/// <summary>
	///  Spr�va a napln�n� jednotliv�ch �daj� pro klouby znakovac�ho pan��ka,
	///  pr�ce s vektory a rotacemi.
	/// </summary>
	public class Joint
	{
		public const int MaxNumberOfRotationInInterpolator = 100;
		/// <summary>
		/// Uchov�n� informac� o rotaci.
		/// </summary>
		public class Rotation
		{
			/// <summary>
			/// Sou�adnice a �hel rotace.
			/// </summary>
			public double x, y, z, angle;

			/// <summary>
			/// P�i vytvo�en� instance inicializuje rotaci o 0�. 
			/// </summary>
			public Rotation()
			{
				x = 1; 
				y = 0;
				z = 0;
				angle = 0;
			}
			/// <summary>
			/// P�i vytvo�en� instance inicializuje rotaci podle vstupn�ch parametr�.
			/// </summary>
			/// <param name="setX">Definovan� osa x rotace.</param>
			/// <param name="setY">Definovan� osa y rotace.</param>
			/// <param name="setZ">Definovan� osa z rotace.</param>
			/// <param name="setAngle">Definovan� velikost �hlu rotace.</param>
			public Rotation(double setX,double setY,double setZ,double setAngle) 
			{
				x = setX;
				y = setY;
				z = setZ;
				angle = setAngle;
			}
						
			/// <summary>
			/// Normalizace vektoru instance t��dy volaj�c� tuto metodu.
			/// </summary>
			/// <exception cref="GenException.ComputingException">Vektor m� v�echny t�i slo�ky rovny nule.</exception>
			public void normalize()
			{
				if (x == 0 && y == 0 && z == 0)
					throw new GenException.ComputingException("V�echny t�i slo�ky vektoru jsou rovny nule.");
				double t = Math.Sqrt(x * x + y * y + z * z);
				x /= t;
				y /= t;
				z /= t;
			}
			/// <summary>
			/// Kontrola nenulovosti vektoru.
			/// </summary>
			/// <exception cref="GenException.ComputingException">V�echny t�i slo�ky vektoru jsou rovny nule.</exception>
			public void checkNullVector()
			{
				if (x == 0 && y == 0 && z == 0)
					throw new GenException.ComputingException("V�echny t�i slo�ky vektoru jsou rovny nule.");
			}
			
			/// <summary>
			/// Zkop�rov�n� rotace uveden�  v parametru do rotace instance t��dy, kter� vol� tuto metodu. 
			/// </summary>
			/// <param name="sourceRot">Rotace, kter� je vzorem pro kopii.</param>
			/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
			public void copyRotation(Rotation sourceRot) 
			{
				if(sourceRot == null)
					throw new GenException.ParameterException("sourceRot: " + (sourceRot == null ? "NULL":sourceRot.ToString()));
				x = sourceRot.x;
				y = sourceRot.y;
				z = sourceRot.z;
				angle = sourceRot.angle;
			}            
			/// <summary>
			/// Nastaven� osy vektoru na osy, kter� jsou zadan� ve vektoru v parameru.
			/// </summary>
			/// <param name="vector">Vektor jeho� osy jsou vzorem.</param>
			public void setAxis(Joint.Vector vector)
			{
				x = vector.x;
				y = vector.y;
				z = vector.z;
			}
			/// <summary>
			/// P�eveden� obsahu vektoru na string. 
			/// </summary>
			/// <returns>�et�zec obsahuj�c� data vektoru.</returns>
			public override string ToString()
			{
				return "" + this.x.ToString("F2") + "," + this.y.ToString("F2") + "," + this.z.ToString("F2") + "," + this.angle.ToString("F2");
			}
			/// <summary>
			///Slo�en� dvou rotac� ve tvaru osa ot��en� a �hel, jsou zad�ny v parametru, prov�d�no pomoc� kvaternionu.
			///Rotace jsou p�evedeny na kvaterniony a vyn�sobeny, n�sledn� p�evedeny zp�t do tvaru osy a �hlu.
			///V�sledn� rotace je ulo�ena do parametru oldRotation. 
			/// </summary>
			/// <param name="joinRotation">Rotace p�id�van�.</param>
			/// <param name="oldRotation">Rotace p�vodn�.</param>
			/// <param name="flag">V p��pad�, �e je flag = 0 je joinRotation p�id�v�na zleva.
			/// V p��pad�, �e je flag = 1 je joinRotation p�id�v�na zprava.</param>
			/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
			public static Joint.Rotation composeRotation(Rotation joinRotation, Rotation oldRotation, int flag) {
				if ((joinRotation == null) || (oldRotation == null) || ((flag != 1) && (flag != 0)))
					throw new GenException.ParameterException("joinRotation: " + (joinRotation == null ? "NULL" : joinRotation.ToString()) + ", " + "oldRotation: " + (oldRotation == null ? "NULL" : oldRotation.ToString()) + ", " + "flag: " + flag);

				// pomocn� kvaterniony
				Quaternion joinQuat = new Quaternion();
				Quaternion oldQuat = new Quaternion();
				Quaternion newQuat = new Quaternion();
				Rotation result = new Rotation();

				// p�eveden� rotac� na kvaterniony
				joinQuat.angleToQuatertnion(joinRotation);
				oldQuat.angleToQuatertnion(oldRotation);

				if (flag == 0) // p�inasob� novou rotaci zleva
					newQuat.multipleQuaternions(joinQuat, oldQuat);
				else if (flag == 1) // p�inasob� novou rotaci zprava
					newQuat.multipleQuaternions(oldQuat, joinQuat);
				// p�eveden� kvaternionu na rotaci tvaru osa a �hel
				newQuat.quaternionToAngle(ref result);
				return result;
			}

			/// <summary>
			/// j1 - j2 je takov� rotace, �e po jej�m slo�en� s rotac� r2 z�sk�m rotaci r1
			/// </summary>
			/// <param name="j1"></param>
			/// <param name="j2"></param>
			/// <returns></returns>
			public static Joint.Rotation subRotations(Joint.Rotation j1, Joint.Rotation j2) {
				Quaternion r1 = new Quaternion(); r1.angleToQuatertnion(j1);
				Quaternion r2 = new Quaternion(); r2.angleToQuatertnion(j2);
				Quaternion r1inv = new Quaternion(); r1.inverseQuaternion(ref r1inv);
				Quaternion r1_r1inv = new Quaternion(); r1_r1inv.multipleQuaternions(r1, r1inv);
				r1inv.w = r1inv.w / r1_r1inv.w;
				r1inv.x = r1inv.x / r1_r1inv.w;
				r1inv.y = r1inv.y / r1_r1inv.w;
				r1inv.z = r1inv.z / r1_r1inv.w;
				Quaternion r1inv_r2 = new Quaternion(); r1inv_r2.multipleQuaternions(r1inv, r2);
				Joint.Rotation rot = new Joint.Rotation();
				r1inv_r2.quaternionToAngle(ref rot);
				return rot;
			}
		}

		
		/// <summary>
		/// Aplikace matematick�ch operac� s vektory. 
		/// </summary>
		public class Vector
		{
			/// <summary>
			/// Sou�adnice vektoru instance t��dy.
			/// </summary>
			public double x, y, z;
			
			/// <summary>
			/// P�i vytvo�en� instance inicializuje na nulov� vektor.
			/// </summary>
			public Vector()
			{
				x = 0;
				y = 0;
				z = 0;
			}

			/// <summary>
			/// P�i vytvo�en� instance inicializuje na vektor zadan� parametry.
			/// </summary>
			/// <param name="setX">Sou�adnice x vektoru.</param>
			/// <param name="setY">Sou�adnice y vektoru.</param>
			/// <param name="setZ">Sou�adnice z vektoru.</param>
			public Vector(double setX,double setY,double setZ)
			{
				x = setX;
				y = setY;
				z = setZ;
			}

			/// <summary>
			/// Normalizace vektoru instance t��dy volaj�c� tuto metodu.
			/// </summary>
			/// <exception cref="GenException.ComputingException">V�echny t�i slo�ky vektoru jsou rovny nule.</exception>
			public void normalize()
			{
				if (x == 0 && y == 0 && z == 0)
					throw new GenException.ComputingException("V�echny t�i slo�ky vektoru jsou rovny nule.");
				double t = Math.Sqrt(x * x + y * y + z * z);
				x /= t;
				y /= t;
				z /= t;
			}
			
			/// <summary>
			/// Kontrola na nenulovost vektoru.
			/// </summary>
			/// <exception cref="GenException.ComputingException">V�echny t�i slo�ky vektoru jsou rovny nule.</exception>
			public void checkNullVector() 
			{
				if (x == 0 && y == 0 && z == 0)
					throw new GenException.ComputingException("V�echny t�i slo�ky vektoru jsou rovny nule."); 
			}
			
			/// <summary>
			/// Porovn�n� vektoru instance a vektoru zadan�ho v parametru.
			/// </summary>
			/// <param name="comp">Vektor k porovn�n�.</param>
			/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
			/// <returns>V p��pad� shodnosti vektoru vrac� metoda true, jinak false.</returns>
			public bool compareVector(Vector comp) 
			{
				if(comp == null)
					throw new GenException.ParameterException("comp: " + (comp == null ? "NULL":comp.ToString()));
				if ((x == comp.x) && (y == comp.y) && (z == comp.z))
					return true;
				else
					return false;
			}
			/// <summary>
			/// Zkop�rov�n� vektoru zadan�ho ve vstupn�m parametru do instance t��dy, kter� vol� tuto metodu.
			/// </summary>
			/// <param name="sourceVect">Vektor, kter� slou�� jako p�edloha ke kopii.</param>
			/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
			public void copyVector(Vector sourceVect)
			{
				if(sourceVect == null)
					throw new GenException.ParameterException("sourceVect: " + (sourceVect == null ? "NULL":sourceVect.ToString())); // wrong parameter

				x = sourceVect.x;
				y = sourceVect.y;
				z = sourceVect.z;
			}
			/// <summary>
			/// Se�ten� sou�adnic vektoru a vektoru v parametru.
			/// </summary>
			/// <param name="addVector">Vektor k p�i�ten�.</param>
			public void addVectors(Vector addVector)
			{
				if(addVector == null)
					throw new GenException.ParameterException("addVector: " + (addVector == null ? "NULL":addVector.ToString()));
				x += addVector.x;
				y += addVector.y;
				z += addVector.z;
			}
			/// <summary>
			/// Ode�ten� sou�adnic vektoru v parametru od sou�adnic vektoru instance.
			/// </summary>
			/// <param name="subVector">Vektor k ode�ten�.</param>
			public void subVectors(Vector subVector)
			{
				if(subVector == null)
					throw new GenException.ParameterException("subVector: " + (subVector == null ? "NULL":subVector.ToString()));
				x -= subVector.x;
				y -= subVector.y;
				z -= subVector.z;
			}

			/// <summary>
			/// Sou�adnice vektoru nastaveny na 0.
			/// </summary>
			public void setNull()
			{
				x = 0;
				y = 0;
				z = 0;
			}
			/// <summary>
			/// Sou�adnice vektoru vyn�sobeny -1.
			/// </summary>
			public void minusVector()
			{
				x = -x;
				y = -y;
				z = -z;
			}
			/// <summary>
			/// P�eveden� dav vektoru do stringu.
			/// </summary>
			/// <returns>�et�zec obsahuj�c�  vektor.</returns>
			public override string ToString()
			{
				return "" + this.x.ToString() + "," + this.y.ToString() + "," + this.z.ToString();
			}
		}
		/// <summary>
		/// Seznam n�sledn�k� kloubu instance t��dy.
		/// </summary>
		public Joint [] listOfChild; 
		/// <summary>
		/// Seznam p�edch�dc� kloubu instance t��dy.
		/// </summary>
		public Joint[] listOfParent; 
		/// <summary>
		/// Jm�no kloubu ve vrml souborech.
		/// </summary>
		public String nameOfJoint; 
		/// <summary>
		/// V�echny rotace aplikovan� na kloub v�etn� rotac� aplikovan�ch na p�edch�dce.
		/// </summary>
		//public Rotation actualRotation ; 
		/// <summary>
		/// Rotace, kter� jsou p�en�eny do vrml souboru, nen� pot�eba i rotace p�edch�dc�, ty si po��t� vrml.
		/// </summary>
		public Rotation vrmlRotation ;
		/// <summary>
		/// Norm�la k dan�mu kloubu, odli�n� dle pou�it� norm�ly kloubu.
		/// </summary>
		public Vector normal;  
		/// <summary>
		/// Relativn� posunut� kloubu vzhledem k p�edch�dci. V p��pad� ramene jde o vzd�lenost
		/// vzhledem k VRML sv�tu.
		/// </summary>
		public Vector relativeDistance;
		/// <summary>
		/// Kopie vrml rotac�. Pou��v� se u simult�ln�ch pohyb�.
		/// </summary>
		public Joint.Rotation copyOfVrmlRot;
		/// <summary>
		/// Rotace, kter� pat�� k jednomu pohybu.
		/// </summary>
		public System.Collections.ArrayList interpolatorRotations;
		/// <summary>
		/// Seznam v�ech rotac� cel�ho pohybu ve znaku.
		/// </summary>
		public System.Collections.ArrayList interpolatorFinalMoveRotations;
		/// <summary>
		/// Seznam �asov�ch interval� pro jednotliv� rotace pohybu.
		/// </summary>
		public System.Collections.ArrayList interpolatorKey;
		/// <summary>
		/// Rotace pohybu, kter� je sou��st� pohybu simult�ln�ho.
		/// </summary>
		public System.Collections.ArrayList moveLocalRotations;
		/// <summary>
		/// Seznam moveLocalRotations v�ech pohyb� pohybu simult�ln�ho.
		/// </summary>
		public System.Collections.ArrayList simultalMoveRotationsLists;

		/// <summary>
		/// P�i vytvo�en� instance kloubu vytvo�� seznam p�edch�dc� a n�sledn�k�.
		/// </summary>
		/// <param name="numberOfChild">Po�et n�sledn�k� kloubu.</param>
		/// <param name="numberOfParent">Po�et p�edch�dc� kloubu.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
		public Joint(int numberOfChild,int numberOfParent) 
		{
			if((numberOfChild < 0) || (numberOfParent < 0))
				throw new GenException.ParameterException("numberOfChild: " + numberOfChild + ", " + "numberOfParent: " + numberOfParent); 

			listOfChild = new Joint[numberOfChild];
			listOfParent = new Joint[numberOfParent];
			vrmlRotation = new Rotation();
			normal = new Vector();
			relativeDistance = new Vector();
			interpolatorRotations = new System.Collections.ArrayList(MaxNumberOfRotationInInterpolator);
			interpolatorFinalMoveRotations = new System.Collections.ArrayList(MaxNumberOfRotationInInterpolator);
			interpolatorKey = new System.Collections.ArrayList(MaxNumberOfRotationInInterpolator);
			interpolatorKey.Add(0.0);
			moveLocalRotations = new System.Collections.ArrayList(MaxNumberOfRotationInInterpolator);
			simultalMoveRotationsLists = new System.Collections.ArrayList(MaxNumberOfRotationInInterpolator);
			copyOfVrmlRot = new Rotation();
		}

		/// <summary>
		///Slo�en� dvou rotac� ve tvaru osa ot��en� a �hel, jsou zad�ny v parametru, prov�d�no pomoc� kvaternionu.
		///Rotace jsou p�evedeny na kvaterniony a vyn�sobeny, n�sledn� p�evedeny zp�t do tvaru osy a �hlu.
		///V�sledn� rotace je ulo�ena do parametru oldRotation. 
		/// </summary>
		/// <param name="joinRotation">Rotace p�id�van�.</param>
		/// <param name="oldRotation">Rotace p�vodn�.</param>
		/// <param name="flag">V p��pad�, �e je flag = 0 je joinRotation p�id�v�na zleva.
		/// V p��pad�, �e je flag = 1 je joinRotation p�id�v�na zprava.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
		public void composeRotation(Rotation joinRotation, ref Rotation oldRotation,int flag)
		{
			if((joinRotation == null) || (oldRotation == null) || ((flag != 1) && (flag != 0)))
				throw new GenException.ParameterException("joinRotation: " + (joinRotation == null ? "NULL":joinRotation.ToString()) + ", " + "oldRotation: " + (oldRotation == null ? "NULL":oldRotation.ToString()) + ", " + "flag: " + flag);

			// pomocn� kvaterniony
			Quaternion joinQuat = new Quaternion();
			Quaternion oldQuat = new Quaternion();
			Quaternion newQuat = new Quaternion();

			// p�eveden� rotac� na kvaterniony
			joinQuat.angleToQuatertnion(joinRotation);
			oldQuat.angleToQuatertnion(oldRotation);

			if(flag == 0) // p�inasob� novou rotaci zleva
				newQuat.multipleQuaternions(joinQuat,oldQuat);
			else if(flag == 1) // p�inasob� novou rotaci zprava
				newQuat.multipleQuaternions(oldQuat,joinQuat);
			// p�eveden� kvaternionu na rotaci tvaru osa a �hel
			newQuat.quaternionToAngle(ref oldRotation);
		}

		/// <summary>
		/// Slo�en� rotace kloubu instance a rotac� kloub� jeho p�edch�dc�, 
		/// neboli p�eveden� rotace instance do glob�ln�ch sou�adnic (sou�adnice sv�ta), kter� je v hierarchii nejv��e
		/// </summary>
		/// <param name="rotation">V�sledn� rotace vr�cena t�mto parametrem.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
		public void joinParentsRotations(ref Rotation rotation) 
		{
			int i;
			if(rotation == null)
				throw new GenException.ParameterException("rotation: " + (rotation == null ? "NULL":rotation.ToString()));

			//prvn� rotace je rotace instance kloubu
			Rotation middleRotation = new Rotation(this.vrmlRotation.x,this.vrmlRotation.y,this.vrmlRotation.z,this.vrmlRotation.angle);
			Quaternion rightQuat = new Quaternion();
			Quaternion leftQuat = new Quaternion();
			Quaternion multiQuat = new Quaternion();

			for (i = 0; i < this.listOfParent.Length; i++) 
			{
				rightQuat.angleToQuatertnion(middleRotation);
				leftQuat.angleToQuatertnion(listOfParent[i].vrmlRotation);
				multiQuat.multipleQuaternions(leftQuat,rightQuat);
				multiQuat.quaternionToAngle(ref middleRotation);
			}

			rotation.copyRotation(middleRotation);
		}
		/// <summary>
		/// P�id�n� vrml rotace do listu rotac�.
		/// </summary>
		public void addVrmlRotationToList()
		{	
			Joint.Rotation copyRot = new Rotation();
			copyRot.copyRotation(this.vrmlRotation);
			
			this.interpolatorRotations.Add(copyRot);
		}
		/// <summary>
		/// P�id�n� rotace do fin�ln�ho seznamu.
		/// </summary>
		/// <param name="addRot">P��d�van� rotace.</param>
		public void addVrmlRotationToFinalMoveList(Rotation addRot)
		{	
			Joint.Rotation copyRot = new Rotation();
			copyRot.copyRotation(addRot);
			
			this.interpolatorFinalMoveRotations.Add(copyRot);
		}

	}

