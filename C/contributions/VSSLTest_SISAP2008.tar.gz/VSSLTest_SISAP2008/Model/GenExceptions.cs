/*
Copyright 2005 Alan Eckhardt, Vojt�ch Fried, Mat�j Hoffmann, David Hoksza, Martina Mat�skov�
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


/*
 * NOTE:
 * 
 * The following code is reused from dictionary mentioned above. 
 * 
 * This part of code is used for transformation signs represented by instance 
 * of Notation class into 3D model.
 * As this is not part of similarity evaluation algorithm the comments were 
 * not translated English (all the comments are done in Czech).
 * 
 * 2008, Jan Ulrych
 */


using System;

	
	/// <summary>
	/// Vyj�mka, kter� nastala v pr�behu zpracov�n� notace a generov�n� dat pro model.
	/// </summary>
	 public class GenException: Exception
	{
		public int typeOfEx;
		public string messageToUser;

		/// <summary>
		/// Konstruktor se zadanou chybou.
		/// </summary>
		public GenException()
		{
			typeOfEx = 0;
			messageToUser = "";
		}
		/// <summary>
		/// Konstruktor se zadanou chybou.
		/// </summary>
		/// <param name="message"></param>
		
		 public GenException(string message)
			 :base(message)
			{
			 typeOfEx = 0;
			 messageToUser = "";
			}
		 /// <summary>
		 /// Konstruktor ze zadanou chybou a vyj�mkou.
		 /// </summary>
		 /// <param name="message">Zpr�va.</param>
		 /// <param name="inner">Vyj�mka.</param>
		 public GenException(string message, Exception inner)
			 :base(message,inner)
			{
			 typeOfEx = 0;
			 messageToUser = "";
			}
		/// <summary>
		/// Vyj�mka, kter� nastane v pr�b�hu v�po�tu dat pro model.
		/// </summary>
		public class ComputingException :GenException
		{
			/// <summary>
			/// Konstruktor vyj�mky, nastav� zpr�vu pro u�ivatele.
			/// </summary>
			public ComputingException()
			{
				messageToUser = "Chyba p�i v�po�tu !";
			}
			/// <summary>
			/// 
			/// </summary>
			/// <param name="message">Zpr�va.</param>
			public ComputingException(string message)
				:base(message)
			{
				messageToUser = "Chyba p�i v�po�tu !\n" + message;
			}
			/// <summary>
			/// 
			/// </summary>
			/// <param name="message">Zpr�va.</param>
			/// <param name="inner">Vyj�mka.</param>
			public ComputingException(string message, Exception inner)
				:base(message,inner)
			{
				messageToUser = "Chyba p�i v�po�tu !\n" + message;
			}
		}
		 /// <summary>
		 /// Vyj�mka p�i zpracov�n� notace.
		 /// </summary>
		 public class NotationException : GenException
		 {
			 /// <summary>
			 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 public NotationException()
			 {
				 messageToUser = "Chyba p�i zpracov�n� notace !";
			 }
			 /// <summary>
			 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 /// <param name="message">Zpr�va.</param>
			 public NotationException(string message)
				 :base(message)
			 {
				 messageToUser = "Chyba p�i zpracov�n� notace !";
			 }
			 /// <summary>
			 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 /// <param name="message">Zpr�va.</param>
			 /// <param name="inner">Vyj�mka.</param>
			 public NotationException(string message, Exception inner)
				 :base(message,inner)
			 {
				 messageToUser = "Chyba p�i zpracov�n� notace !";
			 }
		 }
	/// <summary>
	/// Vyj�mka p�i zad�n� parametr� funkce.
	/// </summary>
	public class ParameterException : GenException
	{
		/// <summary>
		/// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
		/// </summary>
		public ParameterException()
		{
			messageToUser = "Chyba p�i zpracov�n� !";
		}
		/// <summary>
		/// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
		/// </summary>
		/// <param name="message">Zpr�va.</param>
		public ParameterException(string message)
			:base(message)
		{
			messageToUser = "Chyba p�i zpracov�n� !";
		}
		/// <summary>
		/// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
		/// </summary>
		/// <param name="message">Zpr�va.</param>
		/// <param name="inner">Vyj�mka.</param>
		public ParameterException(string message, Exception inner)
			:base(message,inner)
		{
			messageToUser = "Chyba p�i zpracov�n� !";
		}
	}
		 /// <summary>
		 /// Vyj�mka p�i zpracov�n� souboru s daty.
		 /// </summary>
		 public class UsingFileException : GenException
		 {
			 public string file;

			 /// <summary>
			 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 public UsingFileException()
			 {
				 messageToUser = "Chyba p�i zpracov�n� souboru !";
				 file = "";
			 }
			 /// <summary>
			 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 /// <param name="message">Zpr�va.</param>
			 public UsingFileException(string message)
				 :base(message)
			 {
				 messageToUser = "Chyba p�i zpracov�n� souboru !";
				 file = "";
			 }
			 /// <summary>
			 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 /// <param name="message">Zpr�va</param>
			 public UsingFileException(string message,string fileName)
				 :base(message)
			 {
				 messageToUser = "Chyba p�i zpracov�n� souboru !";
				 file = fileName;
			 }
			 /// <summary>
	    	 /// Konstruktor vyj�mky nastav� zpr�vu pro u�ivatele.
			 /// </summary>
			 /// <param name="message">Zpr�va.</param>
			 /// <param name="inner">Vyj�mka.</param>
			 public UsingFileException(string message, Exception inner)
				 :base(message,inner)
			 {
				 messageToUser = "Chyba p�i zpracov�n� souboru !";
				 file = "";
			 }
		 }

	 }


