/*
Copyright 2005 Alan Eckhardt, Vojt�ch Fried, Mat�j Hoffmann, David Hoksza, Martina Mat�skov�
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


/*
 * NOTE:
 * 
 * The following code is reused from dictionary mentioned above. 
 * 
 * This part of code is used for transformation signs represented by instance 
 * of Notation class into 3D model.
 * As this is not part of similarity evaluation algorithm the comments were 
 * not translated English (all the comments are done in Czech).
 * 
 * 2008, Jan Ulrych
 */


using System;
//using System.Collections.Generic;
using System.Text;



	/// <summary>
	/// Aplikace matematick�ch operac� s kvaterniony.
	/// </summary>
	
	public class Quaternion
	{
        /// <summary>
        /// Slo�ky z nich� se skl�d� z�pis kvaternionu.
        /// </summary>
		public double x, y, z, w;

		/// <summary>
		/// Po��te�n� hodnota kvaternionu je jednotkov� kvaternion.
		/// </summary>
		public Quaternion() 
		{
			w = 1;
			x = 0;
			y = 0;
			z = 0;
		}
		/// <summary>
		/// Normalizace kvaternionu, kter� je instanc� t��dy, kter� vol� tuto metodu.
		/// </summary>
		/// <exception cref="GenException.ComputingException">Zadan� quaternion m� v�echny slo�ky rovny nule.</exception>
		public void normalize()
		{
			if (x == 0 && y == 0 && z ==0 && w==0)
				
				throw new GenException.ComputingException("Zadan� quaternion m� v�echny slo�ky rovny nule."); 
			double t = Math.Sqrt(w*w + x * x + y * y + z * z);
			w /= t;
			x /= t;
			y /= t;
			z /= t;

		}
		/// <summary>
		/// V parametru vrac� inverzn� kvaternion ke kvaternionu instance t��dy, kter� vol� tuto metodu.
		/// </summary>
		/// <param name="inverseQuat">Inverzn� kvaternion.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="GenException.ComputingException">V�echny slo�ky kvaternionu jsou rovny nule.</exception>
		public void inverseQuaternion(ref Quaternion inverseQuat) 
		{
			if(inverseQuat == null)
				throw new GenException.ParameterException("inverseQuat: " + (inverseQuat == null ? "NULL":inverseQuat.ToString()));

			double expNorm = this.w*this.w + this.x*this.x + this.y*this.y + this.z*this.z;
 
			if (x == 0 && y == 0 && z == 0 && w == 0)
				throw new GenException.ComputingException("V�echny slo�ky kvaternionu jsou rovny nule."); 
           
			inverseQuat.w = this.w / expNorm;
			inverseQuat.x = -1*this.x / expNorm;
			inverseQuat.y = -1*this.y / expNorm;
			inverseQuat.z = -1*this.z / expNorm;
		}

		/// <summary>
		/// P�eveden� rotace v reprezentaci osa a �hel ot��en� na reprezentaci zapsanou kvaternionem.
		/// Tento kvaternion je instanc� t��dy, kter� vol� metodu.
		/// </summary>
		/// <param name="rot">Rotace v reprezentaci osa a �hel ot��en�.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
		public void angleToQuatertnion(Joint.Rotation rot)
		{
			if(rot == null)
				throw new GenException.ParameterException("rot: " + (rot == null ? "NULL":rot.ToString()));
			
			// p�ed p�eveden�m rotace je nutno prov�st jej� normalizaci
			rot.normalize();
			double s = Math.Sin(rot.angle / 2);
			x = rot.x * s;
			y = rot.y * s;
			z = rot.z * s;
			w = Math.Cos(rot.angle / 2);
		}
		
		/// <summary>
		/// P�eveden� rotace v reprezentaci kvaternionem, kter� je instanc� t��dy, kter� vol� tuto metodu,
		/// na reprezentaci osa ota�en� a �hel.
		/// </summary>
		/// <param name="rot">V�sledn� rotace v reprezentaci osa ota�en� a �hel.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
		public void quaternionToAngle(ref Joint.Rotation rot) 
		{
			if(rot == null)
				throw new GenException.ParameterException("rot: " + (rot == null ? "NULL":rot.ToString()));
			
			this.normalize();
			rot.angle = 2 * Math.Acos(this.w);
			double s = Math.Sqrt(1 - this.w * this.w); // assuming Quaternion normalised then w is less than 1, so term always positive
			if (s < 0.001)
			{ //test na d�len� nulou, s je v�dy kladn� kv�li odmocnin�
				// jestli�e je s bl�zko nule, sm�r os nen� dule�it�
				rot.x = 1; 
				rot.y = this.y;
				rot.z = this.z;
			}
			else
			{	// normalizace os
				rot.x = this.x / s; 
				rot.y = this.y / s;
				rot.z = this.z / s;
			}
		}
		
		/// <summary>
		/// Vyn�soben� kvaternionu zadan�ch v parametrech.
		/// </summary>
		/// <param name="quat1">Kvaternion, kter� je p�in�soben zleva.</param>
		/// <param name="quat2">Kvaternion, kter� je p�in�soben zprava.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� nebo �patn� zadan� parametr.</exception>
		public void multipleQuaternions(Quaternion quat1, Quaternion quat2) 
		{
			if((quat1 == null) || (quat2 == null))
					throw new GenException.ParameterException("quat1: " + (quat1 == null ? "NULL":quat1.ToString()) + ", " + "quat2: " + (quat2 == null ? "NULL":quat2.ToString()));

			this.w = quat1.w * quat2.w - quat1.x * quat2.x - quat1.y * quat2.y - quat1.z * quat2.z;
			this.x = quat1.w * quat2.x + quat1.x * quat2.w + quat1.y * quat2.z - quat1.z * quat2.y;
			this.y = quat1.w * quat2.y + quat1.y * quat2.w + quat1.z * quat2.x - quat1.x * quat2.z;
			this.z = quat1.w * quat2.z + quat1.z * quat2.w + quat1.x * quat2.y - quat1.y * quat2.x;
 
		}
		/// <summary>
		/// Obsah quaternionu instance p�evede na string.
		/// </summary>
		/// <returns>String obsahuj�c� data quaternionu.</returns>
		public override string ToString()
		{			
				return "" + this.x.ToString() + "," + this.y.ToString() + "," + this.z.ToString() + "," + this.w;
		}
	}

