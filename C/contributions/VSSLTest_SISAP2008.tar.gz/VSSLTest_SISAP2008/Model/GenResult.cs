/*
Copyright 2005 Alan Eckhardt, Vojt�ch Fried, Mat�j Hoffmann, David Hoksza, Martina Mat�skov�
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


/*
 * NOTE:
 * 
 * The following code is reused from dictionary mentioned above. 
 * 
 * This part of code is used for transformation signs represented by instance 
 * of Notation class into 3D model.
 * As this is not part of similarity evaluation algorithm the comments were 
 * not translated English (all the comments are done in Czech).
 * 
 * 2008, Jan Ulrych
 */


using System;


	/// <summary>
	/// T��da, jej� instance se vrac� po vygenerov�n� znaku.
	/// </summary>
	public class GenResult
	{
		public Joint[] leftHand;
		public Joint[] rightHand;
		public double moveTime;
		public System.Collections.ArrayList messagesToUser;

		public GenResult()
		{
			moveTime = 0;
			leftHand = null;
			rightHand = null;
			messagesToUser = new System.Collections.ArrayList();
		}
	}

