/*
Copyright 2005 Alan Eckhardt, Vojt�ch Fried, Mat�j Hoffmann, David Hoksza, Martina Mat�skov�
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


/*
 * NOTE:
 * 
 * The following code is reused from dictionary mentioned above. 
 * 
 * This part of code is used for transformation signs represented by instance 
 * of Notation class into 3D model.
 * As this is not part of similarity evaluation algorithm the comments were 
 * not translated English (all the comments are done in Czech).
 * 
 * 2008, Jan Ulrych
 */

 
using System;
using System.Globalization;
using System.Text;
using System.IO;
using System.Threading;


	/// <summary>
	/// Generuje soubory, kter� jsou pot�ebn� k proveden� znaku pomoc� VRML prohl�e�e. Generov�ny jsou jen ty soubory,
	/// kter� jsou pro ka�d� znak rozd�ln�.
	/// V souboru initialize.js jsou ulo�eny rotace jednotliv�ch kloub� modelu, tak aby po po��te�n�m nastaven�
	/// VRML sv�ta byl model v po��te�n� pozici znaku, kter� bude znakovat.
	/// V souboru interpolator.wrl budou ulo�eny informace o animac�ch modelu. 
	/// V souboru timer.wrl jsou informace k timeru, kter� celou animaci modelu ��d�.	
	/// </summary>
	public class Gen_main
	{
		/// <summary>
		/// Cesta k soubor�m, kde jsou ulo�eny data pro generov�n� vrml modelu.
		/// </summary>
		public static string pathToGenerate = "" ;
		/// <summary>
		/// Cesta kam se maj� vygenerovat dinamick� soubory intialize.js, interpolator.wrl a timer.wrl.
		/// </summary>
		public static string pathToModel = "" ;
		/// <summary>
		/// Absolutn� cesta k souboru se jm�ny kloub�.
		/// </summary>
		public static string nameOfJointsFileName;
		/// <summary>
		/// Absolutn� cesta k souboru s norm�lami modelu.
		/// </summary>
		public static string vectorOfNormalsFileName;
		/// <summary>
		/// Absolutn� cesta k souboru se sm�ry prst� modelu.
		/// </summary>
		public static string directionOfFingerFileName;
		/// <summary>
		/// Absolutn� cesta k souboru s ORI sm�ry.
		/// </summary>
		public static string directionOriFileName ;
		/// <summary>
		/// Absolutn� cesta k souboru se sm�ry HA.
		/// </summary>
		public static string directionHaFileName;
		/// <summary>
		/// Absolutn� cesta k souboru s relativn�mi vzd�lenostmi kloub� modelu.
		/// </summary>
		public static string relativeDistanceFileName;
		/// <summary>
		/// Absolutn� cesta k souboru, kde jsou ulo�eny informace k pohyb�m.
		/// </summary>
		public static string moveInformationFileName;
		/// <summary>
		/// Absolutn� cesta k souboru kde jsou sou�adnice kontaktn�ch m�st.
		/// </summary>
		public static string coordToContactFileName;
		/// <summary>
		/// Absolutn� cesta k souboru s informacemi pro DEZ.
		/// </summary>
		public static string dezFileName;
		/// <summary>
		/// Absolutn� cesta k souboru s informace pro TAB pro levou ruku.
		/// </summary>
		public static string tabLFileName;
		/// <summary>
		/// Absolutn� cesta k souboru s informace pro TAB pro pravou ruku.		
		/// </summary>
		public static string tabPFileName;		
		/// <summary>
		/// Absolutn� cesta k souboru interpolator.wrl.
		/// </summary>
		public static string interpolatorFileName;
		/// <summary>
		/// Absolutn� cesta k souboru initialize.js.
		/// </summary>
		public static string initializeFileName;
		/// <summary>
		/// Absolutn� cesta k souboru initialize_default.txt.
		/// </summary>
		public static string initializeDefaultFileName;
		/// <summary>
		/// Absolutn� cesta k souboru interpolator_default.txt.
		/// </summary>
		public static string interpolatorDefaultFileName;
		/// <summary>
		/// Absolutn� cesta k souboru timer.wrl.
		/// </summary>
		public static string timerFileName;
		/// <summary>
		/// Absolutn� cesta k souboru timer_template.txt.
		/// </summary>
		public static string timerTemplateFileName;
		/// <summary>
		/// Absolutn� cesta k souboru log_model.txt
		/// </summary>
		public static string logModelFileName;
		
		/// <summary>
		/// Jm�no souboru obsahuj�c� n�zvy kloub�, kter� se pou��vaj� v reprezentaci modelu ve vrml souborech.
		/// Format:
		/// jm�no lev� ruky;jm�no prav� ruky \n
		/// jm�no ramene lev� ruky;jm�no lokte lev� ruky;...\n
		/// jm�no ramene prav� ruky;jm�no lokte prav� ruky;...\n\EOF 
		/// </summary>
		public static readonly string nameOfJointsFileNameOnly = "name_of_joint.txt";
		
		/// <summary>
		/// Jm�no souboru obsahuj�c� vektory norm�l k jendnotliv�m kloub�m.Vy�adov�ny jsou norm�ly k z�p�st� a k rameni. Norm�la z�p�st� 
		/// ur�uje sm�r dlan� ve v�choz� pozici modelu. Norm�la k rameni ur�uje sm�r bicepsu ve v�choz� pozici modelu.
		/// Form�t:
		/// 0;9;1 1.2 1\n1;6;0.2 0.3 1\n ... libovoln� po�et ��dek  \EOF,
		/// 0/1 lev�/prav� ruka,
		/// 9 ��slo kloubu,
		/// 1 1.2 1 vektor norm�ly kloubu
		/// </summary>
		public static readonly string vectorOfNormalsFileNameOnly = "normals.txt";
		
		/// <summary>
		/// Soubor obsahuj�c� sm�ry prst� modelu ve v�choz� pozici.
		/// Form�t:
		/// 1 1.2 1;0.2 1 0\n\EOF,
		/// prvn� lev� potom prav� ruka,
		/// 1 1.2 1 vektor ur�uj�c� sm�r
		/// </summary>
		public static readonly string directionOfFingerFileNameOnly ="finger_direction.txt";

		/// <summary>
		/// Jm�no souboru obsahuj�c� sm�ry orientac� ORI.
		/// Form�t:
		/// dopredu:0 0 1\n libovoln� po�et ��dek ...\EOF
		/// dopredu - Id oritentace, 0 0 1 vektor orientace
		/// </summary>
		public static readonly string directionOriFileNameOnly = "ori_direction.txt" ;
		
		/// <summary>
		/// Jm�no souboru obsahuj�c� sm�ry vz�jemn�ch poloh rukou.
		/// Form�t:
		/// dopredu:0 0 1\n libovoln� po�et ��dek ...\EOF
		/// dopredu - Id vz�jemn� polohy, 0 0 1 vektor orientace
		/// </summary>
		public static readonly string directionHaFileNameOnly = "ha_direction.txt";
		
		/// <summary>
		///Jm�no souboru obsahuj�c� relativn� vzd�lenosti jednotliv�ch kloub�. Jsou po�adov�n� v�echny vzd�lenosti kloub�
		///ve stromov� struktu�e. Rameno - loket, loket - z�p�st�, z�p�st� - ko�en mal��ku, ...
		///Form�t:
		/// 1;12;0.037 0.135 0\n libovoln� po�et ��dek ...\EOF
		/// 1 - identifik�tor ruky 0 - lev� 1 - prav�
		/// 12 - index kloubu, kter� m� relativn� vzd�lenost od kloubu o jeden stupe� n� v hierarchii
		/// 0.037 0.135 0 - vektor relativn� vzd�lenosti
		/// </summary>
		public static readonly string relativeDistanceFileNameOnly = "relative_distance.txt" ;
		
		/// <summary>
		/// Jm�no souboru obsahuj�c� informace pro n�kter� pohyby.
		/// Form�t:
		/// identifik�tor pro dat pro pohyb: data\n
		/// data - specifick� pro ka�d� typ pohybu
		/// NEBO
		/// identifik�tor: ��slo\n, tyto parametry nejsou povinn�
		/// minTimeUnit:64\n - velikost jednotky pro pohyb
		///	numberOfMoveRepeat:2\n - po�et opakov�n� pohybu
		/// partOfQuickMove:2\n - pom�r jak�m m� b�t vyd�lena d�lka a �as prudk�ho pohybu
		/// moveSpeed:1\n - velikost jedn� �asov� jednotky pohybu pro cycleTime v �asova�i

		/// </summary>
		public static readonly string moveInformationFileNameOnly = "move_info.txt" ;

		/// <summary>
		/// Jm�no souboru obsahuj�c� identifik�tory kontaktn�ch m�st. V p��pad�, �e je kontaktn� m�sto na ruce je 
		/// ur�ena relativn� vzd�lenost od nejbli���ho kloubu nad v hierarchii. V p��pad� ostatn�ch kontaktn�ch m�st je 
		/// ur�en vektor v prostoru, kter� ur�uje kontaktn� m�sto.
		/// Form�t:
		/// spickaPalce,1:17;0 0.038 0\n libovoln� po�et ��dek ...\EOF
		/// spickaPalce - identifik�tor kontaktn�ho m�sta
		/// 1 - identifik�tor na kter� ruce je kontaktn� m�sto, 0 - lev�, 1 - prav�, v p��pad� ostatn�ch kontatn�ch m�st
		/// mus� b�t -1
		/// 17 - identifikace kloubu, kter� je ve sktruktu�e nejbli�s� nad. V p��pad� �pi�ek prst� se zad�v�j� ��sla od 18 - 22,
		/// kde 18 je �pi�ka palce.
		/// 0 0.038 0 - vektor ur�uj�c� polohu kontaktn�ho m�sta
		/// </summary>
		public static readonly string coordToContactFileNameOnly = "contact_points.txt";
		
		/// <summary>
		/// Jm�no souboru ve kter�m jsou ulo�eny tvary rukou.
		/// Form�t:
		/// id:malicek;prstenicek;prostrednicek;ukazovacek;palec\n libovoln� po�et ��dek\n ...\EOF
		/// Form�t prstu:1.kloub,2.kloub,3kloub.
		/// Form�t kloubu je rotace: osaX osaY osaZ �hel.
		/// id - identifik�tor tvaru ruky
		/// </summary>
		public static readonly string dezFileNameOnly = "dez.txt";
		
		/// <summary>
		/// Jm�no souboru obsahuj�c� m�sta znakov�n� pro levou ruku.
		/// Form�t:
		/// krkL:0.593 -0.733 -0.333 1.557;0 0 1 2.815;0.15\n libovoln� po�et ��dek ... \EOF
		/// krkL - identifik�tor m�sta znakov�n�
		/// 0.593 -0.733 -0.333 1.557 - rotace, kter� m� b�t provedena na kloub ramene modelu ve v�choz� pozici
		/// 0 0 1 2.815 - rotace, kter� m� b�t provedena na kloub lokte modelu ve v�choz� pozici,
		/// osa rotace mus� b�t v�dy 0 0 1
		/// 0.15 - d�lka pohybu p��slu�n� k tomuto znakovac�mu m�stu (0.15 m)
		/// </summary>
		public static readonly string tabLFileNameOnly = "tab_left.txt";

		/// <summary>
		/// Jm�no souboru obsahuj�c� m�sta znakov�n� pro pravou ruku.
		/// Form�t:
		/// Form�t:
		/// krkL:0.863 0.467 -0.192 1.64;0 0 -1 1.971;0.15\n libovoln� po�et ��dek ... \EOF
		/// krkL - identifik�tor m�sta znakov�n�
		/// 0.863 0.467 -0.192 1.64 - rotace, kter� m� b�t provedena na kloub ramene modelu ve v�choz� pozici
		/// 0 0 -1 1.971 - rotace, kter� m� b�t provedena na kloub lokte modelu ve v�choz� pozici,
		/// osa rotace mus� b�t v�dy 0 0 -1
		/// 0.15 - d�lka pohybu p��slu�n� k tomuto znakovac�mu m�stu (0.15 m)
		/// </summary>
		public static readonly string tabPFileNameOnly = "tab_right.txt";

		/// <summary>
		/// Jm�no souboru obsahuj�c� defaultn� nastaven� modelu v p��pad�, �e v pr�b�hu v�po�tu nastane chyba.
		/// Form�t: 
		/// Odpov�d� form�tu souboru JavaScript (intitialize.js).
		/// </summary>
		public static readonly string initializeDefaultFileNameOnly = "initialize_default.txt";
		/// <summary>
		/// Jm�no souboru obsahuj�c� defaultn� nataven� modelu v p��pad�, �e v pr�b�hu v�po�tu pohyb� nastane chyba.
		/// Form�t:
		/// Odpov�d� form�tu VRML souboru (interpolator.wrl).
		/// </summary>
		public static readonly string interpolatorDefaultFileNameOnly =  "interpolator_default.txt";
		/// <summary>
		/// Jm�no souboru obsahuj�c� p�edlohu pro generov�n� souboru pro �asova� (timer.wrl).
		/// Form�t:
		/// Odpov�d� form�tu VRML s nahrazen�m d�lk� cycle intervalu a z�kladn�ho cycle intervalu za #MOVECYRCLE.
		/// </summary>
		public static readonly string timerTemplateFileNameOnly =  "timer_template.txt";
		/// <summary>
		/// Jm�no souboru do kter�ho se vypisuj� informace o chyb�ch. Je uvedena funkce ve kter� do�lo k chyb� a 
		/// v�pis popisuj�c� p���inu chyby.
		/// </summary>
		public static readonly string logModelFileNameOnly = "log_model.txt";
		/// <summary>
		/// Jm�no souboru s interpol�tory (interpolator.wrl).
		/// </summary>
		public static string interpolatorFileNameOnly;
		/// <summary>
		/// Jm�no souboru s nastaven�m statick� ��sti (initialize.js). 
		/// </summary>
		public static string initializeFileNameOnly;
		/// <summary>
		/// Jm�no souboru s daty pro �asova� (timer.wrl).
		/// </summary>
		public static string timerFileNameOnly;

		/// <summary>
		/// Objekt kter� je vr�cen funkc� generate.
		/// </summary>
		public static GenResult result;

		/// <summary>
		/// Pole kloub� lev� ruky. Uchov�v� ve�ker� informace, kter� jsou pot�ebn� ke ka�d�mu kloubu.
		/// </summary>
		public static Joint[] leftHand; 
		/// <summary>
		/// Pole kloub� prav� ruky. Uchov�v� ve�ker� informace, kter� jsou pot�ebn� ke ka�d�mu kloubu.
		/// </summary>
		public static Joint[] rightHand; 
		/// <summary>
		/// Ur�uje po�et kloub�, kter� jsou obsa�eny v jedn� ruce.
		/// </summaryo
		public const int numberJointHand = 18; 
		/// <summary>
		/// Povolen� odchylka.
		/// </summary>
		public const double difference = 0.001;
		/// <summary>
		/// Maxim�ln� velikost pohybu, kter� se nem� prov�d�t.
		/// </summary>
		public const double moveEpsilon = 0.01; // 1cm ve sc�n�
		/// <summary>
		/// Maxim�ln� po�et vektor�, kter�mi m��e b�t v souboru pops�n kruhov� pohyb.
		/// </summary>
		public const int maxPolygonVertex = 50;
		/// <summary>
		/// D�lka hrany polygonu,kter�m je pops�n kruhov� pohyb.
		/// </summary>
		public const double lengthOfEdgeInPolygon = 1; 
		/// <summary>
		/// Defaultn� hodnota �hlu pro m�v�n�.
		/// </summary>
		public const double waveAngle = 0.35; //cca 30�
		/// <summary>
		/// Jm�ho prototypu prav� ruky ve VRML souboru popisuj�c� t�lo modelu. 
		/// Jm�no je na��t�no ze souboru name_of_joint.txt , aby bylo mo�n� po��vat r�zn� modely.
		/// </summary>
		public static String nameRighthandVrml;
		/// <summary>
		/// Jm�ho prototypu lev� ruky ve VRML souboru popisuj�c� t�lo znakovac�ho pan��ka. 
		/// Jm�no je na��t�no ze souboru name_of_joint.txt , aby bylo mo�n� po��vat r�zn� modely.
		/// </summary>
		public static String nameLefthandVrml; 
		/// <summary>
		/// Sm�r(vzhledem ke sv�tu) prst� lev� ruky modelu v pozici, ve kter� je navr�en ve VRML sv�t�		
		/// Sm�r je na��t�n ze souboru normals.txt , aby bylo mo�n� po��vat r�zn� modely.
		/// </summary>
		public static Joint.Vector dirFingerLeft;
		/// <summary>
		/// Sm�r(vzhledem ke sv�tu) prst� prav� ruky modelu v pozici, ve kter� je navr�en ve VRML sv�t�.
		/// Sm�r je na��t�n ze souboru normals.txt , aby bylo mo�n� po��vat r�zn� modely.
		/// </summary>
		public static Joint.Vector dirFingerRight;
		/// <summary>
		/// Sm�r(vzhledem ke sv�tu) dlan� lev� ruky modelu v pozici, ve kter� je narv�en ve VRML sv�t�.
		/// Sm�r je na��t�n ze souboru normals.txt , aby bylo mo�n� po��vat r�zn� modely.
		/// </summary>
		public static Joint.Vector dirNormalLeft; 
		/// <summary>
		/// Sm�r(vzhledem ke sv�tu) dlan� prav� ruky modelu v pozici, ve kter� je narv�en ve VRML sv�t�.
		/// Sm�r je na��t�n ze souboru normals.txt , aby bylo mo�n� po��vat r�zn� modely.
		/// </summary>
		public static Joint.Vector dirNormalRight; 
		/// <summary>
		/// Prostor, pro levou ruku, ve kter�m se znak znakuje. 
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string tabL;
		/// <summary>
		/// D�lka pohybu pro na�ten� znakovac� m�sto. Tato informace je z�sk�na ze souboru tab_left.txt.
		/// </summary>
		public static double tabLLengthOfMove;
		/// <summary>
		/// Prostor, pro pravou ruku, ve kter�m se znak znakuje.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string tabR;
		/// <summary>
		/// D�lka pohybu pro na�ten� znakovac� m�sto. Tato informace je z�sk�na ze souboru tab_right.txt.
		/// </summary>
		public static double tabRLengthOfMove;
		/// <summary>
		/// Orientace(vzhledem ke sv�tu) dlan� lev� ruky na za��tku p�edv�d�n� znaku.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string ori1L;
		/// <summary>
		/// Orientace(vzhledem ke sv�tu) dlan� prav� ruky na za��tku p�edv�d�n� znaku.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string ori1R;
		/// <summary>
		/// Orientace(vzhledem ke sv�tu) prst� lev� ruky na za��tku p�edv�d�n� znaku.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string ori2L;
		/// <summary>
		/// Orientace(vzhledem ke sv�tu) prst� prav� ruky na za��tku p�edv�d�n� znaku.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string ori2R;
		/// <summary>
		/// Tvar lev� ruky na za��tku p�edv�d�n� znaku.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string dezL;
		/// <summary>
		/// Tvar prav� ruky na za��tku p�edv�d�n� znaku.
		/// Informace je na na��t�na z notace.
		/// </summary>
		public static string dezR;
		/// <summary>
		/// Jednotka pro jeden atomick� pohyb.
		/// </summary>
		public static int minTimeUnit = 64; // jednotka pro zakladni pohyb nemodifikovany
		/// <summary>
		/// Po�et opakov�n� pohybu, kter� m� indentifik�tor opakovan� pohyb.
		/// </summary>
		public static int numberOfMoveRepeat = 2; // kolikrat se bude pohyb opakovat pokub bude opakovany
		/// <summary>
		/// Kolikr�t se zkr�t� �as, pokud m� pohyb modifik�tor prudk� pohyb.
		/// </summary>
		public static int partOfQuickMove = 2; 
		/// <summary>
		/// Po�et jednotek cel�ho pohybu lev� ruky.
		/// </summary>
		public static int cyrcleTimeL = 0; 
		/// <summary>
		/// Po�et jednotek celoho pohybu prav� ruky.
		/// </summary>
		public static int cyrcleTimeP = 0;
		/// <summary>
		/// Velikost cyrcleUnit (d�lka jednoho cyklu animace) v souboru timer.wrl.
		/// </summary>
		public static double cyrcleUnit = 1.0/(double)minTimeUnit;
		/// <summary>
		/// P��znak zapisov�n� do logu.
		/// </summary>
		public static bool loggerEnabled = true;
		/// <summary>
		/// D�lka jednoho cyklu, kter� je vr�cena v objektu funkc� generate.
		/// </summary>
		public static double moveTime = cyrcleUnit;
		/// <summary>
		/// Typ pohybu, ax, b1 nebo b2. Na��t�no z notace. 
		/// </summary>
		public static string typeOfSign;
		/// <summary>
		/// Vz�jemn� poloha rukou. Na��t�no z notace.
		/// </summary>
		public static string ha;
		/// <summary>
		/// Vzd�lenosti �pi�ek prst� obou rukou, na��t�no ze souboru relative_distance.txt.
		/// </summary>
		public static Joint.Vector[][] fingerTipDistance;
		/// <summary>
		/// Kopie kontaktu lev� ruky pro pulkruhov� pohyb.
		/// </summary>
		public static  Notation.SIG.KKdeTelo circleContactL = null;
		/// <summary>
		/// Kopie kontaktu prav� ruky pro pulkruhov� pohyb.
		/// </summary>
		public static  Notation.SIG.KKdeTelo circleContactP = null;
		/// <summary>
		/// Inicializace jednotliv�ch kloub�. Napln�n� pol� n�sledn�k� a p�edk�.
		/// </summary>
		static public void inicializeJoints() 
		{
			leftHand = initializeHandJoints();
			rightHand = initializeHandJoints();

			dirFingerLeft = new Joint.Vector();
			dirFingerRight = new Joint.Vector();
			dirNormalLeft = new Joint.Vector();
			dirNormalRight = new Joint.Vector();

			fingerTipDistance = new Joint.Vector[2][];
			fingerTipDistance[0] = new Joint.Vector[5];
			fingerTipDistance[1] = new Joint.Vector[5];
		}
		static public Joint[] initializeHandJoints() {
			Joint[] hand = new Joint[numberJointHand];

			// lev� ruka
			// velikost pro n�sledn�ky kloubu
			hand[0] = new Joint(17,0); // rameno
			hand[1] = new Joint(16,1); // loket
			hand[2] = new Joint(15,2); // zapesti            
			hand[3] = new Joint(2,3); // mal1
			hand[4] = new Joint(1,4); // mal2 
			hand[5] = new Joint(0,5); // mal3
			hand[6] = new Joint(2,3); //prst1
			hand[7] = new Joint(1,4); //prst2
			hand[8] = new Joint(0,5); //prst3
			hand[9] = new Joint(2,3); //prost1
			hand[10] = new Joint(1,4); //prost2
			hand[11] = new Joint(0,5); // prost3
			hand[12] = new Joint(2,3); // ukaz1
			hand[13] = new Joint(1,4); //ukaz2
			hand[14] = new Joint(0,5); //ukaz3
			hand[15] = new Joint(2,3); // palec1
			hand[16] = new Joint(1,4); //palec2
			hand[17] = new Joint(0,5); //palec3 

			// nastavit ukazatele na syny
			//uzly od ramene
			hand[0].listOfChild[0] = hand[1];
			hand[0].listOfChild[1] = hand[2];
			hand[0].listOfChild[2] = hand[3];
			hand[0].listOfChild[3] = hand[4];
			hand[0].listOfChild[4] = hand[5];
			hand[0].listOfChild[5] = hand[6];
			hand[0].listOfChild[6] = hand[7];
			hand[0].listOfChild[7] = hand[8];
			hand[0].listOfChild[8] = hand[9];
			hand[0].listOfChild[9] = hand[10];
			hand[0].listOfChild[10] = hand[11];
			hand[0].listOfChild[11] = hand[12];
			hand[0].listOfChild[12] = hand[13];
			hand[0].listOfChild[13] = hand[14];
			hand[0].listOfChild[14] = hand[15];
			hand[0].listOfChild[15] = hand[16];
			hand[0].listOfChild[16] = hand[17];
			// p�edkov� nejsou
                         
			//uzly od lokte
			hand[1].listOfChild[0] = hand[2];
			hand[1].listOfChild[1] = hand[3];
			hand[1].listOfChild[2] = hand[4];
			hand[1].listOfChild[3] = hand[5];
			hand[1].listOfChild[4] = hand[6];
			hand[1].listOfChild[5] = hand[7];
			hand[1].listOfChild[6] = hand[8];
			hand[1].listOfChild[7] = hand[9];
			hand[1].listOfChild[8] = hand[10];
			hand[1].listOfChild[9] = hand[11];
			hand[1].listOfChild[10] = hand[12];
			hand[1].listOfChild[11] = hand[13];
			hand[1].listOfChild[12] = hand[14];
			hand[1].listOfChild[13] = hand[15];
			hand[1].listOfChild[14] = hand[16];
			hand[1].listOfChild[15] = hand[17];
			//p�edkov�
			hand[1].listOfParent[0] = hand[0];

			// uzly od z�p�st�
			hand[2].listOfChild[0] = hand[3];
			hand[2].listOfChild[1] = hand[4];
			hand[2].listOfChild[2] = hand[5];
			hand[2].listOfChild[3] = hand[6];
			hand[2].listOfChild[4] = hand[7];
			hand[2].listOfChild[5] = hand[8];
			hand[2].listOfChild[6] = hand[9];
			hand[2].listOfChild[7] = hand[10];
			hand[2].listOfChild[8] = hand[11];
			hand[2].listOfChild[9] = hand[12];
			hand[2].listOfChild[10] = hand[13];
			hand[2].listOfChild[11] = hand[14];
			hand[2].listOfChild[12] = hand[15];
			hand[2].listOfChild[13] = hand[16];
			hand[2].listOfChild[14] = hand[17];
			//p�edkov�
			hand[2].listOfParent[0] = hand[1];
			hand[2].listOfParent[1] = hand[0];

			//mal��ek
			hand[3].listOfChild[0] = hand[4];
			hand[3].listOfChild[1] = hand[5];
			hand[4].listOfChild[0] = hand[5];
			//p�edkov�            
			hand[3].listOfParent[0] = hand[2];
			hand[3].listOfParent[1] = hand[1];
			hand[3].listOfParent[2] = hand[0];

			hand[4].listOfParent[0] = hand[3];
			hand[4].listOfParent[1] = hand[2]; 
			hand[4].listOfParent[2] = hand[1];
			hand[4].listOfParent[3] = hand[0];

			hand[5].listOfParent[0] = hand[4];
			hand[5].listOfParent[1] = hand[3];
			hand[5].listOfParent[2] = hand[2];
			hand[5].listOfParent[3] = hand[1];
			hand[5].listOfParent[4] = hand[0]; 

			//prsten��ek
			hand[6].listOfChild[0] = hand[7];
			hand[6].listOfChild[1] = hand[8];
			hand[7].listOfChild[0] = hand[8];
			//p�edkov�
			hand[6].listOfParent[0] = hand[2];
			hand[6].listOfParent[1] = hand[1];
			hand[6].listOfParent[2] = hand[0];

			hand[7].listOfParent[0] = hand[6];
			hand[7].listOfParent[1] = hand[2];
			hand[7].listOfParent[2] = hand[1];
			hand[7].listOfParent[3] = hand[0];

			hand[8].listOfParent[0] = hand[7];
			hand[8].listOfParent[1] = hand[6];
			hand[8].listOfParent[2] = hand[2];
			hand[8].listOfParent[3] = hand[1];
			hand[8].listOfParent[4] = hand[0]; 
            
			//prost�edn��ek
			hand[9].listOfChild[0] = hand[10];
			hand[9].listOfChild[1] = hand[11];
			hand[10].listOfChild[0] = hand[11];
			// p�edkov�
			hand[9].listOfParent[0] = hand[2];
			hand[9].listOfParent[1] = hand[1];
			hand[9].listOfParent[2] = hand[0];

			hand[10].listOfParent[0] = hand[9];
			hand[10].listOfParent[1] = hand[2];
			hand[10].listOfParent[2] = hand[1];
			hand[10].listOfParent[3] = hand[0];

			hand[11].listOfParent[0] = hand[10];
			hand[11].listOfParent[1] = hand[9];
			hand[11].listOfParent[2] = hand[2];
			hand[11].listOfParent[3] = hand[1];
			hand[11].listOfParent[4] = hand[0]; 

			//ukazov��ek
			hand[12].listOfChild[0] = hand[13];
			hand[12].listOfChild[1] = hand[14];
			hand[13].listOfChild[0] = hand[14];

			//p�edkov�
			hand[12].listOfParent[0] = hand[2];
			hand[12].listOfParent[1] = hand[1];
			hand[12].listOfParent[2] = hand[0];

			hand[13].listOfParent[0] = hand[12];
			hand[13].listOfParent[1] = hand[2];
			hand[13].listOfParent[2] = hand[1];
			hand[13].listOfParent[3] = hand[0];

			hand[14].listOfParent[0] = hand[13];
			hand[14].listOfParent[1] = hand[12];
			hand[14].listOfParent[2] = hand[2];
			hand[14].listOfParent[3] = hand[1];
			hand[14].listOfParent[4] = hand[0]; 

			//palec
			hand[15].listOfChild[0] = hand[16];
			hand[15].listOfChild[1] = hand[17];
			hand[16].listOfChild[0] = hand[17];
			//p�edkov� 
			hand[15].listOfParent[0] = hand[2];
			hand[15].listOfParent[1] = hand[1];
			hand[15].listOfParent[2] = hand[0];

			hand[16].listOfParent[0] = hand[15];
			hand[16].listOfParent[1] = hand[2];
			hand[16].listOfParent[2] = hand[1];
			hand[16].listOfParent[3] = hand[0];

			hand[17].listOfParent[0] = hand[16];
			hand[17].listOfParent[1] = hand[15];
			hand[17].listOfParent[2] = hand[2];
			hand[17].listOfParent[3] = hand[1];
			hand[17].listOfParent[4] = hand[0];

			return hand;
		}

		/// <summary>
		/// V souboru, zadan�m prom�nnou directionOriFileName, nalezne hodnotu vektoru, zadan�ho v parametru vektor.
		/// </summary>
		/// <param name="vector">�et�zec hledan�ho vektoru.</param>
		/// <param name="vectorToCompare">Hodnota vektoru nalezen� v souboru.</param>
		static public void findVectorToCompareInOriFile(string vector,ref Joint.Vector vectorToCompare)
		{
			int findId = -1;
			FileStream fileFrom = null;
			StreamReader sr = null;
			string input;
			string output= "";
			int result;
			string[] splittedVect;

			try
			{
				fileFrom = new FileStream(directionOriFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fileFrom);
            
				while ((input = sr.ReadLine()) != null)
				{
					result = findIdInInput(directionOriFileName,vector,input,ref output);
					if (result == 0)
					{
						//p��znak nalezen� id v souboru
						findId = 0;
						splittedVect = output.Split(' ');
						if(splittedVect.Length != 3)
							throw new GenException.UsingFileException("Data k hledan� vektoru" + vector + "jsou v souboru " + directionOriFileName + "po�kozena.",directionOriFileName);
						else
						{
							vectorToCompare.x = Double.Parse(splittedVect[0]);
							vectorToCompare.y = Double.Parse(splittedVect[1]);
							vectorToCompare.z = Double.Parse(splittedVect[2]);
						}
						break;
					}
				}
				//id v souboru nebylo nalezeno
				if (findId == -1)
					throw new GenException.UsingFileException("Id vektoru " + vector + "nebylo v souboru " + directionOriFileName + "nalezeno.",directionOriFileName);          														
				
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fileFrom!= null)
					fileFrom.Close();
			}			
		}
		/// <summary>
		/// V souboru, zadan�m v prom�nn� directionOriFileName, najde v�echny vektory, kter� jsou v z�vislosti na parametru action,
		/// kolm� nebo nekolm�. 
		/// </summary>
		/// <param name="vectorToCompare">Vektor, ke kter�mu jsou v souboru, hled�ny p��slu�n� vektory.</param>
		/// <param name="list">Seznam nalezen�ch vektor�.</param>
		/// <param name="action">0 - Nalezen� v�ech vektor�, kter� k dan�mu nejsou kolm�, 1 - Nalezen� v�ech vektor�, kter� k dan�mu jsou kolm�. </param>
		static public void compareVectorsInOriFile(Joint.Vector vectorToCompare,ref System.Collections.ArrayList list, int action)
		{
			FileStream fileFrom = null;
			StreamReader sr = null;
			string input;
			string[] splittedVect;
			string[] splittedOutput;
			Joint.Vector vectorFromFile = new Joint.Vector();
			bool isOrthogonal;

			try
			{
				fileFrom = new FileStream(directionOriFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fileFrom);
            
				while ((input = sr.ReadLine()) != null)
				{		
					splittedOutput = input.Split(':');
					if(splittedOutput.Length == 2)
					{
						splittedVect = splittedOutput[1].Split(' ');
						if(splittedVect.Length == 3)
						{
							vectorFromFile.x = Double.Parse(splittedVect[0]);
							vectorFromFile.y = Double.Parse(splittedVect[1]);
							vectorFromFile.z = Double.Parse(splittedVect[2]);
							// nejsou kolme
							isOrthogonal = checkNormalVectToVect(vectorFromFile,vectorToCompare);

							if((!isOrthogonal) && (action == 0))
							{
								list.Add(splittedOutput[0]);
							}
							else if((isOrthogonal) && (action == 1))
							{
								if(splittedOutput[0].CompareTo("nic") != 0)
								{
									list.Add(splittedOutput[0]);
									break;
								}
							}
						}
					}
				}			
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fileFrom!= null)
					fileFrom.Close();
			}			

		}

		/// <summary>
		/// V souboru, kde jsou ulo�eny vektory ur�uj�c� ORI nalezne v�echny vektory, kter� nejsou kolm� k vektoru
		/// zadan�mu v parametru. V p�ipad�, �e je parametr vektor pr�zdn� �et�zec nebo nic, je vr�cen pr�zdn� seznam.
		/// </summary>
		/// <param name="vector">Vektor, k n�mu� hled�m� kolm� vektor ur�uj�c� ORI.</param>
		/// <param name="result">Seznam kolm�ch vektor�.</param>
		/// <param name="action">0 je nalezen� v�ech vektor�, kter� nejsou kolm� k vektoru v parametru vector
		/// 1 je nalezen� prvn�ho vektoru, kter� je kolm� k vektoru zadan�m v parametru vector.</param>
		static public void findNonOrthogonalVectorsInOriFile(string vector, ref System.Collections.ArrayList result, int action)
		{
			if((vector == null) || (result == null) || ((action != 1) && (action != 0)))
				throw new GenException.ParameterException("Funkce pro nalezen� kolm�ch vektor� selhala.");

			Joint.Vector vectorToCompare = new Joint.Vector();
			result.Clear();

			if((vector.CompareTo("") == 0) || (vector.CompareTo("nic") == 0))
				return;
			else
				findVectorToCompareInOriFile(vector, ref vectorToCompare);

			compareVectorsInOriFile(vectorToCompare, ref result,action);
		}

		/// <summary>
		/// Vytvo�� soubory intialize.js a interpolator.wrl z defaultn�ch soubor�. 
		/// </summary>
		/// <param name="initialize">P��znak, zda se m� tento soubor vytv��et. 1 znamen� vytvo�it.</param>
		/// <param name="interpolator">P��znak, zda se m� tento soubor vytv��et. 1 znamen� vytvo�it.</param>
		static public void copyDefaultInitializeAndInterpolator(int initialize, int interpolator)
		{
			string inputLine;
			FileStream fileFrom = null;
			StreamReader sr = null;
			FileStream fileTo = null;
			StreamWriter sw = null;

			if(initialize == 1)
			{
				try
				{
					fileTo = new FileStream(initializeFileName, FileMode.Create, FileAccess.Write);
					fileFrom = new FileStream(initializeDefaultFileName, FileMode.Open, FileAccess.Read);
					sw = new StreamWriter(fileTo);
					sr = new StreamReader(fileFrom);
            
					while ((inputLine = sr.ReadLine()) != null)
					{
						sw.WriteLine(inputLine);		
					}				
				
				}
				finally
				{
					if(sr != null)
						sr.Close();
					if(fileFrom!= null)
						fileFrom.Close();
					if(sw != null)
						sw.Close();
					if(fileTo != null)
						fileTo.Close();

				}
			}
			if(interpolator == 1)
			{
				try
				{
					fileTo = new FileStream(interpolatorFileName, FileMode.Create, FileAccess.Write);
					fileFrom = new FileStream(interpolatorDefaultFileName, FileMode.Open, FileAccess.Read);
					sw = new StreamWriter(fileTo);
					sr = new StreamReader(fileFrom);
        
					while ((inputLine = sr.ReadLine()) != null)
					{
						sw.WriteLine(inputLine);		
					}				
			
				}
				finally
				{
					if(sr != null)
						sr.Close();
					if(fileFrom!= null)
						fileFrom.Close();
					if(sw != null)
						sw.Close();
					if(fileTo != null)
						fileTo.Close();

				}

			}			
		}
		/// <summary>
		/// Na�ten� jmen, ze souboru zadan�m v prom�nn� nameOfJointsFileName, prototyp� rukou a jmen jednotliv�ch kloub� modelu.Tyto jm�na jsou pou��v�na ve VRML souborech 
		/// modelu. 
		/// </summary>
		/// <exception cref="GenException.UsingFileException">�patn� po�et jmen rukou v souboru.</exception>
		/// <exception cref="GenException.UsingFileException">�patn� po�et jmen kloub� lev� ruky v souboru.</exception>
		/// <exception cref="GenException.UsingFileException">�patn� po�et jmen kloub� prav� ruky v souboru.</exception>

		static public void inicializeNameJoints() 
		{
			int i;
			string inputName;
			string[] splittedLine;
			FileStream file = null;
			StreamReader sr = null;

			try
			{

				file = new FileStream(nameOfJointsFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(file);
			
				// na�ten� n�zvu rukou
				inputName = sr. ReadLine();
				splittedLine = inputName.Split(';');
				if (splittedLine.Length != 2)
				{  
					throw new GenException.UsingFileException("�patn� po�et jmen rukou v souboru.",nameOfJointsFileName);
				}
				//ulo�en� n�zvu rukou
				nameLefthandVrml = splittedLine[0]; 
				nameRighthandVrml = splittedLine[1];
        
				//n�zvy kloub� lev� ruky
				inputName = sr.ReadLine();
				splittedLine = inputName.Split(';');
				if (splittedLine.Length != numberJointHand)
				{
					throw new GenException.UsingFileException("�patn� po�et jmen kloub� lev� ruky v souboru.",nameOfJointsFileName);
				}
				//ulo�en� n�zv� kloub� lev� ruky
				for (i = 0; i < numberJointHand; i++) 
				{
					leftHand[i].nameOfJoint = splittedLine[i].Substring(0);
				}

				//n�zvy kloub� prav� ruky
				inputName = sr.ReadLine();
				splittedLine = inputName.Split(';');
				if (splittedLine.Length != numberJointHand) 
				{
					throw new GenException.UsingFileException("�patn� po�et jmen kloub� prav� ruky v souboru.");
				}
				//ulo�en� n�zv� kloub� prav� ruky
				for (i = 0; i < numberJointHand; i++)
				{
					rightHand[i].nameOfJoint = splittedLine[i].Substring(0);
				}
			}
			finally 
			{
				if(sr != null)
					sr.Close();
				if(file!= null)
					file.Close();
			}

		}


		/// <summary>
		/// Na�ten� norm�l nebo relativn�ch vzd�lenost� k p�edku k jednotliv�m kloub�m. Norm�ly jsou vzhledem k VRML sv�tu. Na�tou se ty norm�ly jejich� po�adov� ��slo odpov�d� n�kter�mu z kloub�.
		/// V�znam a pou�it� norm�l se li�� v z�vislosti na kloubu.
		/// Norm�la k z�p�st� slou�� jako po��te�n� sm�r dlan� modelu.
		/// Relativn� vzd�lenost slou�� k ur�en� polohy rukou ve VRML sv�t� v pr�b�hu v�po�t�.
		/// </summary>
		/// <param name="filePath">Cesta k pou��van�mu souboru.</param>
		/// <param name="action">0 - na�ten� norm�l ke kloub�m, 1 - na�ten� relativn�ch vzd�lenost� kloub�</param>
		/// <exception cref="GenException.UsingFileException">Po�et polo�ek ��dky souboru neodpov�d�.</exception>
		/// <exception cref="GenException.UsingFileException">Ozna�en� pro pravou nebo levou ruku v souboru neodpov�d� jedn� z po�adovan�ch hodnot 0 nebo 1.</exception>
		/// <exception cref="GenException.UsingFileException">��slo kloubu v souboru neodpov�d� ��dn�mu z mo�n�ch kloub�, tedy rozmez� hodnot 0 az 17.</exception>
		/// <exception cref="GenException.UsingFileException">Po�et os vektoru v souboru neodpov�d� 3.</exception>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		static public void inicializeNormalsOrDistance(string filePath, int action) 
		{

			string inputNormal;
			string[] splittedLine;
			string[] splittedVect;			

			if((filePath == null) || ((action != 1) && (action != 0)))
				throw new GenException.ParameterException("filePath: " + (filePath == null ? "NULL":filePath) + ", " + "action: " + action.ToString());
			
			FileStream fs = null;
			StreamReader sr = null;

			try
			{
				fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);

				while ((inputNormal = sr.ReadLine()) != null)
				{
				
					splittedLine = inputNormal.Split(';');

					if (splittedLine.Length != 3)
						throw new GenException.UsingFileException("Po�et polo�ek na ��dce v souboru neodpov�d�.",filePath);

					if (Int32.Parse(splittedLine[0]) != 0 && Int32.Parse(splittedLine[0]) != 1)
						throw new GenException.UsingFileException("Ozna�en� pro pravou nebo levou ruku v souboru neodpov�d� jedn� z po�adovan�ch hodnot 0 nebo 1.",filePath);

					if (Int32.Parse(splittedLine[1]) < 0 || Int32.Parse(splittedLine[1]) > 22)
						throw new GenException.UsingFileException("��slo kloubu v souboru neodpov�d� ��dn�mu z mo�n�ch kloub�, tedy rozmez� hodnot 0 az 17.",filePath);

					splittedVect = splittedLine[2].Split(' ');

					if (splittedVect.Length != 3)
						throw new GenException.UsingFileException("Po�et os vektoru v souboru neodpov�d� 3.",filePath);

                
					//ulo�en� na�ten� norm�ly
					if(action == 0)
					{

						if (Int32.Parse(splittedLine[0]) == 0)
						{
							leftHand[Int32.Parse(splittedLine[1])].normal.x = Double.Parse(splittedVect[0]);
							leftHand[Int32.Parse(splittedLine[1])].normal.y = Double.Parse(splittedVect[1]);
							leftHand[Int32.Parse(splittedLine[1])].normal.z = Double.Parse(splittedVect[2]);
							leftHand[Int32.Parse(splittedLine[1])].normal.checkNullVector();
						}
						else 
						{
							rightHand[Int32.Parse(splittedLine[1])].normal.x = Double.Parse(splittedVect[0]);
							rightHand[Int32.Parse(splittedLine[1])].normal.y = Double.Parse(splittedVect[1]);
							rightHand[Int32.Parse(splittedLine[1])].normal.z = Double.Parse(splittedVect[2]);
							rightHand[Int32.Parse(splittedLine[1])].normal.checkNullVector();
						}
					}
						// ulo�en� na�ten�ch vzd�lenost�
					else if(action == 1)
					{   
						// relativni vzdalenost kloubu
						if(Int32.Parse(splittedLine[1]) < 18)
						{
							if(Int32.Parse(splittedLine[0]) == 0)
							{
								leftHand[Int32.Parse(splittedLine[1])].relativeDistance.x = Double.Parse(splittedVect[0]);
								leftHand[Int32.Parse(splittedLine[1])].relativeDistance.y = Double.Parse(splittedVect[1]);
								leftHand[Int32.Parse(splittedLine[1])].relativeDistance.z = Double.Parse(splittedVect[2]);
							}
							else
							{
								rightHand[Int32.Parse(splittedLine[1])].relativeDistance.x = Double.Parse(splittedVect[0]);
								rightHand[Int32.Parse(splittedLine[1])].relativeDistance.y = Double.Parse(splittedVect[1]);
								rightHand[Int32.Parse(splittedLine[1])].relativeDistance.z = Double.Parse(splittedVect[2]);
							}
						}
						else
						{
							switch(Int32.Parse(splittedLine[1]))
							{
								case 18: fingerTipDistance[Int32.Parse(splittedLine[0])][0] = new Joint.Vector(Double.Parse(splittedVect[0]),Double.Parse(splittedVect[1]),Double.Parse(splittedVect[2]));
									break;
								case 19: fingerTipDistance[Int32.Parse(splittedLine[0])][1] = new Joint.Vector(Double.Parse(splittedVect[0]),Double.Parse(splittedVect[1]),Double.Parse(splittedVect[2]));
									break;
								case 20: fingerTipDistance[Int32.Parse(splittedLine[0])][2] = new Joint.Vector(Double.Parse(splittedVect[0]),Double.Parse(splittedVect[1]),Double.Parse(splittedVect[2]));
									break;
								case 21: fingerTipDistance[Int32.Parse(splittedLine[0])][3] = new Joint.Vector(Double.Parse(splittedVect[0]),Double.Parse(splittedVect[1]),Double.Parse(splittedVect[2]));
									break;
								case 22: fingerTipDistance[Int32.Parse(splittedLine[0])][4] = new Joint.Vector(Double.Parse(splittedVect[0]),Double.Parse(splittedVect[1]),Double.Parse(splittedVect[2]));
									break;
								default:
									throw new GenException.UsingFileException("Id �pi�ky prstu v souboru je �patn� zadan�.",filePath);
							}
						}
					}
				}
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();
			}
		
		}

		/// <summary>
		/// Na�ten� sm�ru prst� u modelu v pozici, ve kter� je pops�n ve VRML souboru.
		/// Sm�ry jsou vzhledem k VRML sv�tu. Jm�no souboru je ulo�eno v prom�nn� directionOfFingerFileName.
		/// </summary>
		/// <exception cref="GenException.UsingFileException">Po�et polo�ek v souboru neodpov�d� po�tu 2.</exception>
		/// <exception cref="GenException.UsingFileException">Po�et os vektoru v souboru neodpov�d� osaX osaY osaZ.</exception>
		static public void inicializeDirFinger() 
		{ 
            
			string inputDirect;
			string[] splittedLine;
			string[] splittedDir;
			
			FileStream fs = null;
			StreamReader sr = null;
			
			try
			{

				fs = new FileStream(directionOfFingerFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);

				inputDirect = sr.ReadLine();
				splittedLine = inputDirect.Split(';');

				if (splittedLine.Length != 2)
					throw new GenException.UsingFileException("Po�et polo�ek v souboru neodpov�d� 2!",directionOfFingerFileName);

				splittedDir = splittedLine[0].Split(' ');
				if (splittedDir.Length != 3)
					throw new GenException.UsingFileException("Po�et os vektoru v souboru neodpov�d� 3.",directionOfFingerFileName);

				// ulo�en� sm�ru prst� lev� ruky
				dirFingerLeft.x = Double.Parse(splittedDir[0]);
				dirFingerLeft.y = Double.Parse(splittedDir[1]);
				dirFingerLeft.z = Double.Parse(splittedDir[2]);
				dirFingerLeft.checkNullVector();

				splittedDir = splittedLine[1].Split(' ');
				if (splittedDir.Length != 3)
					throw new GenException.UsingFileException("Po�et os vektoru v souboru neodpov�d� 3.",directionOfFingerFileName);

				// ulo�en� sm�ru prst� prav� ruky
				dirFingerRight.x = Double.Parse(splittedDir[0]);
				dirFingerRight.y = Double.Parse(splittedDir[1]);
				dirFingerRight.z = Double.Parse(splittedDir[2]);
				dirFingerRight.checkNullVector();
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();
			}
		}

		/// <summary>
		/// V�po�et rotace vektoru zadan�ho v parametru, tak aby po rotaci bylo dosa�eno vektoru, kter� je tak� zad�n v parametru.
		/// V�po�et se skl�d� za dvou krok�. Prvn� je v�po�et osy rotace a druh� je v�po�et velikosti �hlu o kter� se zadan� vektor zarotovat.
		/// Osa rotace se spo��t� jako vektorov� sou�in p�vodn�ho a zarotovan�ho vektoru.
		/// �hel se spo��t� pomoc� vzorce pro v�po�et �hlu mezi dv�ma vektory.
		/// </summary>
		/// <param name="rotateNormal">P�vodn� vektor, kter� se m� rotovat.</param>
		/// <param name="destVector">Kone�n� vektor po zarotov�n�.</param>
		/// <param name="finalRotation">Rotace popsan� osou a �hlem.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="GenException.ComputingException">V�echny t�i osy p�vodn�ho vektoru jsou rovny nule.</exception>
		static public void getRotationVectorVector(Joint.Vector rotateNormal, Joint.Vector destVector, ref Joint.Rotation finalRotation)
		{

			if((rotateNormal == null) || (destVector == null) || (finalRotation == null))
				throw new GenException.ParameterException("rotateNormal: " + (rotateNormal == null ? "NULL":rotateNormal.ToString()) + ", " + 
					"destVector: " + (destVector == null ? "NULL":destVector.ToString()) + ", "  + 
					"finalRotation: " + (finalRotation == null ? "NULL":finalRotation.ToString()));
			
			// spo�ten� velikosti �hlu mezi vektory
			double cosAlfa = (rotateNormal.x * destVector.x + rotateNormal.y * destVector.y + rotateNormal.z * destVector.z) /
				(Math.Sqrt((rotateNormal.x*rotateNormal.x + rotateNormal.y*rotateNormal.y + rotateNormal.z*rotateNormal.z)*
				(destVector.x * destVector.x + destVector.y * destVector.y + destVector.z * destVector.z)));         

			// �hel mezi vektory
			finalRotation.angle = Math.Acos(moveGenerator.checkAngleRange(cosAlfa));
            
			// spo�teni vektoru kolm�ho na oba vektory, tedy osa ot��en�
			if (cosAlfa != -1)
			{
				if (cosAlfa == 1) // �hel je nulov� nez�le�� na os�ch, je nutn� ale aby nebyly nulov�
					finalRotation.x = 1;
				else 
					finalRotation.x = rotateNormal.y * destVector.z - rotateNormal.z * destVector.y;

				finalRotation.y = rotateNormal.z * destVector.x - rotateNormal.x * destVector.z;
				finalRotation.z = rotateNormal.x * destVector.y - rotateNormal.y * destVector.x;

			}
				/* jestli�e cos �hlu je -1 pak se jedn� o rotaci o 180�,tedy p�vodn� a zarotovan� vektor le�� v jedn� p��mce
				 * Je vytvo�en n�hodn� vektor D, kter� je kolm� k t�to p��mce. Je zvolen jako osa rotace.
				 */
			else  
			{
				if (rotateNormal.z != 0)
				{
					finalRotation.x = 1;
					finalRotation.y = 1;
					finalRotation.z = -1 * (rotateNormal.x + rotateNormal.y) / rotateNormal.z;
				}
				else if (rotateNormal.y != 0)
				{
					finalRotation.x = 1;
					finalRotation.y = -1 * (rotateNormal.x + rotateNormal.z) / rotateNormal.y;
					finalRotation.z = 1;
				}
				else if (rotateNormal.x != 0)
				{
					finalRotation.x = -1 * (rotateNormal.y + rotateNormal.z) / rotateNormal.x;
					finalRotation.y = 1;
					finalRotation.z = 1;
				}
				else
					throw new GenException.ComputingException("V�echny t�i osy p�vodn�ho vektoru jsou rovny nule.");

				finalRotation.normalize();
			}
		}

		/// <summary>
		/// Na�ten� vektoru, kter� ur�uje osu rotace, pro kloub� u pohybu t�epot�n�.
		/// </summary>
		/// <param name="flag">Pro kterou ruku se maj� data na��st. 0 - lev�, 1 - prav�.</param>
		/// <param name="axis">Vektor, kter� byl v souboru nalezen.</param>
		static public void getFlapRotFromFile(int flag, ref Joint.Vector axis)
		{
			if(((flag != 0) && (flag != 1)) || (axis == null))
				throw new GenException.ParameterException("flag: " + flag + "axis: " + (axis == null ? "NULL":axis.ToString()));

			int findId = -1;
			string input;
			string output;
			string id = "flapRotation";
			string [] splittedRot;
			int result;

			FileStream fs = null;
			StreamReader sr = null;

			try
			{			
				fs = new FileStream(moveInformationFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);				
				output = "";
				id = id + "," + flag;

				while ((input = sr.ReadLine()) != null)
				{
					result = findIdInInput(moveInformationFileName,id,input,ref output);
					if (result == 0)
					{
						//p��znak nalezen� id v souboru
						findId = 0;
						splittedRot = output.Split(' ');
						if(splittedRot.Length != 3)
							throw new GenException.UsingFileException("Polo�ka flapRotation obsahuje nespr�vn� zapsan� vektor.",moveInformationFileName);
						else
						{
							axis.x = Double.Parse(splittedRot[0]);
							axis.y = Double.Parse(splittedRot[1]);
							axis.z = Double.Parse(splittedRot[2]);
						}
					}
				}
				//id v souboru nebylo nalezeno
				if (findId == -1)
					throw new GenException.UsingFileException("Id flatRotation pro dannou ruku a sm�r nebylo nalezeno.",moveInformationFileName);          
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();	
			}			
		}

		/// <summary>
		/// Na�ten� informac� ze souboru, kter� je ur�en prom�nnou moveInformationFileName. 
		/// </summary>
		/// <param name="action">0 - wheelAngle, 1 - lengthOfEdgeInPolygonCircle, 2 - minTimeUnit, 3 - numberOfMoveRepeat, 4  - partOfQuickMove, 5 - lengthOfEdgeInPolygonCurve, 6 - moveSpeed </param>
		/// <param name="flag">Ur�en� pro, kterou ruku se maj� data na��tat. 0 - lev�, 1 - prav�.</param>
		/// <param name="where">Dodate�n� ur�en� kam se m� pohyb prov�d�t u ot��en� pa�e.</param>
		/// <param name="number">Hodnota nalezen� v souboru.</param>
		static public void getInfoFromMoveFile(int action,int flag,int where,ref double number)
		{
			if(((flag != 0) && (flag != 1)) || ((where != 0) && (where != 1)) || ((action < 0)&&(action > 6)))
				throw new GenException.ParameterException("flag: " + flag + ", " + "where: " + where + ", " + "action: "+ action);

			int findId = -1;
			string input;
			string output;
			string id;
			int result;

			FileStream fs = null;
			StreamReader sr = null;

			try
			{			
				fs = new FileStream(moveInformationFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);				
				output = "";
				
				switch(action)
				{
					case 0: id = "wheelAngle" + "," + flag + "," + where; break;
					case 1: id = "lengthOfEdgeInPolygonCircle"; break;
					case 2: id = "minTimeUnit";break;
					case 3: id = "numberOfMoveRepeat";break;
					case 4: id = "partOfQuickMove";break;
					case 5: id = "lengthOfEdgeInPolygonCurve";break;
					case 6: id = "moveSpeed"; break;
					default: throw new GenException.ParameterException("Parametr action je mimo rozsah: " + action);

				}
				while ((input = sr.ReadLine()) != null)
				{
					result = findIdInInput(moveInformationFileName,id,input,ref output);
					if (result == 0)
					{
						//p��znak nalezen� id v souboru
						findId = 0;
						number = Double.Parse(output);
					}
				}
				//id v souboru nebylo nalezeno
				if ((findId == -1) && (action < 2))
					throw new GenException.UsingFileException("Id wheelAngle pro dannou ruku a sm�r nebylo nalezeno.",moveInformationFileName);          
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();	
			}


		}

		/// <summary>
		/// Hled� zadan� id v souboru, kter� je zad�n parametrem. V parametru destVector, vrac� nalezen� vektor.
		/// </summary>
		/// <param name="id">Id hledan�ho sm�ru.</param>
		/// <param name="destVector">Vektor v�sledn�ho nalezen�ho sm�ru.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="GenException.UsingFileException">�patn� form�t vektoru v souboru, o�ek�vana osaX osaY osaZ.</exception>
		/// <exception cref="GenException.UsingFileException">Id sm�ru nebylo v souboru nalezeno.</exception>

		static public void getDestVectorFromFile(string id,string directionFileName, ref Joint.Vector destVector)
		{
			int findId = -1;
			string inputDirection;
			string outputDirection;
			string [] splittedVect;
			int result;
            
			if((id == null) || (destVector == null))
				throw new GenException.ParameterException("id: " + (id == null ? "NULL":id)+ ", " + "destVector" + (destVector == null ? "NULL":destVector.ToString()));
			
			FileStream fs = null;
			StreamReader sr = null;

			try
			{
			
				fs = new FileStream(directionFileName, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);
				outputDirection = "";
 
				while ((inputDirection = sr.ReadLine()) != null)
				{
					result = findIdInInput(directionFileName, id,inputDirection,ref outputDirection);
					if (result == 0)
					{
						//p��znak nalezen� id v souboru
						findId = 0;
						splittedVect = outputDirection.Split(' ');
						if (splittedVect.Length != 3)
							throw new GenException.UsingFileException("�patn� form�t vektoru v souboru, o�ek�v�ny 3 polo�ky.",directionFileName);

						destVector.x = Double.Parse(splittedVect[0]);
						destVector.y = Double.Parse(splittedVect[1]); 
						destVector.z = Double.Parse(splittedVect[2]);

						destVector.checkNullVector();                 
					}
				}
				//id v souboru nebylo nalezeno
				if (findId == -1)
					throw new GenException.UsingFileException("Id sm�ru" + id+ "nebylo v souboru nalezeno.",directionFileName);          
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();	
			}

		}

		/// <summary>
		/// V parametrech je zad�n kvaternion a vektor. Kvaternion je p�eveden na matici rotace a tato matice
		/// je aplikovan� na vektor. Neboli rotace zadan� v kvaternionu je provedena na vektor.
		/// V�dledn� vektor je vr�cen parametrem.
		/// </summary>
		/// <param name="quat">Rotace pomoc� kvaternionu.</param>
		/// <param name="vector">Vektor, na kter� se m� rotace aplikovat.</param>
		/// <param name="rotateNormal">V�dledn� zarotovan� vektor.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		static public void multipleRotmatrixVector(Quaternion quat,Joint.Vector vector,ref Joint.Vector rotateNormal)
		{

			if((quat == null) || (vector == null) || (rotateNormal == null))
				throw new GenException.ParameterException("quat: " + (quat == null ? "NULL":quat.ToString()) + ", " +
					"vector: " + (vector == null ? "NULL":vector.ToString()) + ", " +
					"rotateNormal: " + (rotateNormal == null ? "NULL":rotateNormal.ToString()));

			rotateNormal.x = ((1 - 2*(quat.y*quat.y) - 2*(quat.z*quat.z))*vector.x) +
				((2*quat.x*quat.y - 2*quat.w*quat.z)* vector.y) +
				((2*quat.x*quat.z + 2*quat.w*quat.y)* vector.z);

			rotateNormal.y = ((2 * quat.x * quat.y + 2 * quat.w * quat.z) * vector.x) +
				((1 - 2 * quat.x * quat.x - 2 * quat.z * quat.z) * vector.y) +
				((2 * quat.y * quat.z - 2 * quat.w * quat.x) * vector.z);

			rotateNormal.z = ((2 * quat.x * quat.z - 2 * quat.w * quat.y) * vector.x) +
				((2 * quat.y * quat.z + 2 * quat.w * quat.x) * vector.y) +
				((1 - 2 * quat.x * quat.x - 2 * quat.y * quat.y) * vector.z);

		}

		/// <summary>
		/// Ur�en� kolmosti dvou vektor�. Kontrola je provedena pomoc� skal�rn�ho sou�inu vektor�.
		/// </summary>
		/// <param name="vect1">Prvn� vektor.</param>
		/// <param name="vect2">Druh� vektor.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		/// <returns>V p��pad�, �e je skal�rn� sou�in nula a� na diferenci je vr�ceno true.
		/// Jinak je vr�ceno false, tedy vektory na sebe kolm� nejsou.</returns>
		static public bool checkNormalVectToVect(Joint.Vector vect1, Joint.Vector vect2)
		{
			if((vect1 == null) || (vect2 == null))
				throw new GenException.ParameterException("vect1: " + (vect1 == null ? "NULL":vect1.ToString()) + ", " +
					"vect2: " + (vect2 == null ? "NULL":vect2.ToString()));

			double innerProduct = vect1.x*vect2.x + vect1.y*vect2.y + vect1.z*vect2.z;
			//povolen� odchylky 
			if (Math.Abs(innerProduct) < difference)
				return true;
			else
				return false;
		}

		/// <summary>
		/// Hled� id v zadan�m ��dku. V parametru je vr�cen vstupn� ��dek o�ez�n o id.
		/// </summary>
		/// <param name="file">Soubor, ze kter�ho je p��slu�n� ��dek.Pou�ito pro v�pis v p��pad� chyby.</param>
		/// <param name="id">Hledan� id.</param>
		/// <param name="inputLine">Vstupn� ��dek.</param>
		/// <param name="outputLine">Vstupn� ��dek o�ez�n o id.</param>
		/// <exception cref="GenException.ParameterException">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="GenException.UsingFileException">Po�adov�no Id a data v souboru.</exception>
		/// <returns>V p��pad� rovnosti id je vr�cena 0.
		/// Jinak je vr�cena 1.</returns>
		static public int findIdInInput(string file,string id, string inputLine, ref string outputLine)
		{
            
			string[] splittedInput;
            
			if((file == null) || (inputLine == null) || (outputLine == null))
				throw new GenException.ParameterException("file: " + (file == null ? "NULL":file) + ", " +
					"inputLine: " + (inputLine == null ? "NULL":inputLine) + ", " +
					"outputLine: " + (outputLine == null ? "NULL":outputLine));
			
			splittedInput = inputLine.Split(':');
			if(splittedInput.Length != 2)
				throw new GenException.UsingFileException("Po�adov�no Id a data v souboru.",file);

			// o�ez�n� id ze vstupn�ho ��dku
			outputLine = splittedInput[1];
                   
			if (splittedInput[0].CompareTo(id) == 0)
				return 0;
			else 
				return 1;

		}

		/// <summary>
		/// Nastaven� rotac� kloub� prstu z parametru. 
		/// </summary>
		/// <param name="flag">Identifikace, zda data pat�� lev� nebo prav� ruce.0 je lev� ruka, 1 je prav� ruka.</param>
		/// <param name="finger">Identifikace, ke kter�mu prstu data pat��.1 mal��ek,2 prsten��ek, 3 prost�edn��ek, 4 ukazov��ek, 5 palec.</param>
		/// <param name="data">Data k prstu. Obsahuje rotace pro klouby ve form�tu: rotace1,rotace2,rotace3. V po�ad� od ko�ene ruky.
		///  Rotace je ve formatu osaX osaY osaZ.
		///  Pou��v� soubor ./generate/dez.txt.</param>
		///  <exception cref="">Neinicializovan� vstupn� parametr.</exception>
		///  <exception cref="">O�ek�v�ny t�i rotace v souboru.</exception>
		///  <exception cref="">Parametr finger neodpov�d� ��dn� z povolen�ch hodnot.</exception>
		///  <exception cref="">�patn� form�t rotace v souboru, o�ek�vana osaX osaY osaZ �hel.</exception>
		///  <exception cref="">Parametr flag neodpov�d� ��dn� z povolen�ch hodnot.</exception>
		static public void setFinger(int flag, int finger, string data) 
		{

			string [] splittedData = data.Split(','); 
			string[] splittedMal; 
			int i;
			int fingerIdent;
			Joint.Rotation rotation = new Joint.Rotation();
            
			if(data == null)
				throw new GenException.ParameterException("Parametr data je NULL.");

			if (splittedData.Length != 3)
				throw new GenException.UsingFileException("�patn� po�et kloub� pro prst, o�ek�v�ny 3 polo�ky.", dezFileName);

			// nastaveni kterym indexem v prom�nn� left/rightHand za��n� prvn� kloub dan�ho prstu
			switch(finger)
			{
					//mal��ek
				case 1: fingerIdent = 3;
					break;
					//prsten��ek
				case 2: fingerIdent = 6;
					break;
					//prost�edn��ek
				case 3: fingerIdent = 9;
					break;
					//ukazov��ek
				case 4: fingerIdent = 12;
					break;
					//palec
				case 5: fingerIdent = 15;
					break;
				default:
					throw new GenException.ParameterException("Parametr finger je mimo rozsah 1 - 5, finger: " + finger + "."); // wrong parameter
			}
			for (i = 0; i < 3; i++,fingerIdent++) 
			{

				splittedMal = splittedData[i].Split(' ');
				if (splittedMal.Length != 4) // osa x,y,z a �hel
					throw new GenException.UsingFileException("�patn� po�et polo�ek pro vektor, o��v�ny 3 polo�ky.",dezFileName);
                
				// na�ten� rotace 
				rotation.x = Double.Parse(splittedMal[0]);
				rotation.y = Double.Parse(splittedMal[1]);
				rotation.z = Double.Parse(splittedMal[2]);
				rotation.angle = Double.Parse(splittedMal[3]);
				
				if (flag == 0) // lev� ruka
				{ 	// v souboru dez jsou pops�ny tvary pro pravou ruku, proto je nutn� p�ehodit osu y a z,
					// tak aby dez pro levou ruku odpov�dal zrcadlov�mu obrazu ruky prav�
					rotation.y *= -1;
					rotation.z *= -1;
					
					leftHand[fingerIdent].vrmlRotation.copyRotation(rotation);
					//leftHand[fingerIdent].composeRotation(rotation, ref leftHand[fingerIdent].vrmlRotation,0);
				}
				else if (flag == 1) // prav� ruka
				{
					rightHand[fingerIdent].vrmlRotation.copyRotation(rotation);
					//		rightHand[fingerIdent].composeRotation(rotation, ref rightHand[fingerIdent].vrmlRotation,0);                       
				}
				else
					throw new GenException.ParameterException("Parametr flag mimo rozsah 0/1, flag: " + flag + "."); // wrong parameter
			}
		}

		/// <summary>
		/// Nastav� pozici ruky, tak aby m�sto na ruce, kter� je ur�eno parametrem joint, nejv�ce odpov�dalo znakovac�mu m�stu TABw. Neboli, pozice z�p�st�
		/// ve znakovac�m prostoru je nahrazena dan�m m�stem v parametru joint.
		/// </summary>
		/// <param name="flag">Ur�en�, u kter� ruky je bod po��t�n. </param>
		/// <param name="joint">Ur�en�, kter� kloub je po��t�n, p��padn�, kter� kloub je ve stromov� struktu�e nejbli��� o �rov�� v��.</param>
		public static void setCorrectTabFromDez(int flag, int joint)
		{
			if(((flag != 0) && (flag != 1)) || ((joint<0) || (joint > 22)) )
				throw new GenException.ParameterException("flag: " + flag + ", " + "joint: " + joint); 
			
			Joint.Vector actualWrist = new Joint.Vector();
			Joint.Vector actualJoint = new Joint.Vector();
			Joint.Vector vectToMove = new Joint.Vector();
			double distMove = 0;
			int jointInFinder = 0;

			// zji�t�n� aktu�ln� pozice z�p�st�
			moveGenerator.getGlobalJointFromLocal(flag,1,0,new Joint.Vector(),ref actualWrist);			
			
			if(joint<18)
				moveGenerator.getGlobalJointFromLocal(flag,joint-1,0,new Joint.Vector(),ref actualJoint);
			else
			{
				switch(joint)
				{
					case 18: jointInFinder = 5;break;
					case 19: jointInFinder = 8;break;
					case 20: jointInFinder = 11;break;
					case 21: jointInFinder = 14;break;
					case 22: jointInFinder = 18;break;
				}
				moveGenerator.getGlobalJointFromLocal(flag,jointInFinder,1,fingerTipDistance[flag][joint-18],ref actualJoint);
			}
			moveGenerator.getVectorFromPoints(actualWrist,actualJoint,ref vectToMove);
			distMove = moveGenerator.getDistancePoints(actualJoint,actualWrist);
			try
			{
				moveGenerator.makeStraightMove(flag,vectToMove,distMove,0);
			}
			catch(GenException.ComputingException ex)
			{
				;
			}

		}

		/// <summary>
		/// Nastaven� tvaru ruky DEZ. Data pro jednotliv� prsty jsou na�tena ze souboru v prom�nn� dezFileName.
		/// V p��pad�, �e je action 1, je provedena korekce, tak aby znakovac�mu prostoru odpov�dalo m�sto, kter� je zad�no v souboru
		/// s daty pro klouby konkr�tn�ho DEZ.
		/// </summary>
		/// <param name="id">Id tvaru ruky, kter� se m� nastavit.</param>
		/// <param name="flag">Identifikace, kter� ruka se m� nastavit. 0 - lev� ruka, 1 - prav� ruka.</param>
		/// <param name="action">0 - Neprov�d�t korekci TAB.
		/// 1 - Prov�st korekci TAB, dle parametru u DEZ.</param>
		/// <exception cref="">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="">Parametr flag neodpov�d� ��dn� z povolen�ch hodnot.</exception>
		/// <exception cref="">�patn� po�et prst� ke tvaru ruky v souboru.</exception>
		/// <exception cref="">Id tvaru ruky nebylo v souboru nalezeno.</exception>
		static public void setDez(string id, int flag,int action)
		{ 
			string inputLineDez;
			int findId = -1;            
			int result;
			string inputFingerRot = "";
			string file = dezFileName;
			string[] splittedLine;
			int i;

			if(id == null)
				throw new GenException.ParameterException("Parametr id je NULL.");
			
			FileStream fs = null;
			StreamReader sr = null;

			try
			{

				fs = new FileStream(file, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);

				while ((inputLineDez = sr.ReadLine()) != null)
				{
					result = findIdInInput(file,id,inputLineDez,ref inputFingerRot);
					if (result == 0)
					{
						findId = 0;
						splittedLine = inputFingerRot.Split(';');
						if (splittedLine.Length != 6) // p�t prst� + identifik�tor kloubu
							throw new GenException.UsingFileException("O�ek�v�na data pro 5 prst� a identifik�tor kloubu.", file);
						
						if((flag != 0) && (flag != 1))
							throw new GenException.ParameterException("Parametr flag mimo rozsah 0/1, flag: " + flag + "."); // wrong paramater										

						// nastaven� rotace prstu do kloub�, provedeno pro ka�d� prst
						for (i = 2; i < 7; i++)
						{
							setFinger(flag,i-1, splittedLine[i-1]);
						}
						if(action == 1)
						{ // pokud je tab nic korekci neprov�d�t
							if(((flag == 0) && (tabL.CompareTo("nic") != 0)) || (flag == 1) && (tabR.CompareTo("nic") != 0))
								setCorrectTabFromDez(flag,Int32.Parse(splittedLine[0]));
						}
                        
						else if (action != 0)
							throw new GenException.ParameterException("Parametr action mimo rozsah 0/1, action: " + action + ".");

						break;
					}
				}
				if (findId == -1)
					throw new GenException.UsingFileException("V souboru nebylo nalezeno po�adovan� ID.");          
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();	
			}
                    
		}

		/// <summary>
		/// Nastaven� vz�jemn� polohy rukou. Vektor, kter� ud�v� sm�r prav� ruky od lev� je na�ten ze souboru
		/// zadan�m v parametru directionHaFileName. Je proveden pohyb prav� ruky ve sm�ru tohoto vektoru a pohyb lev�
		/// ruky ve sm�ru vektoru opa�n�m k na�ten�mu.
		/// </summary>
		/// <param name="id">Id ur�uj�c� konkr�tn� HA.</param>
		public static void setHa(string id)
		{	
			if(id == null)
				throw new GenException.ParameterException("Parametr id je NULL.");

			Joint.Vector direct = new Joint.Vector();

			getDestVectorFromFile(id,directionHaFileName,ref direct);
			if((tabL.CompareTo(tabR) == 0))
			{
				// tedy neplat� podm�nka �e oba TAB jsou nic v tom p��pad� ned�lat HA
				if(tabL.CompareTo("nic") != 0)
				{
					moveGenerator.makeStraightMove(1,direct,tabRLengthOfMove/2,0); 
					direct.minusVector();
					moveGenerator.makeStraightMove(0,direct,tabLLengthOfMove/2,0);
				}
			}
			
		}

		/// <summary>
        /// Ze souboru zadan�m v prom�nn� ori_directionFileName jsou na�teny vektory sm�r�, kter� maj� b�t nastaveny.
        /// V p��pad�, �e je nastavov�n sm�r prst� je zkontrolov�no zda je nastavovan� sm�r kolm� s aktu�ln�m sm�rem dlan� v prostoru.
        /// Lok�ln� vektory ur�uj�c� v�choz� stav jsou p�evedeny na aktu�ln� sm�ry dlan� nebo prst� ve sc�n�. Pro ka�dou ruku je
        /// spo��t�na rotace mezi po�adovan�m sm�rem a aktu�ln�m sm�rem. Rotace je p�evedena do sou�adnic z�p�st� a je slo�ena s
        /// aktu�ln� rotac� v z�p�st�. V�sledn� rotace je ulo�ena do aktu�ln� rotace z�p�st�.		
        /// </summary>
		/// <param name="idLeft">Identifik�tor sm�ru pro levou ruku.</param>
		/// <param name="idRight">Identifik�tor sm�ru pro pravou ruku.</param>
		/// <param name="directionLeft">Aktu�ln� sm�r pro levou ruku.</param>
		/// <param name="directionRight">Aktu�ln� sm�r pro pravou ruku.</param>
		/// <param name="flag">0 - po��tat ORI1, 1 - po��tat ORI2</param>
		static public void setOri(string idLeft,string idRight, Joint.Vector directionLeft, Joint.Vector directionRight,int flag)
		{
			if((idLeft == null) ||(idRight == null) || (directionLeft == null) || (directionRight == null) || ((flag != 1) && (flag != 2)))
				throw new GenException.ParameterException("idLeft: " + (idLeft == null ? "NULL":idLeft) + ", " +
					"idRight: " + (idRight == null ? "NULL":idRight) + ", " +
					"directionLeft: " + (directionLeft == null ? "NULL":directionLeft.ToString()) + ", " +
					"directionRight: " + (directionRight == null ? "NULL":directionRight.ToString()) + ", " +
					"flag: " + flag );

			Quaternion quat = new Quaternion();
			Quaternion quatFinalRot = new Quaternion();
			Quaternion quatFinal = new Quaternion();
			Quaternion quatInverse = new Quaternion();
			Quaternion middle = new Quaternion();
			Joint.Vector rotateNormal = new Joint.Vector(); // norm�la po aplikaci rotac� kloubu
			Joint.Vector destVector = new Joint.Vector(); // kone�n� vektor, kter� m� b�t norm�lou            
			Joint.Rotation finalRotation = new Joint.Rotation(); // rotace kter� se m� prov�st na kloub
			Joint.Rotation actRotation = new Joint.Rotation(); // slo�en� rotac� rodi�� a vlastniho kloubu
			Joint.Vector rotateDestVect = new Joint.Vector();

			// aplikovat na norm�lu lev�ho z�p�st� jeho rotace 
			getDestVectorFromFile(idLeft,directionOriFileName, ref destVector); 
			// zapamatovat si kone�n� sm�r norm�ly dlan� pro kontrolu se sm�rem prst� v dal��m volan� t�to fce
			if (flag == 1) 
			{
				dirNormalLeft.copyVector(destVector);
			}
			else if (flag == 2) 
			{ 
				// pokud norm�la dlan� a sm�r prst� nejsou kolm� nelze pokra�ovat, �patn� zadan�
				if (!checkNormalVectToVect(dirNormalLeft, destVector))
				{
					throw new GenException.ComputingException("Vektory nejsou kolm�.");
				}                    
			}
			leftHand[2].joinParentsRotations(ref actRotation); 
			quat.angleToQuatertnion(actRotation); 
			multipleRotmatrixVector(quat,directionLeft,ref rotateNormal); 
			// glob�ln� rotace na norm�lu, pot�eba p�ev�st na lok�ln� v��i z�p�st�			
			getRotationVectorVector(rotateNormal,destVector, ref finalRotation); 
			// nutno vyn�sobit inverz(quat)* finalrotation-> to quatrot* quat a kone�n� quat p�ev�st na kone�nou rotaci,kterou d�t do distibute
			quatFinalRot.angleToQuatertnion(finalRotation); 
			middle.multipleQuaternions(quatFinalRot, quat); 
			quat.inverseQuaternion(ref quatInverse);
			quatFinal.multipleQuaternions(quatInverse,middle);
			quatFinal.quaternionToAngle(ref finalRotation);
			leftHand[2].composeRotation(finalRotation,ref leftHand[2].vrmlRotation,1); 

			getDestVectorFromFile(idRight,directionOriFileName, ref destVector);
			if (flag == 1)
			{
				dirNormalRight.copyVector(destVector);
			}
			else if (flag == 2)
			{
				if (!checkNormalVectToVect(dirNormalRight, destVector))
					throw new GenException.ComputingException("Vektory nejsou kolm�.");
			}
			rightHand[2].joinParentsRotations(ref actRotation);
			quat.angleToQuatertnion(actRotation);
			multipleRotmatrixVector(quat,directionRight, ref rotateNormal);
			getRotationVectorVector(rotateNormal, destVector, ref finalRotation);
			quatFinalRot.angleToQuatertnion(finalRotation); 
			middle.multipleQuaternions(quatFinalRot, quat);
			quat.inverseQuaternion(ref quatInverse);
			quatFinal.multipleQuaternions(quatInverse, middle);
			quatFinal.quaternionToAngle(ref finalRotation);
			rightHand[2].composeRotation(finalRotation,ref rightHand[2].vrmlRotation,1);
		}

		/// <summary>
		/// Na�ten� rotac� pro rameno a loket. Spole�n� ur�uj� m�sto znakov�n� TAB.
		/// Data jsou na�tena ze vstupn�ho parametru.</summary>
		/// <param name="inputData">Vstupn� data.Form�t dat je: rotace_ramene;rotace_lokte.
		/// Form�t rotace je osaX osaY osaZ.</param>
		/// <param name="rotationArray">V�sledn� rotace m�sta znakov�n� TAB.</param>
		/// <exception cref="">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="">�patn� po�et rotac� na vstupu.</exception>
		static public void getRotationToTab(string inputData,ref Joint.Rotation [] rotationArray,ref double relLengthOfMove)
		{
            
			string[] splittedTab;
			string[] splittedRotation;
			int i;

			if((inputData == null) || (rotationArray == null))
				throw new GenException.ParameterException("inputData: " + (inputData == null ? "NULL":inputData) + ", " +
					"rotationArray: " + (rotationArray == null ? "NULL":"NOT NULL"));  

			splittedTab = inputData.Split(';');
			if (splittedTab.Length != 3)
				throw new GenException.UsingFileException("�patn� po�et rotac� nebo chyb�j�c� velikost pohybu.","Jeden z TAB soubor�.");

			for (i= 0; i < 2; i++)
			{
				splittedRotation = splittedTab[i].Split(' ');
				rotationArray[i].x = Double.Parse(splittedRotation[0]);
				rotationArray[i].y = Double.Parse(splittedRotation[1]);
				rotationArray[i].z = Double.Parse(splittedRotation[2]);
				rotationArray[i].angle = Double.Parse(splittedRotation[3]);
				rotationArray[i].checkNullVector();

			}
			relLengthOfMove = Double.Parse(splittedTab[2]);

		}
		/// <summary>
		/// Rotace v parametru slo�� s vrml rotacemi ramene a lokte.
		/// </summary>
		/// <param name="flag">Identifikace o kterou ruku se jedn�. 0 - lev� ruka, 1 - prav� ruka.</param>
		/// <param name="tabRotationList">Rotace ramene a loktu.</param>
		/// <exception cref="">Neinicializovan� vstupn� parametr.</exception>
		/// <exception cref="">Parametr flag neodpov�d� ��dn� z povolen�ch hodnot.</exception>
		static public void apllyRotationFromTab(int flag, Joint.Rotation[] tabRotationList)
		{
			if(tabRotationList == null)
				throw new GenException.ParameterException("Parametr tabRotationList je NULL.");

			if (flag == 0)
			{
				leftHand[1].composeRotation(tabRotationList[1], ref leftHand[1].vrmlRotation, 1);
				leftHand[0].composeRotation(tabRotationList[0], ref leftHand[0].vrmlRotation, 1);
			}
			else if(flag == 1)
			{
				rightHand[1].composeRotation(tabRotationList[1], ref rightHand[1].vrmlRotation, 1);
				rightHand[0].composeRotation(tabRotationList[0], ref rightHand[0].vrmlRotation, 1);
			}
			else
				throw new GenException.ParameterException("Parametr flag je mimo rozsah 0/1, flag: " + flag);
           
		}

		/// <summary>
		/// Nastaven� znakovac�ho m�sta, kter� je zad�no v parametru. 
		/// V z�vislosti na tom, kter� ruka m� b�t nastavena je pou�ito jm�no souboru z prom�nn� tabLFileName nebo 
		/// tabPFileName. Ze souboru jsou na�teny rotace pro klouby ramene a z�p�st�. Na�tena je tak� hodnota, kter� ur�uje
		/// jak dlouh� se m� prov�d�t, v tomto znakovac�m prostoru, pohyb.
		/// </summary>
		/// <param name="id">Id znakovac�ho prostoru, kter� m� byt nastaven na modelu.</param>
		/// <param name="hand">Ur�uje, pro kterou ruju je znakovac� prostor na��t�n. 0 - lev�, 1 - prav�.</param>
		static public void getTab(string id,int hand)
		{			
			string inputLineTab;           
			string inputData = "";
			string file = "";
			int findId = -1;
			int result;
			double length = 0;

			if(id == null)
				throw new GenException.ParameterException("Parametr id je NULL.");
			
			if (hand == 0)
				file = tabLFileName;
			else if(hand == 1)
				file = tabPFileName;
			else 
				throw new GenException.ParameterException("Parametr hand je mimo rozsah 0/1, hand: " + hand + ".");
			
			Joint.Rotation[] tabRotationList = new Joint.Rotation[2]; 
            
			for (int j= 0; j < 2; j++)

				tabRotationList[j] = new Joint.Rotation();
            
			FileStream fs = null;
			StreamReader sr = null;

			try
			{
				fs = new FileStream(file, FileMode.Open, FileAccess.Read);
				sr = new StreamReader(fs);

				while ((inputLineTab = sr.ReadLine()) != null)
				{
					result = findIdInInput(file, id, inputLineTab, ref inputData);
					if (result == 0)
					{
						findId = 0;
						getRotationToTab(inputData, ref tabRotationList,ref length);
						if(hand == 0)
							tabLLengthOfMove = length;
						else 
							tabRLengthOfMove = length;
						apllyRotationFromTab(hand,tabRotationList);
						break;
					}
				}
				if (findId == -1)
					throw new GenException.UsingFileException("V souboru nebylo nalezeno po�adovan� id.", file);          
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fs != null)
					fs.Close();	
			}
		}
		
		/// <summary>
		/// Do seznamu, ve kter�m jsou ulo�eny fin�ln� rotace (z tohoto seznamu se vytv��� data do souboru interpolator.wrl), jsou p�id�ny rotace ze seznamu, kter� se napl�uje v pr�b�hu 
		/// v�po�tu jednoho pohybu. Tyto seznamy obsahuje ka�d� kloub. Kopie je tedy provedena pro v�echny klouby.
		/// </summary>
		/// <param name="flag">Ur�uje, kter� klouby maj� b�t zkop�rov�ny. 0 - lev� ruky, 1 - prav� ruky.</param>
		static public void useRotationToFinalRotation(int flag)
		{
			if((flag != 1) && (flag != 0))
				throw new GenException.ParameterException("Parametr flag je mimo rozsah 0/1, flag: " + flag + ".");

			Joint[] hand;

			if(flag == 0)
				hand = leftHand;
			else
				hand = rightHand;

			for(int joint = 0; joint < numberJointHand; joint++)
			{
				// kopie posledn�ho prvku v seznamu
				if(hand[joint].interpolatorRotations.Count == 0)
				{
					hand[joint].interpolatorFinalMoveRotations.Add((hand[joint].interpolatorFinalMoveRotations[hand[joint].interpolatorFinalMoveRotations.Count -1]));
				}				
				for(int i = 0; i < hand[joint].interpolatorRotations.Count; i++)
					hand[joint].interpolatorFinalMoveRotations.Add(hand[joint].interpolatorRotations[i]);
				
				hand[joint].interpolatorRotations.Clear();
			}			
		}

		/// <summary>
		/// Pro ka�d� kloub zadan� ruky, p�id� z�znamy do seznamu �as� pro interpol�tor dan�ho kloubu.
		/// �asov� z�znamu jsou vytvo�eny na z�klad� po�tu rotac�, kter� byly provedeny v pr�b�hu zpracov�n� jednoho pohybu
		/// a na z�klad� �asov�ho �seku, kter� je tomuto pohybu p�i�azen. Po��te�n� �as pohybu je z�sk�n jako posledn� z�znam 
		/// v seznamu �as�. Kone�n� �as pohybu je zad�n parametrem.
		/// </summary>
		/// <param name="flag">Ur�uje, pro kterou ruku maj� b�t p�id�ny informace o �ase jednoho pohybu.</param>
		/// <param name="untilTime">�as, ve kter�m m� proveden� pohyb skon�it.</param>
		static public void createInterpolatorKey(int flag,double untilTime)
		{
			int i;	
			double deltaKey;
			double lastKey;
			Joint[] hand;

			if(((flag != 0) && (flag != 1)) || (untilTime<= 0))
				throw new GenException.ParameterException("flag: " + flag + ", " + "untilTime: " + untilTime);

			for(i=0; i < numberJointHand; i++)
			{									
				if(flag == 0)
					hand= leftHand;
				else
					hand= rightHand;
			
				lastKey = (double)hand[i].interpolatorKey[hand[i].interpolatorKey.Count - 1];					
				if(hand[i].interpolatorRotations.Count == 0)
				{
					hand[i].interpolatorKey.Add(untilTime);
				}
				deltaKey =(untilTime - lastKey)*( 1/(double)(hand[i].interpolatorRotations.Count));
									
				for(int k=0; k < (hand[i].interpolatorRotations.Count);k++)
				{
					lastKey += deltaKey;
					hand[i].interpolatorKey.Add(lastKey);
				}								
			}
		}

		/// <summary>
		/// Vytvo�� soubor interpolator.wrl. V tomto souboru jsou ulo�eny informace o animaci modelu.
		/// Jsou v n�m informace o tom, jak� rotace se maj� na klouby prov�d�t a informace o tom jak maj� b�t 
		/// rotace �asov�ny. Form�t souboru odpov�d� VRML.
		/// V p��pad�, �e dojde k vyj�mce p�i v�po�tu pohybu, je tento soubor vytvo�en jako kopie souboru 
		/// interpolator_default.wrl.
		/// </summary>
		static public void createInterpolatorVrmlFile()
		{
			int i;
			string  interp = "interp_";
			string frac = "_set_fraction";
			string val = "_value_changed";
			StringBuilder s;

			FileStream file = null;
			StreamWriter sw = null;

			try
			{
				file = new FileStream(interpolatorFileName, FileMode.Create ,FileAccess.Write);
				sw = new StreamWriter(file);
            
				sw.WriteLine("#VRML V2.0 utf8");
				sw.WriteLine("PROTO interpolatory [");

				for(i=0; i < numberJointHand; i++)
				{
					sw.WriteLine("eventIn SFFloat " + interp + leftHand[i].nameOfJoint + frac);
					sw.WriteLine("eventOut SFRotation " + interp + leftHand[i].nameOfJoint + val);
					sw.WriteLine("eventIn SFFloat " + interp + rightHand[i].nameOfJoint + frac);
					sw.WriteLine("eventOut SFRotation " + interp + rightHand[i].nameOfJoint + val);
				}
				sw.WriteLine("]{");
				sw.WriteLine("Group {	children [");
			
				Joint[] hand;
				for(i=0; i < numberJointHand; i++)
			{	
				for(int j=0; j<=1;j++)
				{	
						if(j==0)
							hand= leftHand;
						else
							hand= rightHand;

						sw.WriteLine("DEF " + interp + hand[i].nameOfJoint + " OrientationInterpolator {" );
					
						s = new StringBuilder("key[");

						foreach(Double k in hand[i].interpolatorKey)
						{
							s.Append(k.ToString()).Append(", ");
						}

						s.Remove(s.Length - 2, 2);
						s.Append("]");
						sw.WriteLine(s.ToString());
						sw.Write("keyValue[");
			
						s = new StringBuilder("");
						foreach(Joint.Rotation p in hand[i].interpolatorFinalMoveRotations)
						{
							s.Append(p.x).Append(" ").Append(p.y).Append(" ").Append(p.z).Append(" ").Append(p.angle).Append(", ");
						}
					
						s.Remove(s.Length-2, 2);
						sw.Write(s.ToString());
						sw.WriteLine("]");					
						sw.WriteLine("set_fraction IS " + interp + hand[i].nameOfJoint + frac);
						sw.WriteLine("value_changed IS " + interp + hand[i].nameOfJoint + val);
						sw.WriteLine("}");
					}
				}

				sw.WriteLine("]}}");
			}
			finally
			{
				if(sw != null)
					sw.Close();
				if(file != null)
					file.Close();
			}
		}

		/// <summary>
		/// Vytvo�� soubor intitialize.js. Tento soubor obsahuje informace o statick�m nastaven� modelu.
		/// Pro ka�d� kloub je do souboru ulo�ena rotace, kter� se mus� prov�st na v�choz� model. Po na�ten� tohoto souboru
		/// je model nastavem do po��te�n� polohy znakov�n�.
		/// Pro ka�d� kloub existuje prom�nn�, ve kter� je ulo�ena aktu�ln� rotace v pr�b�hu v�po�tu.
		/// Tato prom�nn� je pro ka�d� kloub zkop�rov�na do souboru sou�asne s identifik�torem kloubu.
		/// Form�t souboru odpov�d� form�tu JavaScript pro VRML.
		/// </summary>
		static public void createInitializeVrmlFile()
		{
			int i;
			FileStream file =null;
			StreamWriter sw = null;

			try
			{
				file = new FileStream(initializeFileName, FileMode.Create ,FileAccess.Write);
				sw = new StreamWriter(file);
            
				sw.WriteLine("function initialize(){");
         
				// lev� ruka
				for (i = 0; i < numberJointHand; i++)
				{
					// v souboru rotac� nesm� b�t z�pis 0 0 0 0, proto p�i nulov�m �hlu nastavena jedna osa na 1
					if (leftHand[i].vrmlRotation.angle == 0) 
						leftHand[i].vrmlRotation.x = 1;

					sw.WriteLine(nameLefthandVrml + '.' + leftHand[i].nameOfJoint + "_rot =" + "new SFRotation(" + 
						leftHand[i].vrmlRotation.x +
						"," +
						leftHand[i].vrmlRotation.y +
						"," +
						leftHand[i].vrmlRotation.z +
						"," +
						leftHand[i].vrmlRotation.angle +
						");"
						);
				}
				// prav� ruka
				for (i = 0; i < numberJointHand; i++)
				{
					if (rightHand[i].vrmlRotation.angle == 0) 
						rightHand[i].vrmlRotation.x = 1;

					sw.WriteLine(nameRighthandVrml + '.' + rightHand[i].nameOfJoint + "_rot =" + "new SFRotation(" +
						rightHand[i].vrmlRotation.x +
						"," +
						rightHand[i].vrmlRotation.y +
						"," +
						rightHand[i].vrmlRotation.z +
						"," +
						rightHand[i].vrmlRotation.angle +
						");"
						);
				}
				sw.WriteLine("}");
			}
			finally
			{
				if(sw != null)
					sw.Close();
				if(file != null)
					file.Close();
			}
		}

		/// <summary>
		/// Pro ka�d� kloub zadan� ruky, zkop�ruje aktu�ln� rotaci do seznamu, 
		/// ve kter�m jsou ulo�eny rotace v�ech pohyb�, kter� jsou ve znaku.
		/// </summary>
		static public void copyVrmlRotationOfAllJointsToFinalList()
		{	
			int joint;
			// kopie do fin�ln�ho listu rotac� na prvn� m�sto
			for(joint=0;joint < numberJointHand; joint++)
			{
				leftHand[joint].addVrmlRotationToFinalMoveList(leftHand[joint].vrmlRotation);
				rightHand[joint].addVrmlRotationToFinalMoveList(rightHand[joint].vrmlRotation);
			}
		}
	
		/// <summary>
		/// P�evede statick� prvky notace na �et�zce a ulo�� je do glob�ln�ch prom�nn�ch.
		/// Sou�asn� je tak� prov�d�na kontrola jednotliv�ch ��st� notace a v p��pad�, �e jsou nalezeny chyby, je provedena
		/// korektura. U n�kter�ch ��st� notace je tak� p�id�na zpr�va pro u�ivatele.
		/// </summary>
		/// <param name="notation">Notace, kter� obsahuje aktu�ln� znak.</param>
		/// <param name="tab">Ur�uje, zda je v klientovi pr�v� zpracov�v�no znakov�c� m�sto.</param>
		static public void getArguments(Notation notation, bool tab) 
		{ 
			System.Collections.ArrayList listOfOri = new System.Collections.ArrayList();

			if(notation == null)
				throw new GenException.ParameterException("Parametr notation je NULL.");
			
			typeOfSign = notation.typ.ToString();

			//nic je zavedeno primo v souborech pro tabL a tabR
			if((notation.tabL == Notation.TAB.odKoleneKeKotnikuL) || (notation.tabL == Notation.TAB.stehnoL) || (notation.tabL == Notation.TAB.bokP) ||
				(notation.tabL == Notation.TAB.odKoleneKeKotnikuP) ||(notation.tabL == Notation.TAB.stehnoP))
			{
				tabL = "nic";
				// vypsani hlasky o tom ze tento tab neumime a byl nastaven tab nic
				if(tab)
					result.messagesToUser.Add("Model tento TAB pro levou ruku nepodporuje, na modelu nastaven TAB nic !");
			}
			else
				tabL = notation.tabL.ToString();

			if((notation.tabP == Notation.TAB.odKoleneKeKotnikuL) || (notation.tabP == Notation.TAB.stehnoL) || (notation.tabP == Notation.TAB.bokL) ||
				(notation.tabP == Notation.TAB.odKoleneKeKotnikuP) ||(notation.tabP == Notation.TAB.stehnoP))
			{
				tabR = "nic";
				// vypsani hlasky o tom ze tento tab neumime a byl nastaven tab nic
				if(tab)
					result.messagesToUser.Add("Model tento TAB pro pravou ruku nepodporuje, na modelu nastaven TAB nic !");
			}
			else
				tabR = notation.tabP.ToString();
			
			ori1L = notation.ori1L.ToString();
			ori1R = notation.ori1P.ToString();
			ori2L = notation.ori2L.ToString();
			ori2R = notation.ori2P.ToString();

			if((ori1L.CompareTo("nic") == 0) && (ori2L.CompareTo("nic") == 0))
			{	
				ori1L = "doprava";
				if(tabL.CompareTo("nic") == 0)
					ori2L = "dolu";
				else
					ori2L = "nahoru";
			}
			else if(ori1L.CompareTo("nic") == 0)
			{
				findNonOrthogonalVectorsInOriFile(ori2L,ref listOfOri,1);
				if(listOfOri.Count == 0)
					throw new GenException.UsingFileException("Soubor neobsahuje ��dn� vektor, kter� by byl kolm� k vektoru" + ori2L + ".",directionOriFileName);
				else
					ori1L = (String)listOfOri[0];
			}
			else if(ori2L.CompareTo("nic") == 0)
			{
				findNonOrthogonalVectorsInOriFile(ori1L,ref listOfOri,1);
				if(listOfOri.Count == 0)
					throw new GenException.UsingFileException("Soubor neobsahuje ��dn� vektor, kter� by byl kolm� k vektoru" + ori1L + ".",directionOriFileName);
				else
					ori2L = (String)listOfOri[0];
			}
			if((ori1R.CompareTo("nic") == 0) && (ori2R.CompareTo("nic") == 0))
			{	
				ori1R = "doleva";
				if(tabR.CompareTo("nic") == 0)
					ori2R = "dolu";
				else
					ori2R = "nahoru";
			}
			else if(ori1R.CompareTo("nic") == 0)
			{
				findNonOrthogonalVectorsInOriFile(ori2R,ref listOfOri,1);
				if(listOfOri.Count == 0)
					throw new GenException.UsingFileException("Soubor neobsahuje ��dn� vektor, kter� by byl kolm� k vektoru" + ori2R + ".",directionOriFileName);
				else
					ori1R = (String)listOfOri[0];
			}
			else if(ori2R.CompareTo("nic") == 0)
			{
				findNonOrthogonalVectorsInOriFile(ori1R,ref listOfOri,1);
				if(listOfOri.Count == 0)
					throw new GenException.UsingFileException("Soubor neobsahuje ��dn� vektor, kter� by byl kolm� k vektoru" + ori1R + ".",directionOriFileName);
				else
					ori2R = (String)listOfOri[0];
			}
			
			//n�sleduj�c� prvky jsou v p��pad� nic �e�eny v souboru
			dezL = notation.dezL.ToString();
			dezR = notation.dezP.ToString();

			ha = notation.ha.ToString();
		}

		/// <summary>
		/// Vytvo�� soubor timer.wrl. Tento soubor obsahuje informace pro VRML �asova�, kter� ��d� animaci.
		/// Informace, kter� z�st�vaj� pro ka�d� znak stejn�, jsou na�teny ze souboru timer_template.txt.
		/// Informace o d�lce jednoho cyklu animace jsou na�teny z parametru.
		/// </summary>
		/// <param name="time">D�lka jednoho cyklu animace.</param>
		static public void setTimerFile(double time)
		{
			if(time < 0)
				throw new GenException.ParameterException("Parametr time je < 0, time: " +  time + ".");

			string inputLine;
			FileStream fileFrom = null;
			StreamReader sr = null;
			FileStream fileTo = null;
			StreamWriter sw = null;

			try
			{
				fileTo = new FileStream(timerFileName, FileMode.Create, FileAccess.Write);
				fileFrom = new FileStream(timerTemplateFileName, FileMode.Open, FileAccess.Read);
				sw = new StreamWriter(fileTo);
				sr = new StreamReader(fileFrom);
				
				while ((inputLine = sr.ReadLine()) != null)
				{
					sw.WriteLine(inputLine.Replace("#MOVECYRCLE", time.ToString()));		
				}				
			
			}
			finally
			{
				if(sr != null)
					sr.Close();
				if(fileFrom!= null)
					fileFrom.Close();
				if(sw != null)
					sw.Close();
				if(fileTo != null)
					fileTo.Close();

			}
		}

		/// <summary>
		/// Korektura fin�ln�ch rotac� a kl��� pro �asova�. Po�et prvk� je zredukov�n na dva, kde druh� je kopi� 
		/// prvn�ho.
		/// </summary>
		/// <param name="flag">Pro kterou ruku se m� korektura prov�st. 0 - lev�, 1 - prav�.</param>
		public static void fullAllKeyListsAndRotations(int flag)
		{	
			if((flag != 1) && (flag != 0))
				throw new GenException.ParameterException("Parametr flag je mimo rozsah 0/1, flag: " + flag + ".");

			Joint[] hand;
			if(flag == 0)
				hand = leftHand;
			else
				hand = rightHand;

			for(int joint= 0; joint < numberJointHand; joint++)
			{
				if(hand[joint].interpolatorKey.Count <= 1)
				{
					hand[joint].interpolatorKey.Add(1.0);
					hand[joint].interpolatorFinalMoveRotations.Add(hand[joint].interpolatorFinalMoveRotations[hand[joint].interpolatorFinalMoveRotations.Count -1]);
				}
				else
				{
					hand[joint].interpolatorKey.RemoveRange(1,hand[joint].interpolatorKey.Count-1);
					hand[joint].interpolatorFinalMoveRotations.RemoveRange(1,hand[joint].interpolatorFinalMoveRotations.Count -1);
					hand[joint].interpolatorKey.Add(1.0);
					hand[joint].interpolatorFinalMoveRotations.Add(hand[joint].interpolatorFinalMoveRotations[hand[joint].interpolatorFinalMoveRotations.Count -1]);
				}
			}
		}
		/// <summary>
		/// Inicializace hodnot pro pohyb. Data jsou na��t�na ze souboru, jeho� jm�no je v prom�nn� moveInfoFile.
		/// V p��pad�, �e n�kter� z nastavovan�ch prvk� nen� v souboru uveden, je ponech�na jeho p�vodn� hodnota.
		/// </summary>
		public static void inicializeMoveInfo()
		{
			double tmp = 0.0;
			
			getInfoFromMoveFile(2,0,0,ref tmp);
			if(tmp > 0)
				minTimeUnit = (int)tmp;
			
			tmp = 0;
			getInfoFromMoveFile(3,0,0,ref tmp);
			if(tmp > 0)
				numberOfMoveRepeat = (int)tmp;
			
			tmp = 0;
			getInfoFromMoveFile(4,0,0,ref tmp);
			if(tmp > 0)
				partOfQuickMove = (int)tmp;
			
			tmp = 0;
			getInfoFromMoveFile(6,0,0,ref tmp);
			if(tmp> 0)
				cyrcleUnit = tmp/(double)minTimeUnit;
		}

		/// <summary>
		/// V p��pad� vyj�mky p�id� informaci o chyb� do logu, jeho� jm�no je ulo�eno v prom�nn� logModelFileName.
		/// </summary>
		/// <param name="ex">Vznikl� vyj�mka.</param>
		public static void appendToLog(Exception ex)
		{
			if(!loggerEnabled)
				return;

			if(ex != null)
			{
				FileStream fileTo = null;
				StreamWriter sw = null;

				try
				{
					fileTo = new FileStream(logModelFileName, FileMode.Append, FileAccess.Write);
					sw = new StreamWriter(fileTo);

					// vypsat v jak� funkci k vyj�mce do�lo
					sw.WriteLine(">>>> "+ DateTime.Now.ToString() + " >>>>>" + ex.StackTrace.ToString());

					if(ex.GetType().IsSubclassOf(typeof(GenException)))
					{
						if(ex.GetType().Equals(typeof(GenException.UsingFileException)))
						{ 
							GenException.UsingFileException preEx = (GenException.UsingFileException)ex;
							sw.WriteLine("Chyba v souboru " + preEx.file + ". " + ex.Message.ToString());
						}
						else if(ex.GetType().Equals(typeof(GenException.ParameterException)))
						{
							sw.WriteLine("�patn� nebo neinicializovan� parametr funkce. " + ex.Message.ToString());
						}
						else
						{
							GenException preEx = (GenException)ex;
							sw.WriteLine(preEx.messageToUser + " " + ex.Message.ToString());
						}
					}
					else
					{
						sw.WriteLine(ex.Message.ToString());
					}
				}
				finally
				{
					if(sw != null)
						sw.Close();
					if(fileTo != null)
						fileTo.Close();
				}		
			}
		}

		/// <summary>
		/// Inicializace cesty k dat�m pro model. Inicializace cesty kam maj� soubory s daty pro model.
		/// </summary>
		/// <param name="modelPath">Cesta kam se maj� soubory s daty pro model vygenerovat.</param>
		/// <param name="dataPath">Cesta kde jsou ulo�eny soubory s daty pro generov�n�.</param>
		public static void initModelFilePaths(string modelPath, string dataPath)
		{
			initModelFilePaths(modelPath,dataPath,"initialize.js","interpolator.wrl","timer.wrl");
		}

		
		/// <summary>
		/// Inicializace cesty k dat�m pro model. Inicializace cesty kam maj� soubory s daty pro model vygenerovat a 
		/// tak� inicializace jmen generovan�ch soubor�.
		/// </summary>
		/// <param name="modelPath">Cesta kam se maj� soubory s daty pro model vygenerovat.</param>
		/// <param name="dataPath">Cesta kde jsou ulo�eny soubory s daty pro generov�n�.</param>
		public static void initModelFilePaths(string modelPath, string dataPath, string initializeName, string interpolatorName, string timerName)
		{
			pathToModel = modelPath;
			pathToGenerate = dataPath;

			initializeFileNameOnly = initializeName;
			interpolatorFileNameOnly = interpolatorName;
			timerFileNameOnly = timerName;

			nameOfJointsFileName = pathToGenerate + nameOfJointsFileNameOnly;
			vectorOfNormalsFileName = pathToGenerate + vectorOfNormalsFileNameOnly;
			directionOfFingerFileName = pathToGenerate + directionOfFingerFileNameOnly;
			directionOriFileName = pathToGenerate + directionOriFileNameOnly ;
			directionHaFileName = pathToGenerate + directionHaFileNameOnly;
			relativeDistanceFileName = pathToGenerate  + relativeDistanceFileNameOnly ;
			moveInformationFileName = pathToGenerate + moveInformationFileNameOnly;
			coordToContactFileName = pathToGenerate + coordToContactFileNameOnly;
			dezFileName = pathToGenerate + dezFileNameOnly;
			tabLFileName = pathToGenerate + tabLFileNameOnly;
			tabPFileName = pathToGenerate + tabPFileNameOnly;			
			initializeDefaultFileName = pathToGenerate + initializeDefaultFileNameOnly;
			timerTemplateFileName = pathToGenerate + timerTemplateFileNameOnly;
			interpolatorDefaultFileName = pathToGenerate + interpolatorDefaultFileNameOnly;

			interpolatorFileName = pathToModel + interpolatorFileNameOnly;
			initializeFileName = pathToModel + initializeFileNameOnly;
			timerFileName = pathToModel + timerFileNameOnly;
			logModelFileName = pathToModel + logModelFileNameOnly;

		}

		/// <summary>
		/// Hlavn� funkce generov�n� znaku. Podle notace v parametru vytvo�� v�echny dynamick� soubory, 
		/// kter� mus� b�t sou��st� adres��e s modelem, aby model korektn� znakoval znak.
		/// </summary>
		/// <param name="notation">Notace, ve kter� je ulo�en aktu�ln� znak.</param>
		/// <param name="editing">Flag zda se generuje znak p�i editov�n� nebo u vyhled�v�ni.</param>
		/// <param name="tab">Flag zda se generuje znak po zadani TAB v klientovi.</param>
		/// <param name="modelPath">Cesta k soubor�m, kter� se vygenuj� pro znakov�n� modelu. 
		///		Tyto soubory mus� b�t sou��st� adres��e s modelem.</param>
		/// <param name="genPath">Cesta k soubor�m, ve kter�ch jsou ulo�ena data pro generov�n�.</param>
		/// <returns>Objekt v n�m� je obsa�en <c>cycleInterval</c> modelu a message pro usera.</returns>
		/// <exception cref="Gen_exception.ParameterException">Parametr funkce je mimo rozsah nebo NULL.</exception>
		public static GenResult generate(Notation notation, bool editing, bool tab/*, string modelPath, string genPath*/)
		{
			return generate(notation, editing, tab, true);
		}

		/// <summary>
		/// Hlavn� funkce generov�n� znaku. Podle notace v parametru vytvo�� v�echny dynamick� soubory, 
		/// kter� mus� b�t sou��st� adres��e s modelem, aby model korektn� znakoval znak.
		/// 
		/// V�stup se zkop�ruje do <c>Gen_result.leftHand</c> a <c>Gen_result.rightHand</c>, a to pouze 
		/// v p��pad�, �e se cel� generov�n� povede. Jinak maj� uveden� dv� prom�nn� hodnou <c>null</c>.
		/// 
		/// Negeneruje soubory s VRML skripty.
		/// </summary>
		/// <param name="notation">Notace, ve kter� je ulo�en aktu�ln� znak.</param>
		/// <param name="editing">Flag zda se generuje znak p�i editov�n� nebo u vyhled�v�ni.</param>
		/// <param name="tab">Flag zda se generuje znak po zadani TAB v klientovi.</param>
		/// <param name="modelPath">Cesta k soubor�m, kter� se vygenuj� pro znakov�n� modelu. 
		///		Tyto soubory mus� b�t sou��st� adres��e s modelem.</param>
		/// <param name="genPath">Cesta k soubor�m, ve kter�ch jsou ulo�ena data pro generov�n�.</param>
		/// <returns>Objekt v n�m� je obsa�en <c>cycleInterval</c> modelu a message pro usera.</returns>
		/// <exception cref="Gen_exception.ParameterException">Parametr funkce je mimo rozsah nebo NULL.</exception>
		public static GenResult generateModel(Notation notation, bool editing, bool tab/*, string modelPath, string genPath*/)
		{
			return generate(notation, editing, tab, false);
		}

		/// <summary>
		/// Hlavn� funkce generov�n� znaku. Podle notace v parametru vytvo�� v�echny dynamick� soubory, 
		/// kter� mus� b�t sou��st� adres��e s modelem, aby model korektn� znakoval znak.
		/// </summary>
		/// <param name="notation">Notace, ve kter� je ulo�en aktu�ln� znak.</param>
		/// <param name="editing">Flag zda se generuje znak p�i editov�n� nebo u vyhled�v�ni.</param>
		/// <param name="tab">Flag zda se generuje znak po zadani TAB v klientovi.</param>
		/// <param name="modelPath">Cesta k soubor�m, kter� se vygenuj� pro znakov�n� modelu. 
		///		Tyto soubory mus� b�t sou��st� adres��e s modelem.</param>
		/// <param name="generateVrmlFiles"><c>true</c> = v�stup se vygeneruje do do soubor� ve form�tu 
		///		VRML; <c>false</c> v�stup se zkop�ruje do <c>Gen_result.leftHand</c> a 
		///		<c>Gen_result.rightHand</c>, a to pouze v p��pad�, �e se cel� generov�n� povede. Jinak 
		///		maj� uveden� dv� prom�nn� hodnou <c>null</c>.</param>
		/// <param name="genPath">Cesta k soubor�m, ve kter�ch jsou ulo�ena data pro generov�n�.</param>
		/// <returns>Objekt v n�m� je obsa�en <c>cycleInterval</c> modelu a message pro usera.</returns>
		/// <exception cref="Gen_exception.ParameterException">Parametr funkce je mimo rozsah nebo NULL.</exception>
		private static GenResult generate(Notation notation, bool editing, bool tab/*, string modelPath, string genPath*/, bool generateVrmlFiles)
		{

			System.Globalization.CultureInfo oldCulture = Thread.CurrentThread.CurrentCulture;			
			Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
			try
			{
				try
				{
					result = new GenResult();

					getArguments(notation,tab);
					inicializeJoints();
					inicializeNameJoints();
					inicializeNormalsOrDistance(vectorOfNormalsFileName,0);
					inicializeDirFinger();
					inicializeNormalsOrDistance(relativeDistanceFileName,1);
					inicializeMoveInfo();
					//nastaven� m�sta znakov�n�
					getTab(tabL,0);
					getTab(tabR,1);
					//nastaveni orientac� dlan�
					setOri(ori1L,ori1R,leftHand[2].normal,rightHand[2].normal,1);
					//nastaveni orientac� prst�
					setOri(ori2L,ori2R,dirFingerLeft,dirFingerRight,2);
					//nastaven� tvaru ruky
					setDez(dezL,0,1);
					setDez(dezR,1,1);
					//nastaven� vz�jemn� polohy rukou
					setHa(ha);            

					if (generateVrmlFiles)
						createInitializeVrmlFile();
					copyVrmlRotationOfAllJointsToFinalList();

				}
				catch(GenException e)
				{
					if (generateVrmlFiles) {
						copyDefaultInitializeAndInterpolator(1, 1);
						setTimerFile(cyrcleUnit);
					}
					appendToLog(e);
					Thread.CurrentThread.CurrentCulture = oldCulture;
					
					if(e.GetType().Equals(typeof(GenException.ComputingException)))
						throw new GenException.ComputingException(e.messageToUser);
					else if(e.GetType().Equals(typeof(GenException.NotationException)))
						throw new GenException.NotationException(e.messageToUser);
					else
					throw new GenException(e.messageToUser);
				}
				try
				{
			
					// nelze prov�st pohyb pro levou ani pro pravou ruku
					if((notation.tabP == Notation.TAB.nic)||(notation.sigP == null) || (notation.sigP.prvkyPohybu.Count == 0) || (notation.sigP.prvkyPohybu[0] == null))
						if((notation.tabL == Notation.TAB.nic)||(notation.sigL == null) || (notation.sigL.prvkyPohybu.Count == 0) || (notation.sigL.prvkyPohybu[0] == null))
						{
							if (generateVrmlFiles)
								setTimerFile(cyrcleUnit);
							fullAllKeyListsAndRotations(1);
							fullAllKeyListsAndRotations(0);
							if (generateVrmlFiles)
								createInterpolatorVrmlFile();
							Thread.CurrentThread.CurrentCulture = oldCulture;
							result.moveTime = -1;
							return result;
						}
			
					Notation.SIG sigP,sigL;
					//zjednodu�en� notace pohybu
					if((notation.tabP != Notation.TAB.nic)&&(notation.sigP != null) && (notation.sigP.prvkyPohybu.Count != 0) && (notation.sigP.prvkyPohybu[0] != null))										
					{
						sigP = moveGenerator.flatNotation(notation.sigP);
					}
					else
					{
						sigP = null;
						fullAllKeyListsAndRotations(1);
					}

					if((notation.tabL != Notation.TAB.nic)&& (notation.sigL != null) && (notation.sigL.prvkyPohybu.Count != 0) && (notation.sigL.prvkyPohybu[0] != null))
					{   
						sigL = moveGenerator.flatNotation(notation.sigL);
					}
					else 
					{
						sigL = null;
						fullAllKeyListsAndRotations(0);
					}
					//spo��tej pohyb znaku
					moveGenerator.useSigMoves(sigP,sigL);

					if(cyrcleTimeP > 0)
						moveTime = cyrcleUnit*cyrcleTimeP;
					else if (cyrcleTimeL > 0)
						moveTime = cyrcleUnit*cyrcleTimeL;
					else 
						moveTime = cyrcleUnit;

					if (generateVrmlFiles) {
						//vytvo�it soubor pro �asova�
						setTimerFile(moveTime);
						//vytvo�it soubor s daty pro interpol�tory
						createInterpolatorVrmlFile();
					}

					if (!generateVrmlFiles) {
						// muzu je primo vratit, protoze dalsi volani metody generate vytvori zcela nove objekty
						result.leftHand = leftHand;
						result.rightHand = rightHand;
					}
				}
				catch(GenException e)
				{
					if (generateVrmlFiles)
						setTimerFile(cyrcleUnit);
					fullAllKeyListsAndRotations(1);
					fullAllKeyListsAndRotations(0);
					if (generateVrmlFiles)
						createInterpolatorVrmlFile();
					appendToLog(e);
					Thread.CurrentThread.CurrentCulture = oldCulture;

					if(e.GetType().Equals(typeof(GenException.ComputingException)))
					{
						GenException.ComputingException ex = new GenException.ComputingException(e.messageToUser);					
						ex.typeOfEx = 1;
						throw ex;
					}
					else if(e.GetType().Equals(typeof(GenException.NotationException)))
					{
						GenException.NotationException ex = new GenException.NotationException(e.messageToUser);
						ex.typeOfEx = 1;
						throw ex;
					}
					else
					{
						GenException ex = new GenException(e.messageToUser);
						ex.typeOfEx = 1;
						throw ex;
					}

				}
			} catch (GenException e) {
				Thread.CurrentThread.CurrentCulture = oldCulture;
				throw e;
			} catch (Exception e) {
				Thread.CurrentThread.CurrentCulture = oldCulture;
				throw e;
			}
			Thread.CurrentThread.CurrentCulture = oldCulture;							
			
			result.moveTime = moveTime;
			return result;                

		}
		/// <summary>
		/// Zpracov�n� pohyb�.
		/// </summary>
		public class moveGenerator
		{					
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et p��m�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveStraight">Objekt obsahuj�c� data pro p��m� pohyb.</param>
			/// <param name="lengthFactor">Faktor pro d�lku pohybu.</param>
			static public void sigMakeStraightMove(int flag,Notation.SIG.PrimyPohyb partOfMoveStraight, int lengthFactor)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveStraight == null) || (lengthFactor < 0))
					throw new GenException.ParameterException("flag: " + flag + ", " + "lengthFactor: " + lengthFactor + ", " +
						"partOfMoveStraight: " + (partOfMoveStraight == null ? "NULL":"NOT NULL"));

				string id = partOfMoveStraight.hodnota.ToString();
				Joint.Vector moveDirect = new Joint.Vector();
				double length = 0;
						
				if(flag == 0)
					length = tabLLengthOfMove/lengthFactor;
				else
					length = tabRLengthOfMove/lengthFactor;
							
				getDestVectorFromFile(id,directionOriFileName, ref moveDirect); 
				makeStraightMove(flag,moveDirect,length,1);
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu k�v�n�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveSwing">Objekt obsahuj�c� data pro pohyb k�v�n�.</param>
			static public void sigMakeSwingMove(int flag,Notation.SIG.Kyvani partOfMoveSwing)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveSwing == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveSwing: " + (partOfMoveSwing == null ? "NULL":"NOT NULL"));
				
				if(partOfMoveSwing.jake == Notation.SIG.JakeKyvani.horizontalni)
					makeSwingMove(flag,1);
				else if(partOfMoveSwing.jake == Notation.SIG.JakeKyvani.vertikalni)
					makeSwingMove(flag,2);
				else
					throw new GenException.NotationException("Typ pohybu k�van� nen� horizont�ln� ani vertik�ln�.");
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu m�n�c� tvar ruky.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveDez">Objekt obsahuj�c� data pro pohyb, kter� m�n� tvar ruky.</param>			
			static public void sigMakeDezMove(int flag,Notation.SIG.AtomZmenaDEZ partOfMoveDez)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveDez == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveDez: " + (partOfMoveDez == null ? "NULL":"NOT NULL"));

				if(partOfMoveDez.jaka == Notation.SIG.JakaAtomZmenaDEZ.drobeniSpickamiPrstu)
					makeFlapMove(flag,1);
				else if(partOfMoveDez.jaka == Notation.SIG.JakaAtomZmenaDEZ.mavani)
					makeWaveMove(flag);
				else if(partOfMoveDez.jaka == Notation.SIG.JakaAtomZmenaDEZ.skrceniPrstu)
					makeDEZmove(flag,"S_A");
				else if(partOfMoveDez.jaka == Notation.SIG.JakaAtomZmenaDEZ.trepotani)
					makeFlapMove(flag,0);
				else
					throw new GenException.NotationException("Typ pohybu atomick� zm�na pohybu neodpov�d� povolen� hodnot�.");								
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu zav�r�n� a otev�r�n� ruky.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveDez">Objekt obsahuj�c� data pro pohyb zav�r�n� a otev�r�n� ruky.</param>			
			static public void sigMakeDEZMove2(int flag,Notation.SIG.OtviraniZaviraniRuky partOfMoveDez)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveDez == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveDez: " + (partOfMoveDez == null ? "NULL":"NOT NULL"));
				
				makeDEZmove(flag,partOfMoveDez.koncovyTvar.ToString());
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et kontaktn�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveCont">Objekt obsahuj�c� data pro kontaktn� pohyb.</param>
			static public void sigMakeContactMove(int flag,Notation.SIG.Kontakt partOfMoveCont)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveCont == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveCont: " + (partOfMoveCont == null ? "NULL":"NOT NULL"));

				string where = "";

				if(partOfMoveCont.cim != null)
				{
					if(partOfMoveCont.GetType().Equals(typeof(Notation.SIG.KKdeTelo)))
					{
						Notation.SIG.KKdeTelo partOfMoveWhere = (Notation.SIG.KKdeTelo)partOfMoveCont;
						where = partOfMoveWhere.kde.ToString();
					}
					else if(partOfMoveCont.GetType().Equals(typeof(Notation.SIG.KKdeRuka)))
					{
						Notation.SIG.KKdeRuka partOfMoveWhere = (Notation.SIG.KKdeRuka)partOfMoveCont;
						if(partOfMoveWhere.kde != null)
							where = partOfMoveWhere.kde[0].ToString();
						else
							throw new GenException.NotationException("Pole pro ulo�en� kontaktn�ho m�sta kde je null.");
					}
					makeContactMove(flag,where,partOfMoveCont.cim[0].ToString());
				}
				else
					throw new GenException.NotationException("Pole pro ulo�en� kontaktn�ho m�sta ��m je null.");
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et kruhov�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveCircle">Objekt obsahuj�c� data pro kruhov� pohyb.</param>
			static public void sigMakeCircleMove(int flag,Notation.SIG.KruhovyPohyb partOfMoveCircle)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveCircle == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveCircle: " + (partOfMoveCircle == null ? "NULL":"NOT NULL"));

				int number = (int)partOfMoveCircle.cislo - 1; 
				string id = number.ToString();
				string type = "";
				double lengthOfPolygonEdge = 1;
				int lengthSet = 0;

				if(partOfMoveCircle.prumer <= 0)
					getInfoFromMoveFile(1,flag,0,ref lengthOfPolygonEdge);
				else
				{
					double sin = Math.Sin(Math.PI/16);
					lengthOfPolygonEdge = sin*partOfMoveCircle.prumer;
					partOfMoveCircle.prumer = 0.0;
					lengthSet = 1;
				}

				if(partOfMoveCircle.cast == Notation.SIG.CastKruhu.cely)
					type = "f";
				else if(partOfMoveCircle.cast == Notation.SIG.CastKruhu.ctvrt)
				{
					type = "q";
					lengthOfPolygonEdge *= 2.5;
				}
				else if(partOfMoveCircle.cast == Notation.SIG.CastKruhu.pul)
				{
					type = "h";
					if(lengthSet == 0)
						lengthOfPolygonEdge *= 1.5;
				}
				id = id + ":" + type;	

				makeCircleMove(flag,id,lengthOfPolygonEdge,0);
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu ot��en� pa�e.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveWheel">Objekt obsahuj�c� data pro pohyb ot��en� pa�e.</param>
			static public void sigMakeWheelMove(int flag,Notation.SIG.OtaceniPaze partOfMoveWheel)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveWheel == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveWheel: " + (partOfMoveWheel == null ? "NULL":"NOT NULL"));

				if(partOfMoveWheel.kam == Notation.SIG.KamOtacetPazi.ven)
					makeWheelMove(flag,1);
				else if(partOfMoveWheel.kam == Notation.SIG.KamOtacetPazi.dovnitr)
					makeWheelMove(flag,0);
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu kroucen� z�p�st�m.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveRound">Objekt obsahuj�c� data pro kroucen� z�p�st�m.</param>
			static public void sigMakeRoundMove(int flag,Notation.SIG.KrouceniZapestim partOfMoveRound)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveRound == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveRound: " + (partOfMoveRound == null ? "NULL":"NOT NULL"));

				if(partOfMoveRound.jak == Notation.SIG.JakKroutitZapestim.dokolaDoprava)
					makeRoundMove(flag,0);
				else if (partOfMoveRound.jak == Notation.SIG.JakKroutitZapestim.dokolaDoleva)
					makeRoundMove(flag,1);
				else if (partOfMoveRound.jak == Notation.SIG.JakKroutitZapestim.doprava)
					makeRoundMove(flag,2);
				else if (partOfMoveRound.jak == Notation.SIG.JakKroutitZapestim.doleva)
					makeRoundMove(flag,3);
				else if (partOfMoveRound.jak == Notation.SIG.JakKroutitZapestim.zeStranyNaStranu)
					makeRoundMove(flag,4);
				else if (partOfMoveRound.jak == Notation.SIG.JakKroutitZapestim.alfa)
					makeRoundMove(flag,5);
			
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et obloukov�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveCurve">Objekt obsahuj�c� data pro obloukov� pohyb.</param>
			static public void sigMakeCurveMove(int flag,Notation.SIG.ObloukovyPohyb partOfMoveCurve)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveCurve == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveCurve: " + (partOfMoveCurve == null ? "NULL":"NOT NULL"));

				int number = (int)partOfMoveCurve.cislo - 1; 
				string id = number.ToString();
				string type = "";
				double lengthOfPolygonEdge = 1;

				if(partOfMoveCurve.cast == Notation.SIG.CastKruhu.cely)
					type = "f";
				else if(partOfMoveCurve.cast == Notation.SIG.CastKruhu.ctvrt)
					type = "q";
				else if(partOfMoveCurve.cast == Notation.SIG.CastKruhu.pul)
					type = "h";
				id = id + ":" + type;	

				getInfoFromMoveFile(5,flag,0,ref lengthOfPolygonEdge);
				makeCircleMove(flag,id,lengthOfPolygonEdge,1);

			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu vsunut�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveIn">Objekt obsahuj�c� data pro pohyb vsunut�.</param>
			static public void sigMakeInsideMove(int flag,Notation.SIG.Vsunuti partOfMoveIn)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveIn == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveIn: " + (partOfMoveIn == null ? "NULL":"NOT NULL"));				

				makeContactMove(flag,"meziPrstyIo","upatiUkazovacku");
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu zk��en�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMoveCross">Objekt obsahuj�c� data pro pohyb zk��en�.</param>
			static public void sigMakeCrossMove(int flag,Notation.SIG.Zkrizeni partOfMoveCross)
			{
				if(((flag != 0) && (flag != 1)) || (partOfMoveCross == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMoveCross: " + (partOfMoveCross == null ? "NULL":"NOT NULL"));
				
				Notation.SIG.PrimyPohyb straight = new Notation.SIG.PrimyPohyb();
				
				if(flag == 0)
					straight.hodnota = Notation.ORI.doprava;
				else
					straight.hodnota = Notation.ORI.doleva;

				makeContactMove(flag,"vnejsiZapesti","vnejsiZapesti");
			}
			/// <summary>
			/// P�evede informace z parametr� na vstupn� data funkce pro v�po�et pohybu v�m�na.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			static public void sigMakeChangeMove(int flag)
			{
				if((flag != 0) && (flag != 1))
					throw new GenException.ParameterException("flag: " + flag);
				
				if(flag == 1)
					makeChangeMove(flag);
			}
			/// <summary>
			/// V�po�et celkov�ho �asu pro prvek pohybu zadan� v parametru. Tento �as se n�sledn� vyu��v� pro ur�en� �asov�ch
			/// �sek� pro rotace.
			/// </summary>
			/// <param name="partOfMove">Prvek pohybu pro kter� se m� spo��tat �as.</param>
			/// <returns>Celkov� �as pro prvek pohybu.</returns>
			static public int getSigTime(Notation.SIG.PrvekPohybu partOfMove)
			{	
				if(partOfMove == null)
					throw new GenException.ParameterException("partOfMove: " + (partOfMove == null ? "NULL":"NOT NULL"));

				int time = 0;
			
				if((partOfMove.GetType().IsSubclassOf(typeof(Notation.SIG.AtomickyPohyb))) 
					|| (partOfMove.GetType().Equals(typeof(Notation.SIG.SimultanniPohyb))))
					time = minTimeUnit;
				
				else if ((partOfMove.GetType().Equals(typeof(Notation.SIG.SekvencePohybu))))
				{
					Notation.SIG.SekvencePohybu listOfSequence = (Notation.SIG.SekvencePohybu)partOfMove;

					foreach(Notation.SIG.PrvekPohybu secPartOfMove in listOfSequence.prvkySekvencePohybu)
					{  
						if(secPartOfMove != null)
							time += getSigTime(secPartOfMove);						
					}
				}
				else
					throw new GenException.NotationException("Prvek pohybu v z�klan�m poli neodpov�d� ani jednomu z povolen�ch typ�.");

				if(partOfMove.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.opakovanyPohyb))
					time *= numberOfMoveRepeat;
				
				if(partOfMove.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.prudkyPohyb))
					time /= partOfQuickMove;

				if(partOfMove.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.kratkyPohyb))
					time /= partOfQuickMove;

				return time;
			}		

			/// <summary>
			/// Rozli�en� jednotliv�ch atomick�ch pohyb� a zavol�n� funkce pro zpracov�n� dat pro konkr�tn� pohyb.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb po��tat. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMove">Prvek pohybu (atomick�).</param>
			/// <param name="lengthFactor">Faktor d�lky pohybu.</param>
			/// <param name="action">0 - prvek je atomick�, 1 - prvek je sou��st� pohybu simult�ln�ho.</param>
			/// <returns>V p��pad�, �e je pohyb kontakt vrac� hodnotu >0.</returns>
			static public int makeSelectAtomicMove(int flag,Notation.SIG.PrvekPohybu partOfMove,int lengthFactor, int action)
			{
				if(((flag != 1) && (flag != 0)) || (partOfMove == null) || (lengthFactor < 0) || ((action != 1) && (action != 0)))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMove: " + (partOfMove == null ? "NULL":"NOT NULL") + ", " +
						"lengthFactor: " + lengthFactor + ", " + "action: " + action);

				if(partOfMove.GetType().Equals(typeof(Notation.SIG.PrimyPohyb)))
				{	
					sigMakeStraightMove(flag,(Notation.SIG.PrimyPohyb)partOfMove,lengthFactor);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.Kyvani)))
				{
					sigMakeSwingMove(flag,(Notation.SIG.Kyvani)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.AtomZmenaDEZ)))
				{
					sigMakeDezMove(flag,(Notation.SIG.AtomZmenaDEZ)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.OtviraniZaviraniRuky)))
				{	
					sigMakeDEZMove2(flag,(Notation.SIG.OtviraniZaviraniRuky)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().IsSubclassOf(typeof(Notation.SIG.Kontakt)))
				{
					//pohyb se provede jen pokud je to atomick� pohyb, kter� nen� sou��st� simult�ln�ho
					if(action == 0)
						sigMakeContactMove(flag,(Notation.SIG.Kontakt)partOfMove);
					
					if(partOfMove.GetType().Equals(typeof(Notation.SIG.KKdeTelo)))
						return 2;
					else
						return 1;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.KruhovyPohyb)))
				{
					sigMakeCircleMove(flag,(Notation.SIG.KruhovyPohyb)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.OtaceniPaze)))
				{
					sigMakeWheelMove(flag,(Notation.SIG.OtaceniPaze)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.KrouceniZapestim)))
				{
					sigMakeRoundMove(flag,(Notation.SIG.KrouceniZapestim)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.ObloukovyPohyb)))
				{
					sigMakeCurveMove(flag,(Notation.SIG.ObloukovyPohyb)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.Vsunuti)))
				{
					sigMakeInsideMove(flag,(Notation.SIG.Vsunuti)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.Zkrizeni)))
				{
					sigMakeCrossMove(flag,(Notation.SIG.Zkrizeni)partOfMove);
					return 0;
				}
				if(partOfMove.GetType().Equals(typeof(Notation.SIG.Vymena)))
				{
					sigMakeChangeMove(flag);
					return 0;
				}
				return 0;
			}
			/// <summary>
			/// Zpracov�n� a nastaven� faktor� pro dal�� v�po�et atomick�ho pohybu. V p��pad�, �e je to kontaktn� pohyb
			/// na t�le je odkaz na tento pohyb uchov�n pro zpracov�n� dal��ch pohyb�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se pohyb prov�d�. 0 - lev�, 1 - prav�.</param>
			/// <param name="partOfMove">Atomick� pohyb.</param>
			/// <param name="finishTime">�as ve kter�m m� tento pohyb skon�it.</param>
			/// <param name="quickFactor">Faktor rychlosti pohybu.</param>
			/// <param name="lengthFactor">Faktor d�lky pohybu.</param>
			/// <param name="currentTime">Aktu�ln� �as pro znakov�n�.</param>
			static public void useAtomicMoves(int flag,Notation.SIG.PrvekPohybu partOfMove,int finishTime,int quickFactor,int lengthFactor,ref int currentTime)
			{
				if(((flag != 1) && (flag != 0))||(partOfMove == null) || (finishTime < 0) || (quickFactor < 0) || (lengthFactor < 0))
					throw new GenException.ParameterException("flag: " + flag + ", " + "partOfMove: " + (partOfMove == null ? "NULL":"NOT NULL") + ", " +
						"lengthFactor: " + lengthFactor + ", " + "quickFactor: " + quickFactor + ", " + "finishTime: " + finishTime);

				Joint[] hand;
				int contactType;

				if(flag == 0)
					hand = leftHand;
				else 
					hand = rightHand;

				int numberOfRepeat = 1;

				if(partOfMove.modifikatoryPohybu != null)
				{
					foreach (Notation.SIG.ModifikatorPohybu modif in partOfMove.modifikatoryPohybu)
					{
						if(modif == Notation.SIG.ModifikatorPohybu.prudkyPohyb)
							quickFactor *= 2;

						if(modif == Notation.SIG.ModifikatorPohybu.kratkyPohyb)
						{
							lengthFactor *= 2;
							quickFactor *= 2;
						}
			
						if(modif == Notation.SIG.ModifikatorPohybu.opakovanyPohyb)
							numberOfRepeat = numberOfMoveRepeat;
					}
				}

				int timeOfMove = minTimeUnit/quickFactor;
				double untilTime,fromTime;

				for(int krok =1;krok<= numberOfRepeat;krok++)
				{	
					fromTime = currentTime * (1/(double)finishTime);
					untilTime = fromTime + ((double)timeOfMove* (1/(double)finishTime));

					contactType = makeSelectAtomicMove(flag,partOfMove,lengthFactor,0);
					createInterpolatorKey(flag,untilTime);
					useRotationToFinalRotation(flag);

					currentTime += timeOfMove;
					//kontakt na t�le
					if(contactType == 2)
					{
						if(flag == 0)
							circleContactL = (Notation.SIG.KKdeTelo)copyOfAtomicElement((Notation.SIG.AtomickyPohyb)partOfMove);
						else
							circleContactP = (Notation.SIG.KKdeTelo)copyOfAtomicElement((Notation.SIG.AtomickyPohyb)partOfMove);
					}
					else
					{
						if(flag == 0)
							circleContactL = null;
						else 
							circleContactP = null;
					}
				}
			}

			/// <summary>
			/// Smaz�n� seznam� rotac� pro v�echny typy pohyb� pro ruku zadanou v parametru.
			/// </summary>
			/// <param name="flag">Identifikace ruky pro kterou se m� akce prov�st. 0 - lev�, 1 - prav�.</param>
			static public void clearAllListsOfLocalRotations(int flag)
			{
				if((flag != 1) && (flag != 0))
					throw new GenException.ParameterException("flag: " + flag);
				
				Joint[] hand;
				int joint;

				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;

				for(joint = 0; joint < numberJointHand;joint++)
				{
					hand[joint].moveLocalRotations.Clear();
					hand[joint].interpolatorRotations.Clear();
				}
			}

			/// <summary>
			/// Kopie vrml rotac� do kopi� nebo opa�n�. Z�v�s� na parametru action.
			/// </summary>
			/// <param name="flag">Identifikace ruky pro kterou se m� akce prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="action">0 - zkop�ruj vrml rotace do copie. 1 - zkop�ruj copie do vrml rotac�.</param>
			static public void copyVrmlRot(int flag, int action)
			{
				if((flag != 1) && (flag != 0)|| ((action != 0) && (action != 1)))
					throw new GenException.ParameterException("flag: " + flag + ", " + "action: " + action);
				
				Joint[] hand;
				int joint;

				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;

				for(joint = 0; joint < numberJointHand;joint++)
				{
					if(action == 0)
						hand[joint].copyOfVrmlRot.copyRotation(hand[joint].vrmlRotation);
					else
						hand[joint].vrmlRotation.copyRotation(hand[joint].copyOfVrmlRot);
				}
			}
			/// <summary>
			/// Zav�en� seznamu rotac� do seznamu v�ech rotac� simult�ln�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace ruky pro kterou se m� akce prov�st. 0 - lev�, 1 - prav�.</param>
			static public void copyAllListsWithLocalRotToBigList(int flag)
			{
				if((flag != 1) && (flag != 0))
					throw new GenException.ParameterException("flag: " + flag);
				
				Joint[] hand;
				int joint;

				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;
				
				System.Collections.ArrayList tmpList;

				for(joint = 0; joint < numberJointHand;joint++)
				{
					//pohyb nevygeneroval pro tento kloub ��dn� rotace, je zbyte�n� aby se kop�rovaly d�l
					if(hand[joint].moveLocalRotations.Count == 0)
						continue;
					
					tmpList = (System.Collections.ArrayList)hand[joint].moveLocalRotations.Clone();
					hand[joint].simultalMoveRotationsLists.Add(tmpList);
				}
				
			}
			/// <summary>
			/// Nejv�t�� spole�n� d�litel hodnot zadan�ch v parametrech.
			/// </summary>
			/// <param name="x">Hodnota pro v�po�et.</param>
			/// <param name="y">Hodnota pro v�po�et.</param>
			/// <returns>Nejv�t�� spole�n� d�litel</returns>
			static public int gcd(int x, int y)
			{
				while((x > 0) && (y > 0))
				{
					if(x>y)
						x = x % y;
					else
						y = y % x;
				}
				if(x == 0)
					return y;
				else
					return x;
			}
			/// <summary>
			/// Nejmen�� spole�n� n�sobek hodnot zadan�ch v parametrech.
			/// </summary>
			/// <param name="x">Hodnota pro v�po�et.</param>
			/// <param name="y">Hodnota pro v�po�et.</param>
			/// <returns>Nejmen�� spole�n� n�sobek.</returns>
			public static int lcm(int x, int y)
			{
				return x * y / gcd(x,y);
			}

			/// <summary>
			/// Vytvo�en� kone�n�ho seznamu rotac� pro simult�ln� pohyb. Je provedena interpolace mezi jednotliv�mi
			/// seznami rotac� pohyb� simult�n�ho. Rotace v�sledn�ho seznamu jsou postupn� slo�eny s rotac� aktu�ln�.
			/// </summary>
			/// <param name="flag">Identifikace ruky pro kterou se m� akce prov�st. 0 - lev�, 1 - prav�.</param>
			static public void composeAllRotationFromBigListsToActualRot(int flag)
			{
				if((flag != 1) && (flag != 0))
					throw new GenException.ParameterException("flag: " + flag);

				Joint[] hand;
				int joint;
				System.Collections.ArrayList partOfList;
				Joint.Rotation tmpRotToCompose;
				int rot;
				int lcmNumberOfRot = 1;
				int numberOfRotInMove  = 0;
				int positionOfRot = 0;
				Joint.Rotation parOfRot = new Joint.Rotation();
				
				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;
				for(joint = 0; joint < numberJointHand;joint++)
				{
					// nastavit na nulovou rotaci
					hand[joint].interpolatorRotations.Clear();

					// list obsahuje alespo� jeden seznam rotac� pohybu
					if(hand[joint].simultalMoveRotationsLists.Count != 0)
					{
						lcmNumberOfRot = 1;
						foreach( System.Collections.ArrayList listOfRot in hand[joint].simultalMoveRotationsLists)					
						{
							if(listOfRot.Count != 0)
							{
								// nejmen�� spole�n� n�sobek 
								lcmNumberOfRot = lcm(lcmNumberOfRot,listOfRot.Count);
							}
						}
						//list obsahuje alespo� n�jak� seznam s rotacemi,nejsou v�echny pohyby mimo tento kloub
						if(lcmNumberOfRot != 0)
						{
							// vytvo�en� seznamu nulov�ch rotac�, po�et odpov�d� poctu deleni, tedy lcm vsech poctu rotaci v listu
							for(int pos = 0;pos < lcmNumberOfRot; pos++)
							{
								hand[joint].interpolatorRotations.Add(new Joint.Rotation());
							}

							// slo�en� v�ech odpov�daj�c�ch rotac� do jednoho listu
							// postupuje se v�dy po pohybech, pro pohyb se zpracuj� v�echny rotace
							for(int list = 0; list < hand[joint].simultalMoveRotationsLists.Count; list++ )
							{								
								partOfList = (System.Collections.ArrayList)hand[joint].simultalMoveRotationsLists[list];
								// skute�n� po�et rotac� v listu pohybu
								numberOfRotInMove = partOfList.Count;			

								for(rot =0 ; rot < lcmNumberOfRot; rot++)
								{	
									// pozice realn� rotace pohybu kter� se m� pou��t
									positionOfRot = rot / (int)((double)lcmNumberOfRot/numberOfRotInMove);
									// rotace kter� se m� pou��t
									parOfRot.copyRotation((Joint.Rotation)partOfList[positionOfRot]);
									// odpov�daj�c� ��st rotace
									parOfRot.angle = parOfRot.angle * ((double)numberOfRotInMove/lcmNumberOfRot);

									tmpRotToCompose = (Joint.Rotation)hand[joint].interpolatorRotations[rot];

									hand[joint].composeRotation(parOfRot,ref tmpRotToCompose,1);
								}
							}
							// lokalni zmena rotace se musi slozit s rotaci, ktera by provedena pred tim, aby se docililo celkove rotace kam se chceme dostat
							foreach (Joint.Rotation rotToCompose in hand[joint].interpolatorRotations)
							{
								hand[joint].composeRotation(rotToCompose,ref hand[joint].copyOfVrmlRot,1);								
								rotToCompose.copyRotation(hand[joint].copyOfVrmlRot);
							}
							// pokud vse od stejneho mista taky prekopirovat copii vrm rotace do vrml rotace, melo by
							// byt celkova rotace, jeliko slozene lokalni byly slozeny s copii a to by mela byt vysledna rotace ve ktere 
							// se kloub nachazi
							
						}
					}					
					hand[joint].simultalMoveRotationsLists.Clear();
				}
				copyVrmlRot(flag,1);
			}

			/// <summary>
			/// V seznamu pohyb� hled� kontaktn� pohyb na t�le.
			/// </summary>
			/// <param name="atomickePohyby">Seznam atomick�ch pohyb�.</param>
			/// <param name="contact">Nalezen� kontakt.V p��pad� neusp�chu nastaven na NULL.</param>
			static public void findContactBodyInList(System.Collections.ArrayList atomickePohyby, ref Notation.SIG.KKdeTelo contact)
			{
				contact = null;
				foreach (Notation.SIG.AtomickyPohyb move in atomickePohyby)
				{
					if(move.GetType().Equals(typeof(Notation.SIG.KKdeTelo)))
					{
						contact = (Notation.SIG.KKdeTelo)move;
						return;
					}
				}				
			}
			/// <summary>
			/// Zpracov�n� simult�ln�ho  pohybu. Nastaven� faktor�. Ka�d� atomick� pohyb simult�ln�ho pohybu se po��t� ze stejn�
			/// v�choz� pozice modelu. V p��pad�, �e je atomick� pohyb kontakt, je jeho v�po�et ponech�n na konec. 
			/// </summary>
			/// <param name="prvekP">Simult�ln� pohyb prav� ruky.</param>
			/// <param name="prvekL">Simult�ln� pohyb lev� ruky.</param>
			/// <param name="finishTimeP">�as ve kter�m m� simul�ln� pohyb prav� ruky  skon�it.</param>
			/// <param name="finishTimeL">�as ve kter�m m� simul�ln� pohyb lev� ruky  skon�it.</param>
			/// <param name="currentTimeP">Aktu�ln� �as pro pravou ruku.</param>
			/// <param name="currentTimeL">Aktu�ln� �as pro levou ruku.</param>
			static public void useSimultalMoves(Notation.SIG.SimultanniPohyb prvekP,Notation.SIG.SimultanniPohyb prvekL,int finishTimeP,int finishTimeL,ref int currentTimeP,ref int currentTimeL)
			{
				if(((prvekP == null) && (prvekL == null)) || (finishTimeL < 0) || (finishTimeP < 0) || (currentTimeP < 0) || (currentTimeL < 0))
					throw new GenException.ParameterException("prvekP: " + (prvekP == null ? "NULL":"NOT NULL") + ", " + "prvekL: " + (prvekL == null ? "NULL":"NOT NULL") + ", " + "finishTimeP: " + finishTimeP +
						"finishTimeL: " + finishTimeL + "currentTimeP: " + currentTimeP + ", " + "currentTimeL: " + currentTimeL);

				if(((prvekP != null) &&  ((prvekP.atomickePohyby == null) || (prvekP.atomickePohyby.Count == 0))) || ((prvekL != null) &&  ((prvekL.atomickePohyby == null) || (prvekL.atomickePohyby.Count == 0))))
				{return;}
				
				int isContactP = 0;
				int isContactL = 0;
				int typeOfMove = 0;
				int quickFactor = 0;
				int lengthFactor = 0;
				double untilTimeP = 0;
				double untilTimeL = 0;
				double fromTimeP = 0;
				double fromTimeL = 0;
				int timeOfMoveL = 0;
				int timeOfMoveP = 0;
				int flag = 1;
				int id = 0;
				Joint.Vector firstBody = new Joint.Vector();
				Joint.Vector secondBody = new Joint.Vector();

				Notation.SIG.Kontakt contactL = null;
				Notation.SIG.Kontakt contactP = null;
				Notation.SIG.KruhovyPohyb circleMove;
				Notation.SIG.KKdeTelo secondContact = null;
				Notation.SIG.KKdeTelo contact = null;

				for(int move = 0; move < 2; move++)
				{
					Notation.SIG.SimultanniPohyb simultalPartOfMove;
					quickFactor = 1;
					lengthFactor = 1;

					if(move == 0)
					{
						simultalPartOfMove = prvekP;
					}
					else
					{
						simultalPartOfMove = prvekL;
					}
					// pohyby nezpracov�vat
					if(simultalPartOfMove == null)
						continue;

					if(simultalPartOfMove.modifikatoryPohybu != null)
					{
						foreach (Notation.SIG.ModifikatorPohybu modif in simultalPartOfMove.modifikatoryPohybu)
						{
							if(modif == Notation.SIG.ModifikatorPohybu.prudkyPohyb)
								quickFactor *= 2;

							if(modif == Notation.SIG.ModifikatorPohybu.kratkyPohyb)
							{
								lengthFactor *= 2;
								quickFactor *= 2;
							}
						}
					}

					if(move == 0)
					{
						timeOfMoveP = minTimeUnit/quickFactor;
						fromTimeP = currentTimeP * (1/(double)finishTimeP);
						untilTimeP = fromTimeP + ((double)timeOfMoveP * (1/(double)finishTimeP));
						isContactP = 0;
						flag = 1;
					}
					else
					{
						timeOfMoveL = minTimeUnit/quickFactor;
						fromTimeL = currentTimeL * (1/(double)finishTimeL);
						untilTimeL = fromTimeL + ((double)timeOfMoveL * (1/(double)finishTimeL));
						isContactL = 0;
						flag = 0;
					}

					typeOfMove = 0;
					//zapamatujeme si aktualni rotace ve vrml
					copyVrmlRot(flag,0);

					// predzpracovani kvuli kontaktum kontakt uz se musi pocitac aktualnich vrmlrotaci
					foreach (Notation.SIG.AtomickyPohyb pohyb in simultalPartOfMove.atomickePohyby)
					{
						if(pohyb != null)
						{
							// smaze u kazdeho kloubu list ktery obsahuje lokalni rotace
							clearAllListsOfLocalRotations(flag);

							if(pohyb.GetType().Equals(typeof(Notation.SIG.KruhovyPohyb)))
							{
								circleMove = (Notation.SIG.KruhovyPohyb)pohyb;
								if((circleMove.cast == Notation.SIG.CastKruhu.pul) && (((move == 1) && (circleContactL != null)) || ((move == 0) && (circleContactP != null))))
								{
									findContactBodyInList(simultalPartOfMove.atomickePohyby, ref secondContact);
									if(secondContact != null)
									{
										getContactPointFromFile(secondContact.kde.ToString(),coordToContactFileName,ref secondBody,ref id);
										if(move == 1)
										{
											getContactPointFromFile(circleContactL.kde.ToString(),coordToContactFileName,ref firstBody,ref id);
										}
										else
										{
											getContactPointFromFile(circleContactP.kde.ToString(),coordToContactFileName,ref firstBody,ref id);
											
										}										
										circleMove.prumer = getDistancePoints(secondBody,firstBody); 
									}
								}
							}
							typeOfMove = makeSelectAtomicMove(flag,pohyb,lengthFactor,1);
							if(typeOfMove == 0) // neni kontakt
							{
								//pro kazdy kloub prida list rotaci(lokalnich) do vydledneho seznamu
								copyAllListsWithLocalRotToBigList(flag);
								// v pripade, ze rotace ze stejneho mista, pak zde nakopirovat copii vrml do vrml rotace
								copyVrmlRot(flag,1);
							}
							else
							{  //odkaz na kontakt v seznamu pohyb�
								if(move == 1)
								{
									isContactL = typeOfMove;
									contactL = (Notation.SIG.Kontakt)pohyb;
								}
								else
								{
									isContactP = typeOfMove;
									contactP = (Notation.SIG.Kontakt)pohyb;
								}
							}
						}
					
					}
					// porovna pocet rotaci v kazdem prvku listu, ktery obsahuje listy, pokud odpovidaji, prvni 
					//se prekopiruje do listu actualRotations a ostatni listy se s temito rotacemi slozi, prvni z prvni, atd.
					//smaze se list listu
					composeAllRotationFromBigListsToActualRot(flag);

					//pokud simultalni pohyb obsahuje kontakt uloz jej 
					findContactBodyInList(simultalPartOfMove.atomickePohyby, ref contact);
					if(contact != null)
					{
						if(move == 0)
							circleContactP = (Notation.SIG.KKdeTelo)copyOfAtomicElement(contact);
						else
							circleContactL = (Notation.SIG.KKdeTelo)copyOfAtomicElement(contact);
					}

				}
				// prov�st kontakt, rotace se p�idaj� do listu interpolatorRotations
				if((isContactL != isContactP) && (prvekL != null) && (prvekP != null))
					throw new GenException.NotationException("Kontakt na prav� a lev� ruce nen� shodn�.");

				if((isContactP > 0) && (contactP != null))
					sigMakeContactMove(1,contactP);

				if((isContactL > 0) && (contactL != null))
					sigMakeContactMove(0,contactL);

				if(prvekP != null)
				{
					createInterpolatorKey(1,untilTimeP);
					useRotationToFinalRotation(1);
				}
				if(prvekL != null)
				{
					createInterpolatorKey(0,untilTimeL);
					useRotationToFinalRotation(0);
				}
				if((timeOfMoveL == timeOfMoveP) || ((prvekL == null) || (prvekP == null)) )
				{
					currentTimeL += timeOfMoveL;					
					currentTimeP += timeOfMoveP;
				}
				else
					throw new GenException.NotationException("Nesouhlas� d�lka pohybu.");
			}
			/// <summary>
			/// Kopie v�ech modifik�tor� z jednoho seznamu do druh�ho.
			/// </summary>
			/// <param name="sequenceModif">Modifik�tory kter� jsou vzorem.</param>
			/// <param name="elementModif">Nov� pole modifik�tor�.</param>
			static public void jointModifList(System.Collections.ArrayList sequenceModif, ref System.Collections.ArrayList elementModif)
			{
				if((sequenceModif == null) || (elementModif == null))
					throw new GenException.ParameterException("sequenceModif: " + (sequenceModif == null ? "NULL":"NOT NULL")+ ", " + "elementModif: " + (elementModif == null ? "NULL":"NOT NULL"));

				foreach (Notation.SIG.ModifikatorPohybu modifToAdd in sequenceModif)
				{
					elementModif.Add(modifToAdd);
				}
			}
			/// <summary>
			/// Provede kopii sekven�n�ho pohybu. Provede kopie v�ech modifik�tor�. Vnit�n� pohyby jsou kop�rov�ny 
			/// pouze jako odkazy.
			/// </summary>
			/// <param name="sequence">Vzor pro kopii sekvence.</param>
			/// <returns>Kopie prvku sekvence pohybu zadan�ho v parametru.</returns>
			static public Notation.SIG.SekvencePohybu copyOfSequence(Notation.SIG.SekvencePohybu sequence)
			{	
				if(sequence == null)
					return null;
				
				Notation.SIG.SekvencePohybu newSequence = new Notation.SIG.SekvencePohybu();

				foreach (Notation.SIG.PrvekPohybu element in sequence.prvkySekvencePohybu)
				{
					newSequence.prvkySekvencePohybu.Add(element);
				}

				foreach (Notation.SIG.ModifikatorPohybu modif in sequence.modifikatoryPohybu)
				{
					newSequence.modifikatoryPohybu.Add(modif);
				}
				return newSequence;

			}
			/// <summary>
			/// Kopie dle typu atomick�ho pohybu. Vytvo�en� nov� instance a kopie z p�vodn�, v�etn� modifik�tor�.
			/// </summary>
			/// <param name="element">P�edloha pro kopii.</param>
			/// <returns>Kopie atomick�ho pohybu.</returns>			
			static public Notation.SIG.AtomickyPohyb copyOfAtomicElement(Notation.SIG.AtomickyPohyb element)
			{
				if(element == null)
					return null;

				Notation.SIG.AtomickyPohyb moveToAdd;
								
				if(element.GetType().Equals(typeof(Notation.SIG.PrimyPohyb)))
				{	
					Notation.SIG.PrimyPohyb newMove = new Notation.SIG.PrimyPohyb();
					Notation.SIG.PrimyPohyb oldMove = (Notation.SIG.PrimyPohyb)element;
					
					newMove.hodnota = oldMove.hodnota;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.Kyvani)))
				{
					Notation.SIG.Kyvani newMove = new Notation.SIG.Kyvani();
					Notation.SIG.Kyvani oldMove = (Notation.SIG.Kyvani)element;
					
					newMove.jake = oldMove.jake;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.AtomZmenaDEZ)))
				{
					Notation.SIG.AtomZmenaDEZ newMove = new Notation.SIG.AtomZmenaDEZ();
					Notation.SIG.AtomZmenaDEZ oldMove = (Notation.SIG.AtomZmenaDEZ)element;

					newMove.jaka = oldMove.jaka;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.OtviraniZaviraniRuky)))
				{	
					Notation.SIG.OtviraniZaviraniRuky newMove = new Notation.SIG.OtviraniZaviraniRuky();
					Notation.SIG.OtviraniZaviraniRuky oldMove = (Notation.SIG.OtviraniZaviraniRuky)element;

					newMove.koncovyTvar = oldMove.koncovyTvar;
					newMove.ktere = oldMove.ktere;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.KKdeTelo)))
				{
					Notation.SIG.KKdeTelo newMove = new Notation.SIG.KKdeTelo();
					Notation.SIG.KKdeTelo oldMove = (Notation.SIG.KKdeTelo)element;

					newMove.kde = oldMove.kde;
					if(oldMove.cim != null)
					{
						newMove.cim = new Notation.KdeRuka[oldMove.cim.Length];
						for(int i=0; i < oldMove.cim.Length ; i++)
						{
							newMove.cim[i] = oldMove.cim[i];
						}
					}
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.KKdeRuka)))
				{
					Notation.SIG.KKdeRuka newMove = new Notation.SIG.KKdeRuka();
					Notation.SIG.KKdeRuka oldMove = (Notation.SIG.KKdeRuka)element;

					if(oldMove.kde != null)
					{
						newMove.kde = new Notation.KdeRuka[oldMove.kde.Length];
						for(int i= 0; i < oldMove.kde.Length; i++)
						{
							newMove.kde[i] = oldMove.kde[i];
						}
					}
					if(oldMove.cim != null)
					{
						newMove.cim = new Notation.KdeRuka[oldMove.cim.Length];
						for(int i=0; i < oldMove.cim.Length ; i++)
						{
							newMove.cim[i] = oldMove.cim[i];
						}
					}
					
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.KruhovyPohyb)))
				{
					Notation.SIG.KruhovyPohyb newMove = new Notation.SIG.KruhovyPohyb();
					Notation.SIG.KruhovyPohyb oldMove = (Notation.SIG.KruhovyPohyb)element;

					newMove.cast = oldMove.cast;
					newMove.cislo = oldMove.cislo;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.OtaceniPaze)))
				{
					Notation.SIG.OtaceniPaze newMove = new Notation.SIG.OtaceniPaze();
					Notation.SIG.OtaceniPaze oldMove = (Notation.SIG.OtaceniPaze)element;

					newMove.kam = oldMove.kam;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.KrouceniZapestim)))
				{
					Notation.SIG.KrouceniZapestim newMove = new Notation.SIG.KrouceniZapestim();
					Notation.SIG.KrouceniZapestim oldMove = (Notation.SIG.KrouceniZapestim)element;

					newMove.jak = oldMove.jak;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.ObloukovyPohyb)))
				{
					Notation.SIG.ObloukovyPohyb newMove = new Notation.SIG.ObloukovyPohyb();
					Notation.SIG.ObloukovyPohyb oldMove = (Notation.SIG.ObloukovyPohyb)element;

					newMove.cast= oldMove.cast;
					newMove.cislo = oldMove.cislo;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.Vsunuti)))
				{
					Notation.SIG.Vsunuti newMove = new Notation.SIG.Vsunuti();
					Notation.SIG.Vsunuti oldMove = (Notation.SIG.Vsunuti)element;
					
					if(oldMove.kdeNaRuce != null)
					{
						newMove.kdeNaRuce = new Notation.KdeRuka[oldMove.kdeNaRuce.Length];
						for(int i= 0; i < oldMove.kdeNaRuce.Length; i++)
						{
							newMove.kdeNaRuce[i] = oldMove.kdeNaRuce[i];
						}
					}
					if(oldMove.cim != null)
					{
						newMove.cim = new Notation.KdeRuka[oldMove.cim.Length];
						for(int i=0; i < oldMove.cim.Length ; i++)
						{
							newMove.cim[i] = oldMove.cim[i];
						}
					}
					newMove.kdeNaTele = oldMove.kdeNaTele;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.Zkrizeni)))
				{
					Notation.SIG.Zkrizeni newMove = new Notation.SIG.Zkrizeni();
					Notation.SIG.Zkrizeni oldMove = (Notation.SIG.Zkrizeni)element;

					newMove.smerLeva = oldMove.smerLeva;
					newMove.smerPrava = oldMove.smerPrava;
					moveToAdd = newMove;
				}
				else if(element.GetType().Equals(typeof(Notation.SIG.Vymena)))
				{
					Notation.SIG.Vymena newMove = new Notation.SIG.Vymena();										
					moveToAdd = newMove;
				}
				else
					return null;

				foreach (Notation.SIG.ModifikatorPohybu modif in element.modifikatoryPohybu)
				{
					moveToAdd.modifikatoryPohybu.Add(modif);
				}
				return moveToAdd;
			}
			/// <summary>
			/// Kopie pohybu atomick�ho nebo simult�ln�ho v�etn� modifik�tor�. V p��pad� simult�ln�ho pohybu
			/// jsou jeho atomick� pohyby zkop�rov�ny jako odkazy.
			/// </summary>
			/// <param name="element">P�edloha kopie.</param>
			/// <returns>Kopie pohybu.</returns>
			static public Notation.SIG.PrvekPohybu copyOfElement(Notation.SIG.PrvekPohybu element)
			{
				if(element == null)
					return null;

				Notation.SIG.SimultanniPohyb copyOfSimultal;
				Notation.SIG.SimultanniPohyb originalSimultal;

				if((element.GetType().IsSubclassOf(typeof(Notation.SIG.AtomickyPohyb))))
				{
					return (Notation.SIG.PrvekPohybu)copyOfAtomicElement((Notation.SIG.AtomickyPohyb)element);
				}
				else if((element.GetType().Equals(typeof(Notation.SIG.SimultanniPohyb))))
				{
					copyOfSimultal = new Notation.SIG.SimultanniPohyb();
					originalSimultal = (Notation.SIG.SimultanniPohyb)element;

					foreach (Notation.SIG.AtomickyPohyb atomicElement in originalSimultal.atomickePohyby)
					{
						copyOfSimultal.atomickePohyby.Add(copyOfAtomicElement(atomicElement));
					}
					// kopie modifik�tor� pro cel� simult�ln� pohyb
					foreach (Notation.SIG.ModifikatorPohybu modif in originalSimultal.modifikatoryPohybu)
					{
						copyOfSimultal.modifikatoryPohybu.Add(modif);
					}
					return (Notation.SIG.PrvekPohybu)copyOfSimultal;
				}
				else 
					throw new GenException.NotationException("Nezn�m� typ prvku pohybu pro copii pohybu.");
					
			}

			/// <summary>
			/// Zjednodu�en� z�pisu pohybu. Vytvo�en� nov� instance pohybu kde jsou jen atomick� a simult�ln� pohyby.
			/// Sekven�n� pohyby jsou rozd�leny na jejich prvky. Prvk�m jsou p�id�ny modifik�tory, kter� obsahoval 
			/// sekven�n� pohyb. V p��pad� opakov�n� simult�ln�ho a sekven�n�ho pohybu jsou tyto pohyby vlo�eny do nov�
			/// instance v po�tu, kter� ud�v� opakov�n�.
			/// </summary>
			/// <param name="oldNotation">P�edloha pohybu pro zjednodu�en�.</param>
			/// <returns>Nov� zjednodu�en� notace pohybu.</returns>
			static public Notation.SIG flatNotation(Notation.SIG oldNotation)
			{
				if(oldNotation == null)
					return null;

				Notation.SIG.PrvekPohybu elementToAdd;
				Notation.SIG.SekvencePohybu copyOfSequenceElement;

				Notation.SIG newNotation = new Notation.SIG();
 
				foreach (Notation.SIG.PrvekPohybu element in oldNotation.prvkyPohybu)
				{
					if(element != null)
					{
						for(int i = 0; (i == 0) ||((element.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.opakovanyPohyb)) && (i < numberOfMoveRepeat)); i++)
						{
							if((element.GetType().IsSubclassOf(typeof(Notation.SIG.AtomickyPohyb))) || (element.GetType().Equals(typeof(Notation.SIG.SimultanniPohyb))))
							{
								// vytvor kopii atomickeho nebo simultalniho pohybu
								elementToAdd = copyOfElement(element);
								// odnastav opakovaci modifikator
								if((elementToAdd.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.opakovanyPohyb)))
								{
									elementToAdd.modifikatoryPohybu.Remove(Notation.SIG.ModifikatorPohybu.opakovanyPohyb);
								}
								newNotation.prvkyPohybu.Add(elementToAdd);
							}
							else
							{
								//udelej kopii pole sekvencnich pohybu, jednotlive vnitrni prvky budou jen odkazy z puvodni notace, nebudou se menit
								copyOfSequenceElement = copyOfSequence((Notation.SIG.SekvencePohybu)element);
								//zrus opakovani bude tolikrat kopie v hlavnim seznamu
								if((copyOfSequenceElement.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.opakovanyPohyb)))
								{
									copyOfSequenceElement.modifikatoryPohybu.Remove(Notation.SIG.ModifikatorPohybu.opakovanyPohyb);
								}

								foreach (Notation.SIG.PrvekPohybu elementInSequence in copyOfSequenceElement.prvkySekvencePohybu)
								{
									for(int j = 0; (j == 0) ||((elementInSequence.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.opakovanyPohyb)) && (j < numberOfMoveRepeat)); j++)
									{
										elementToAdd = copyOfElement(elementInSequence);
										if((elementToAdd.modifikatoryPohybu.Contains(Notation.SIG.ModifikatorPohybu.opakovanyPohyb)))
										{
											elementToAdd.modifikatoryPohybu.Remove(Notation.SIG.ModifikatorPohybu.opakovanyPohyb);
										}
										jointModifList(copyOfSequenceElement.modifikatoryPohybu, ref elementToAdd.modifikatoryPohybu);
										newNotation.prvkyPohybu.Add(elementToAdd);
									}	
								}
							}
						}
					}
				}
				return newNotation;
			}
			/// <summary>
			/// Zpracov�n� pohybu lev� a prav� ruky.
			/// </summary>
			/// <param name="sigP">Pohyb prav� ruky po zjednodu�en�.</param>
			/// <param name="sigL">Pohyb lev� ruky po zjednodu�en�.</param>
			static public void useSigMoves(Notation.SIG sigP,Notation.SIG sigL)
			{
				int finishTimeP = 0;
				int finishTimeL = 0;
				int currentTimeP = 0;
				int currentTimeL = 0;

				if((sigP == null) && (sigL == null))
					return;

				// predzpracovani, zjisteni celkoveho poctu jednotek casu
				if(sigP != null)
				{
					foreach(Notation.SIG.PrvekPohybu prvek in sigP.prvkyPohybu)
					{
						if(prvek !=  null)
							finishTimeP += getSigTime(prvek);
					}
				}
				if(sigL != null)
				{
					foreach(Notation.SIG.PrvekPohybu prvek in sigL.prvkyPohybu)
					{
						if(prvek !=  null)
							finishTimeL += getSigTime(prvek);
					}
				}

				if((sigL != null) && (sigP != null) && ((finishTimeL != finishTimeP) || (sigP.prvkyPohybu.Count != sigL.prvkyPohybu.Count)))
					throw new GenException.NotationException("Po�et �asov�ch jednotek nebo po�et pohyb� v seznamu je pro pohyby rukou r�zn�.");
				
				cyrcleTimeL = finishTimeL;
				cyrcleTimeP = finishTimeP;

				Notation.SIG.PrvekPohybu prvekL;
				Notation.SIG.PrvekPohybu prvekP;

				for(int i= 0; i < (sigL == null ? sigP.prvkyPohybu.Count : sigL.prvkyPohybu.Count);i++)
				{
					int correctType = 0;

					prvekL = (sigL == null) ? null : (Notation.SIG.PrvekPohybu)sigL.prvkyPohybu[i];
					prvekP = (sigP == null) ? null : (Notation.SIG.PrvekPohybu)sigP.prvkyPohybu[i];

					// alespon jeden neni null
					if((prvekL != null) || (prvekP != null))
					{

						if((prvekP != null) && (prvekP.GetType().IsSubclassOf(typeof(Notation.SIG.AtomickyPohyb))))
						{
							useAtomicMoves(1,prvekP,finishTimeP,1,1,ref currentTimeP);
							correctType = 1;
						}
						if((prvekL != null) && (prvekL.GetType().IsSubclassOf(typeof(Notation.SIG.AtomickyPohyb)))) 
						{
							useAtomicMoves(0,prvekL,finishTimeL,1,1,ref currentTimeL);
							correctType = 1;
						}

						if(((prvekP == null) || (prvekP.GetType().Equals(typeof(Notation.SIG.SimultanniPohyb)))) && ((prvekL == null) || (prvekL.GetType().Equals(typeof(Notation.SIG.SimultanniPohyb)))))
						{
							useSimultalMoves((Notation.SIG.SimultanniPohyb)prvekP,(Notation.SIG.SimultanniPohyb)prvekL,finishTimeP,finishTimeL,ref currentTimeP,ref currentTimeL);
							correctType = 1;
						}
						if(correctType == 0)
							throw new GenException.NotationException("Nezn�m� typ v seznamu prvk� pohybu.");
					}
				}
	
			}

			/// <summary>
			/// V�po�et skute�n�ho indexu kloubu ve struktu�e.
			/// </summary>
			/// <param name="finger">Index prstu. ��slov�no od mal��ku.</param>
			/// <param name="joint">Kolikaty je to kloub v po�ad� od ramene. Tedy na p��m� cest�.</param>
			/// <returns>Vrac� skute�n� index kloubu ve struktu�e.</returns>
			static public int getIndexOfNthJoint(int finger,int joint)
			{
				if((finger == 0) && (joint > 2))
					throw new GenException.ParameterException("finger: " + finger + ", " + "joint: " + joint);
				else if(joint <=2)
					return joint;
				else
					return finger*3 + joint -3; 
			}

			/// <summary>
			/// V�po�et ke kter�mu prstu index kloubu pat�� a kolik�t� je to kloub na p��m� cest� od ramene.
			/// </summary>
			/// <param name="indexOfJoint">Skute�n� index kloubu.</param>
			/// <param name="finger">��slo prstu, ��slov�no od 1 po��naje mal��kem.Pokud je number < 3 pak finger je 0.</param>
			/// <param name="number">Kolik�ty kloub od ramene na p��m� cest�. Rameno index 0.</param>
			static public void getFingerAndNumberOfJointOnWay(int indexOfJoint,ref int finger,ref int number)
			{
				if(indexOfJoint <= 2)
				{
					number = indexOfJoint;
					finger = 0;
				}
				else if (indexOfJoint < numberJointHand)
				{
					finger = indexOfJoint / 3; //celociselne deleni
					number = 3 + (indexOfJoint % 3);
				}
				else
					throw new GenException.ParameterException("Parametr indexOfJoint je mimo rozsah, indexOfJoint: " + indexOfJoint + ".");
			}

			/// <summary>
			/// V�po�et sou�adnic kloubu nebo bodu na ruce z lok�ln�ch do glob�ln�ch. 
			/// </summary>
			/// <param name="flag">Identifikace na kter� ruce se m�sto nach�z�. 0 - lev�, 1 - prav�.</param>
			/// <param name="indexOfJoint">Index kloubu, kter� je po��tan� nebo index nejbli���ho kloubu k po��tan�mu
			/// m�stu sm�rem nahoru ve struktu�e.</param>
			/// <param name="action">0 - m�sto pro p�eveden� je kloub, 1 - m�sto pro p�eveden� je n�jak� m�sto na ruce.</param>
			/// <param name="relativeContactDistance">V p��pad� �e m�sto nen� kloub ud�v� vzd�lenost od nejbli���ho kloubu sm�rem 
			/// nahoru ve struktu�e.</param>
			/// <param name="globalJoint">Glob�ln� sou�adn�ce po��tan�ho m�sta.</param>
			static public void getGlobalJointFromLocal(int flag,int indexOfJoint,int action, Joint.Vector relativeContactDistance,ref Joint.Vector globalJoint)
			{
				int joint;
				Joint.Vector T = new Joint.Vector();
				Quaternion tmpQuat = new Quaternion();
				Joint.Vector tmpVect = new Joint.Vector();
				int finger =0;
				int number=0;
				Joint[] hand;

				if(((action!=0)&&(action!=1))||(indexOfJoint < -1) || (indexOfJoint >= numberJointHand ) || ((flag != 0) && (flag != 1)) || (globalJoint == null))
					throw new GenException.ParameterException("action: " + action + ", " + "indexOfJoint: " + indexOfJoint + ", " + "flag: " + flag + "," + "globalJoint: " + (globalJoint == null ? "NULL":globalJoint.ToString()));

				getFingerAndNumberOfJointOnWay(indexOfJoint,ref finger,ref number);

				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;

				for(joint = number; joint >= 0; joint--)
				{												
					tmpVect.setNull();
					tmpQuat.angleToQuatertnion(hand[getIndexOfNthJoint(finger,joint)].vrmlRotation);
					tmpVect.addVectors(T);

					if((action == 1) && (joint == number))
						tmpVect.addVectors(relativeContactDistance);
					else
						tmpVect.addVectors(hand[getIndexOfNthJoint(finger,joint+1)].relativeDistance);						
					
					multipleRotmatrixVector(tmpQuat,tmpVect,ref T);
				}			
				T.addVectors(hand[0].relativeDistance);
				globalJoint.copyVector(T);
			}
			/// <summary>
			/// V�po�et klob�ln�ch sou�adnic kloub� ramene, lokte a z�p�st�.
			/// </summary>
			/// <param name="flag">Identifikace kter� ruce klouby pat��. 0 - lev�, 1 - prav�.</param>
			/// <param name="P0">Glob�ln� sou�adnice ramene.</param>
			/// <param name="P1">Glob�ln� sou�adnice lokte.</param>
			/// <param name="P2">Glob�ln� sou�adnice z�p�st�.</param>
			static public void getGlobalJoints(int flag,ref Joint.Vector P0,ref Joint.Vector P1,ref Joint.Vector P2)
			{
				if((P0 == null) || (P1 == null) || (P2 == null))
					throw new GenException.ParameterException("P0: " + (P0 == null ? "NULL":P0.ToString()) + ", " + "P1: " + (P1 == null ? "NULL":P1.ToString()) + ", " +"P2: " + (P2 == null ? "NULL":P2.ToString()));

				if(flag == 0)
				{
					getGlobalJointFromLocal(0,-1,0,new Joint.Vector(),ref P0);
					getGlobalJointFromLocal(0,0,0,new Joint.Vector(),ref P1);
					getGlobalJointFromLocal(0,1,0,new Joint.Vector(),ref P2);
				}
				else
				{
					getGlobalJointFromLocal(1,-1,0,new Joint.Vector(),ref P0);
					getGlobalJointFromLocal(1,0,0,new Joint.Vector(),ref P1);
					getGlobalJointFromLocal(1,1,0,new Joint.Vector(),ref P2);
				}
			}
			/// <summary>
			/// Vzd�lenost dvou bod� v prostoru.
			/// </summary>
			/// <param name="firstPoint">Prvn� bod.</param>
			/// <param name="secondPoint">Druh� bod.</param>
			/// <returns>Vzd�lenost bod�.</returns>
			static public double getDistancePoints(Joint.Vector firstPoint, Joint.Vector secondPoint)
			{
				if((firstPoint == null) || (secondPoint == null))
					throw new GenException.ParameterException("firstPoint: " + (firstPoint == null ? "NULL":firstPoint.ToString()) + ", " + "secondPoint: " + (secondPoint == null ? "NULL":secondPoint.ToString()) );
				
				return Math.Sqrt(Math.Pow((firstPoint.x - secondPoint.x),2) +
					Math.Pow((firstPoint.y - secondPoint.y),2) +
					Math.Pow((firstPoint.z - secondPoint.z),2));
			}
			/// <summary>
			/// V�po�et lok�ln� rotace pro kloub z rotace zadan� v glob�ln�ch sou�adnic�ch.
			/// </summary>
			/// <param name="flag">Identifikace kter� ruce rotace pat��. 0- lev�, 1- prav�.</param>
			/// <param name="joint">Kloub ve kter�m je rotace prov�d�na.</param>
			/// <param name="globalRot">Glob�ln� rotace.</param>
			/// <param name="localRot">Lok�ln� rotace.</param>
			static public void getLocalRotationFromGlobal(int flag,int joint,Joint.Rotation globalRot,ref Joint.Rotation localRot )
			{	
				if(((flag != 0)&&(flag != 1)) || (localRot == null) || (joint< 0) || (joint >= numberJointHand) || (globalRot == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "globalRot: " + (globalRot == null ? "NULL":globalRot.ToString()) +  ", " + "localRot: " + (localRot == null ? "NULL":localRot.ToString()));
				
				Joint.Rotation parentRot = new Joint.Rotation();
				Quaternion quatParentRot = new Quaternion();
				Quaternion quatGlobalRot = new Quaternion();
				Quaternion quatMiddle = new Quaternion();
				Quaternion quatInverseParentRot = new Quaternion();
				Quaternion quatFinal = new Quaternion();

				if(flag == 0)
					leftHand[joint].joinParentsRotations(ref parentRot);
				else
					rightHand[joint].joinParentsRotations(ref parentRot);
				
				quatParentRot.angleToQuatertnion(parentRot);
				quatGlobalRot.angleToQuatertnion(globalRot);
				quatMiddle.multipleQuaternions(quatGlobalRot,quatParentRot);
				quatParentRot.inverseQuaternion(ref quatInverseParentRot); 
				quatFinal.multipleQuaternions(quatInverseParentRot,quatMiddle);
				quatFinal.quaternionToAngle(ref localRot);

			}
			/// <summary>
			/// V�po�et rotace v z�p�st�, kter� zm�n� aktu�ln� vektor v soustav� z�p�st� na po�adovan�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� rotace po��tat.0 - lev�, 1 -prav�.</param>
			/// <param name="beginDirect">V�choz� sm�r vektoru.</param>
			/// <param name="endDirect">Kone�n� sm�r vektoru.</param>
			/// <param name="tmpRot">Lok�ln� rotace.</param>
			static public void keepOri(int flag,Joint.Vector beginDirect, Joint.Vector endDirect, ref Joint.Rotation tmpRot)
			{
				if(((flag != 1) && (flag != 0)) ||(beginDirect == null) || (endDirect == null) || (tmpRot == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "beginDirect: " + (beginDirect == null ? "NULL":beginDirect.ToString())+ ", " + "endDirect: " + (endDirect == null ? "NULL":endDirect.ToString())+ ", " + "tmpRot: " + (tmpRot == null ? "NULL":tmpRot.ToString()));

				Joint.Rotation rotationGlob = new Joint.Rotation();
				Joint.Rotation rotationLoc = new Joint.Rotation();

				getRotationVectorVector(beginDirect,endDirect,ref rotationGlob);
				getLocalRotationFromGlobal(flag,2,rotationGlob,ref rotationLoc);
				if(flag == 0)
				{
					leftHand[2].composeRotation(rotationLoc,ref leftHand[2].vrmlRotation,1);					
					leftHand[2].composeRotation(rotationLoc,ref tmpRot,1);
				}
				else
				{
					rightHand[2].composeRotation(rotationLoc,ref rightHand[2].vrmlRotation,1);
					rightHand[2].composeRotation(rotationLoc,ref tmpRot,1);
				}
			
				
			}
			/// <summary>
			/// V�po�et glob�ln�ch sou�adnic vektoru ze sou�adnic lok�ln�ch k dan�mu kloubu.
			/// </summary>
			/// <param name="flag">Identifikace ke kter� ruce se vektor vztahuje.0 - lev�, 1 - prav�.</param>
			/// <param name="joint">Kloub ke kter�mu se vektor vztahuje.</param>
			/// <param name="localVect">Lok�ln� vektor.</param>
			/// <param name="globalVect">Glob�ln� vektor.</param>
			static public void getGlobalVectorFromLocal(int flag, int joint, Joint.Vector localVect, ref Joint.Vector globalVect ) 
			{
				Joint.Rotation actRotation = new Joint.Rotation();
				Quaternion quat = new Quaternion();

				if(((flag != 0) && (flag != 1)) || (joint < 0) || (joint >= numberJointHand) || (localVect == null) || (globalVect == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "joint: " + joint + ", " + ", " + "localVect: " + (localVect == null ? "NULL":localVect.ToString())+ ", " + "globalVect: " + (globalVect == null ? "NULL":globalVect.ToString()));

				if(flag == 0)
				{ // slozeni vsech rotaci predchudcu vcetne rotace na kloub samotny
					leftHand[joint].joinParentsRotations(ref actRotation); 
				}
				else
				{// slozeni vsech rotaci predchudcu vcetne rotace na kloub samotny
					rightHand[joint].joinParentsRotations(ref actRotation);  
				}

				quat.angleToQuatertnion(actRotation);             
				// vector preveden na globalni       
				multipleRotmatrixVector(quat,localVect,ref globalVect); 
				
			}
			/// <summary>
			/// V�po�et bodu, zadan�ho po��te�n�m bodem, vektorem a d�lkou vektoru.
			/// </summary>
			/// <param name="point">Po��te�n� bod.</param>
			/// <param name="direction">Vektor.</param>
			/// <param name="distance">Vzd�lenost po��te�n�ho bodu a bodu po��tan�ho.</param>
			/// <param name="finalPoint">Nov� bod.</param>
			static public void getNewPointFromPointAndVector(Joint.Vector point, Joint.Vector direction,double distance, ref Joint.Vector finalPoint)
			{
				if((point == null) || (direction == null) || (finalPoint == null))
					throw new GenException.ParameterException("point: " + (point == null ? "NULL":point.ToString())+ ", " + "direction: " + (direction == null ? "NULL":direction.ToString())+ ", " + "finalPoint: " + (finalPoint == null ? "NULL":finalPoint.ToString()));
				
				direction.normalize();
				finalPoint.x = point.x + (direction.x * distance);
				finalPoint.y = point.y + (direction.y * distance);
				finalPoint.z = point.z + (direction.z * distance);

			}
			/// <summary>
			/// V�po�et vektor� ze dvou bod�.
			/// </summary>
			/// <param name="to">Kone�n� bod vektoru.</param>
			/// <param name="from">Po��te�n� bod vektoru.</param>
			/// <param name="vector">Vektor.</param>
			static public void getVectorFromPoints(Joint.Vector to, Joint.Vector from,ref Joint.Vector vector)
			{
				if((to == null) || (from == null) || (vector == null))
					throw new GenException.ParameterException("to: " + (to == null ? "NULL":to.ToString())+ ", " + "from: " + (from == null ? "NULL":from.ToString())+ ", " + "vector: " + (vector == null ? "NULL":vector.ToString()));
				
				vector.addVectors(to);
				vector.subVectors(from);
				vector.normalize();

			}
			/// <summary>
			/// V�po�et �hlu mezi dv�ma vektory.
			/// </summary>
			/// <param name="firsVect">Po��te�n� vektor.</param>
			/// <param name="secondVect">kone�n� vektor.</param>
			/// <returns>�hel mezi vektory.</returns>
			static public double getAngleVectorVector(Joint.Vector firsVect, Joint.Vector secondVect)
			{
				if((firsVect == null) || (secondVect == null))
					throw new GenException.ParameterException("firstVect: " + (firsVect == null ? "NULL":firsVect.ToString())+ ", " + "secondVect: " + (secondVect == null ? "NULL":secondVect.ToString()));

				// spo�ten� velikosti �hlu mezi vektory
				double cosAlfa = (firsVect.x * secondVect.x + firsVect.y * secondVect.y + firsVect.z * secondVect.z) /
					(Math.Sqrt((firsVect.x*firsVect.x + firsVect.y*firsVect.y + firsVect.z*firsVect.z)*
					(secondVect.x * secondVect.x + secondVect.y * secondVect.y + secondVect.z * secondVect.z)));         

				// �hel mezi vektory
				return Math.Acos(moveGenerator.checkAngleRange(cosAlfa));

			}
			/// <summary>
			/// V�po�et �hlu mezi vektory zadan�mi t�emi body.
			/// </summary>
			/// <param name="firstPoint">Kone�n� bod prvn�ho vektoru.</param>
			/// <param name="middlePoint">Po��te�n� bod obou vektor�.</param>
			/// <param name="secondPoint">Kone�n� bod druh�ho vektoru.</param>
			/// <returns>�hel mezi vektory.</returns></returns>
			static public double getAngleFromPoints(Joint.Vector firstPoint,Joint.Vector middlePoint, Joint.Vector secondPoint)
			{
				if((firstPoint == null)|| (secondPoint == null) ||(middlePoint == null))
					throw new GenException.ParameterException("firstPoint: " + (firstPoint == null ? "NULL":firstPoint.ToString())+ ", " + "middlePoint: " + (middlePoint == null ? "NULL":middlePoint.ToString())+ ", " + "secondPoint: " + (secondPoint == null ? "NULL":secondPoint.ToString()));

				Joint.Vector firstVect = new Joint.Vector();
				Joint.Vector secondVect = new Joint.Vector();

				getVectorFromPoints(firstPoint,middlePoint,ref firstVect);
				getVectorFromPoints(secondPoint,middlePoint,ref secondVect);

				return getAngleVectorVector(firstVect,secondVect);

			}
			/// <summary>
			/// Na�ten� seznamu vektor� ze souboru. K �emu se vektory vztahuj� je ur�eno parametrem action.
			/// </summary>
			/// <param name="action">0 - polygon, 1 - vektory sm�ru ot��en� z�p�st� ORI1, 2 - vektory sm�ru ot��en� z�p�st� ORI2,
			/// 3 - alfa ORI1, 4 - alfa ORI2</param>
			/// <param name="type">Pro na��t�n� polygonu.Ur�uje kolik hran polygonu se m� na��st.</param>
			/// <param name="list">Seznam vektor�.</param>
			static public void getPolygonOrListOfVectorFromFile(int action,string type,ref System.Collections.ArrayList list)
			{	
				if((list == null) || (type == null) || ((action < 0) || (action > 4)))
					throw new GenException.ParameterException("action: " + action + ", " + "type: " + (type == null ? "NULL":type) + ", " + "list: " + (list == null ? "NULL":"NOT NULL"));
				
				string inputLineTab;           
				string inputData = "";
				string[] splittedLine; 
				string[] splittedVector; 
				Joint.Vector toList;
				int n;
				int result= -1;
				int findId = -1;
				int end = 0;
				string id = "";

				//do souboru pocet vrcholu
				switch(type)
				{
					case "f": end = 16; break;
					case "h": end = 8; break;
					case "q": end = 4; break;
					case "v": end = 7; break;
					case "a": end = 6; break;

					default: throw new GenException.ParameterException("Parametr type neodpov�d� f/h/q/v, type: " + type);
				}

				FileStream fs = null;
				StreamReader sr = null;

				try 
				{

					fs = new FileStream(moveInformationFileName, FileMode.Open, FileAccess.Read);
					sr = new StreamReader(fs);

					if(action == 0)
						id = "polygon";
					else if(action == 1)
						id= "roundVectorsOri1";
					else if(action == 2)
						id = "roundVectorsOri2";
					else if(action == 3)
						id = "alfaVectorsOri1";
					else if(action == 4)
						id = "alfaVectorsOri2";

					while ((inputLineTab = sr.ReadLine()) != null)
					{					
						result = findIdInInput(moveInformationFileName, id, inputLineTab, ref inputData);
						if (result == 0)
						{
							findId = 0;
							splittedLine = inputData.Split(';');
							for(n=0;n < end;n++)
							{
								splittedVector = splittedLine[n].Split(' ');
								if(splittedVector.Length != 3)
									throw new GenException.UsingFileException("Po�et os vektoru v souboru neodpov�d� 3.", moveInformationFileName);
								toList = new Joint.Vector(Double.Parse(splittedVector[0]),Double.Parse(splittedVector[1]),Double.Parse(splittedVector[2]));
								list.Add(toList);
							}
							break;
						}
					}
					if (findId == -1)
						throw new GenException.UsingFileException("Id 'polygon' nebo 'roundVectors' nebylo v souboru nalezeno.", moveInformationFileName);          
				}
				finally
				{
					if(sr != null)
						sr.Close();
					if(fs != null)
						fs.Close();
				}
			}
			/// <summary>
			/// Pohyb m�v�n�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st.</param>
			static public void makeWaveMove(int flag)
			{
				if((flag != 0) && (flag != 1))
					throw new GenException.ParameterException("flag: " + flag);

				makeDEZmove(flag,"B0");
				makeDEZmove(flag,"B0ii");
				makeDEZmove(flag,"B0");
			}

			//spocita polomer polygonu pri zadanem poctu hran a delce hrany
			/// <summary>
			/// V�po�et polom�ru kruhu z po�tu vrchol� vepsan�ho polygonu a d�lky jedn� hrany.
			/// </summary>
			/// <param name="numberOfEdge">Po�et vrchol� polygonu.</param>
			/// <param name="lengthOfEdgeInPolygon">D�lka hrany polygonu.</param>
			/// <returns>Polom�r kruhu.</returns>
			static public double getRadiusOfCircle(int numberOfEdge,double lengthOfEdgeInPolygon)
			{
				return (lengthOfEdgeInPolygon/(Math.Sin(Math.PI/numberOfEdge)));
			}
			/// <summary>
			/// V�po�et rotace polygonu pro kruhov� pohyb v posunu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="lengthOfMove">D�lka pohybu.</param>
			/// <param name="circleDirectionList">Seznam vektor� pro kruhov� pohyb.</param>
			/// <param name="rotPolygon">Rotace pro polygony.</param>
			static public void findNewVectorToCircleMove(int flag,double lengthOfMove,System.Collections.ArrayList circleDirectionList,ref Joint.Rotation rotPolygon)
			{
				
				if((flag != 0) && (flag != 1) || (circleDirectionList == null) || (rotPolygon == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "circleDirectionList: " + (circleDirectionList == null ? "NULL":"NOT NULL")+ ", " + "rotPolygon: " + (rotPolygon == null ? "NULL":rotPolygon.ToString()));

				Joint.Vector globWrist = new Joint.Vector();
				Joint.Vector globSecondWrist = new Joint.Vector();
				Joint.Vector directGlobSecondWristToGlobWrist = new Joint.Vector();
				Joint.Vector centreOfCircle = new Joint.Vector();
				Joint.Vector directLeftToRigthWristInZ = new Joint.Vector();
				Joint.Vector directCenterToWrist = new Joint.Vector();
				double distWrist = 0;
				double zDistance = 0;
				double radius = 0;
				double tmpDist = 0;

				// aktualni globalni souradnice zapesti
				getGlobalJointFromLocal(flag,1,0,new Joint.Vector(),ref globWrist);
				getGlobalJointFromLocal(((flag+1)%2),1,0,new Joint.Vector(),ref globSecondWrist);

				// nalezeni stredu kruhu
				distWrist = getDistancePoints(globWrist,globSecondWrist);
				getVectorFromPoints(globWrist,globSecondWrist,ref directGlobSecondWristToGlobWrist);
				directGlobSecondWristToGlobWrist.normalize();
				getNewPointFromPointAndVector(globSecondWrist,directGlobSecondWristToGlobWrist,distWrist/2,ref centreOfCircle);

				//spocte polomer polygonu
				radius = getRadiusOfCircle(circleDirectionList.Count,lengthOfEdgeInPolygon*lengthOfMove);
				if(radius == 0)
					throw new GenException.ComputingException("Polom�r kruhov�ho pohybu je 0 !");

				// zjisteni vzdalenosti zapesti v souradnici Z
				zDistance = Math.Abs(globWrist.z - globSecondWrist.z);

				// zjisteni smeru od leve ruky k prave
				directLeftToRigthWristInZ.setNull();

				//zjisteni smeru od leve ruky k prave v zetove ose
				if(flag == 0)
				{
					directLeftToRigthWristInZ.z = globSecondWrist.z - globWrist.z; 											
				}
				else
				{
					directLeftToRigthWristInZ.z = globWrist.z - globSecondWrist.z ; 					
				}

				//ruce jsou uplne u sebe, posuneme pravou dopredu a levou dozadu
				if(directLeftToRigthWristInZ.z == 0)
					directLeftToRigthWristInZ.z = 1;
				else
					directLeftToRigthWristInZ.normalize();

				// posunout ruce od sebe, tedy pravou ve smeru vektoru directLeftToRightWristInz a levou v -1 smeru
				// ruce jsou v mensi vzdalenosti nez je potrebna vzdalenost, tedy ruce museji jit od sebe
				if((zDistance/2) < radius)
				{
					tmpDist = radius - (zDistance/2);
					// u obou if dat misto zde primo do straight move pro vsechny prime pohyby
					if(tmpDist > 0.01)
					{
						//leva ruka jde opacnym smerem nez je smer k prave ruce
						if(flag == 0) 
						{
							directLeftToRigthWristInZ.minusVector();
							makeStraightMove(flag,directLeftToRigthWristInZ,tmpDist,1);
						}
							// prava ruka jde ve stejnem smeru jako je smer leve ruky k prave
						else
							makeStraightMove(flag,directLeftToRigthWristInZ,tmpDist,1);
					}
				}
					// posouvat presne obracene, pravou v -1 smeru a levou ve smeru vektoru
					//ruce jsou ve vetsi vzdalenosti nez je potreba, tedy ruce museji jit k sobe
				else if ((zDistance/2) > radius)
				{
					tmpDist = (zDistance/2) - radius;
					if(tmpDist > 0.01)
					{
						//leva ruka jde smerem k prave
						if(flag == 0)
							makeStraightMove(flag,directLeftToRigthWristInZ,tmpDist,1);
							//prava ruka jde smerem k leve
						else
						{
							directLeftToRigthWristInZ.minusVector();
							makeStraightMove(flag,directLeftToRigthWristInZ,tmpDist,1);
						}
						
					}
				}
								
				getGlobalJointFromLocal(flag,1,0,new Joint.Vector(),ref globWrist);
				directCenterToWrist.setNull();
				directCenterToWrist.z = globWrist.z - centreOfCircle.z;

				getRotationVectorVector(new Joint.Vector(0,1,0),directCenterToWrist,ref rotPolygon);

			}
			/// <summary>
			/// V�po�et kruhov�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�st. 0 - lev�, 1 - prav�.</param>
			/// <param name="id">cislo(1-12):cast(f,q,h)</param>
			/// <param name="distLine">D�lka hrany polygonu.</param>
			/// <param name="action">0 - dodr�ovat sm�r ORI, 1 - nedodr�ovat sm�r ORI.</param>				
			static public void makeCircleMove(int flag, string id, double distLine,int action)
			{	
				if((flag != 0) && (flag != 1) || (id == null) || ((action != 0) && (action != 1)))
					throw new GenException.ParameterException("flag: " + flag + ", " + "id: " + (id == null ? "NULL":id) + ", " + "action: " + action);

				System.Collections.ArrayList circleDirectionList = new System.Collections.ArrayList(maxPolygonVertex);
				Joint.Rotation rotPolygon = new Joint.Rotation();

				// typ pohybu oddelit od cisla pohybu
				string[] typeOfCircleMove = id.Split(':');
				int type = Int32.Parse(typeOfCircleMove[0]);
				double tmp;
				int reverse1 = 1; // neotacet vektor
				int reverse2 = 1; // neotacet vektor

				getPolygonOrListOfVectorFromFile(0,typeOfCircleMove[1],ref circleDirectionList);
				
				if((type == 2)||(type == 6) || (type == 9) ||(type == 11) ||((flag == 0) && ((type == 3)||(type == 7))) || ((flag == 1) && ((type == 4)||(type == 8))) )
				{
					// cely kruh
					if(typeOfCircleMove[1].ToCharArray(0,1)[0] == 'f')
					{
						circleDirectionList.Reverse();
						reverse1 = -1;
						reverse2 = -1;
					}
					//ctvrt kruh
					if(typeOfCircleMove[1].ToCharArray(0,1)[0] == 'q')
						reverse1 = -1;
					//pukruh
					if(typeOfCircleMove[1].ToCharArray(0,1)[0] == 'h')
						circleDirectionList.Reverse();

				}

				// pohyby v posunu obe ruce ve stejnem smeru
				if((type == 11) || (type == 12))
					findNewVectorToCircleMove(flag,distLine,circleDirectionList,ref rotPolygon);	

				foreach(Joint.Vector v in circleDirectionList)
				{
					// otoceni vektoru nebo ponechani ve stejnem smeru
					v.x = v.x*reverse1;
					v.y = v.y*reverse2;
					v.z = v.z*reverse1;
					
					//nastaveni roviny ve ktere se bude provadet kruh
					if((type>= 1) && (type<= 4))
					{
						tmp = v.y;
						v.y = v.z;
						v.z = tmp;
					}
					if((type>=9) && (type<=12))
					{
						tmp = v.x;
						v.x = v.z;
						v.z = tmp;

						if((type==11) || (type == 12))
						{
							Quaternion tmpQuat = new Quaternion();
							Joint.Vector tmpVect = new Joint.Vector();

							tmpQuat.angleToQuatertnion(rotPolygon);
							multipleRotmatrixVector(tmpQuat,v,ref tmpVect);
							v.copyVector(tmpVect);
						}
					}
					if((type< 1) || (type > 12))
						throw new GenException.ParameterException("Parametr type je mimo rozsah 1-12, type: " + type );

					makeStraightMoveAskOri(flag,v,distLine,1,action);
				}
				
			}
			/// <summary>
			/// Na�ten� kontaktn�ho m�sta ze souboru. 
			/// </summary>
			/// <param name="id">Id kontaktn�ho m�sta.</param>
			/// <param name="fileName">Soubor z kter�ho se m�j� data k id na��st.</param>
			/// <param name="contactPoint">Kontakn� m�sto</param>
			/// <param name="idOfContJoint">��slo ze souboru dopl�uj�c� informace ke kontaktn�mu m�stu.</param>			
			static public void getContactPointFromFile(string id,string fileName,ref Joint.Vector contactPoint ,ref int idOfContJoint)			
			{
				if((id == null) || (fileName == null) || (contactPoint == null))
					throw new GenException.ParameterException("id: " + (id == null ? "NULL":id)+ ", " + "fileName: " + (fileName == null ? "NULL":fileName)+ ", " + "contactPoint: " + (contactPoint == null ? "NULL":contactPoint.ToString()));

				int findId = -1;
				string inputDirection;
				string outputDirection;
				string [] splittedVect;
				string [] splittedInput;
				int result;

				FileStream fs = null;
				StreamReader sr = null;

				try 
				{
				
					fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
					sr = new StreamReader(fs);
				
					outputDirection = "";
 
					while ((inputDirection = sr.ReadLine()) != null)
					{
						result = findIdInInput(fileName,id,inputDirection,ref outputDirection);
						//pokud id neni na ruce, bude na tele
						if(result != 0)
							result = findIdInInput(fileName,id.Split(',')[0]+",-1",inputDirection,ref outputDirection);

						if (result == 0)
						{
							//p��znak nalezen� id v souboru
							findId = 0;
							splittedInput = outputDirection.Split(';');
							if(splittedInput.Length != 2)
								throw new GenException.UsingFileException("�patn� form�t souboru,o�ek�v�no id ruky, id kloubu a sou�adnice m�sta kontaktu.", fileName);
				
							idOfContJoint= Int32.Parse(splittedInput[0]);

							if((idOfContJoint< -1) || (idOfContJoint >= numberJointHand))
								throw new GenException.UsingFileException("�patn� ��slo kloubu v souboru.", fileName);

							splittedVect= splittedInput[1].Split(' ');
							if(splittedVect.Length != 3)
								throw new GenException.UsingFileException("�patn� form�t vektoru v souboru, o�ek�vana osaX osaY osaZ.", fileName);
						
							contactPoint.x = Double.Parse(splittedVect[0]);
							contactPoint.y = Double.Parse(splittedVect[1]);
							contactPoint.z = Double.Parse(splittedVect[2]);
							break;
						}
					}
					//id v souboru nebylo nalezeno
					if (findId == -1)
						throw new GenException.UsingFileException("Id sm�ru nebylo v souboru nalezeno.", fileName);          
				}
				finally
				{
					if(sr != null)
						sr.Close();
					if(fs != null)
						fs.Close();
				}
			}
			/// <summary>
			/// Nalezen� hranic ze souboru pro pohybu k�v�n�.
			/// </summary>
			/// <param name="frontL">P�edn� hranice.</param>
			/// <param name="backL">Zadn� hranice.</param>
			static public void getBoundsFromFile(ref Joint.Vector frontL,ref Joint.Vector backL)
			{
				if((frontL == null) || (backL == null))
					throw new GenException.ParameterException("frontL: " + (frontL == null ? "NULL":frontL.ToString())+ ", " + "backL: " + (backL == null ? "NULL":backL.ToString()));

				int findId = -1;
				string inputDirection;
				string outputDirection;
				string [] splittedVect;
				string [] splittedInput;
				int result;
				FileStream fs =	 null;
				StreamReader sr = null;

				try
				{

					fs = new FileStream(moveInformationFileName, FileMode.Open, FileAccess.Read);
					sr = new StreamReader(fs);
					outputDirection = "";
 
					while ((inputDirection = sr.ReadLine()) != null)
					{
						result = findIdInInput(moveInformationFileName, "waveHorizont",inputDirection,ref outputDirection);
						if (result == 0)
						{
							//p��znak nalezen� id v souboru
							findId = 0;
							splittedInput = outputDirection.Split(';');
							if(splittedInput.Length != 2)
								throw new GenException.UsingFileException(".�patn� form�t souboru, o�ek�v�ny dva vektory ur�uj�c� meze pohybu horizont�ln�ho m�v�n�.",moveInformationFileName);

							for(int i=0;i<2;i++)
							{
								splittedVect = splittedInput[i].Split(' ');
								if (splittedVect.Length != 3)
									throw new GenException.UsingFileException("�patn� form�t vektoru v souboru, o�ek�vana osaX osaY osaZ.",moveInformationFileName);
								if(i==0)
								{
									frontL.x = Double.Parse(splittedVect[0]);
									frontL.y = Double.Parse(splittedVect[1]); 
									frontL.z = Double.Parse(splittedVect[2]);
								}
								else
								{
									backL.x = Double.Parse(splittedVect[0]);
									backL.y = Double.Parse(splittedVect[1]); 
									backL.z = Double.Parse(splittedVect[2]);
								}

							}					
						}
					}
					//id v souboru nebylo nalezeno
					if (findId == -1)
						throw new GenException.UsingFileException("Id sm�ru nebylo v souboru nalezeno.",moveInformationFileName);          
				}
			
				finally
				{
					if(sr != null)
						sr.Close();
					if(fs != null)
						fs.Close();	
				}

			}
			
			/// <summary>
			/// V�po�et pohybu k�v�n�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="ident">1 - horizont�ln�, 2 - vertik�ln�.</param>
			static public void makeSwingMove(int flag, int ident)
			{
				if((flag != 0) && (flag != 1) || ((ident != 1) && (ident != 2)))
					throw new GenException.ParameterException("flag: " + flag + ", " + "ident: " + ident);
	
				Joint[] hand;
				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;

				if(ident == 2)
				{
					Joint.Vector actualHandNormal = new Joint.Vector();
					Joint.Rotation tmpRot = new Joint.Rotation(0,0,0,waveAngle);
				
					tmpRot.setAxis(hand[2].normal);
					hand[2].moveLocalRotations.Add(new Joint.Rotation(tmpRot.x,tmpRot.y,tmpRot.z,tmpRot.angle));
					hand[2].composeRotation(tmpRot,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();
					tmpRot.angle = waveAngle*(-1); // opacny smer
					hand[2].moveLocalRotations.Add(new Joint.Rotation(tmpRot.x,tmpRot.y,tmpRot.z,tmpRot.angle));
					hand[2].composeRotation(tmpRot,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();
					tmpRot.angle = waveAngle*(-1); // opacny smer
					hand[2].moveLocalRotations.Add(new Joint.Rotation(tmpRot.x,tmpRot.y,tmpRot.z,tmpRot.angle));
					hand[2].composeRotation(tmpRot,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();
					tmpRot.angle = waveAngle;
					hand[2].moveLocalRotations.Add(new Joint.Rotation(tmpRot.x,tmpRot.y,tmpRot.z,tmpRot.angle));
					hand[2].composeRotation(tmpRot,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();

				}
				if(ident == 1)
				{
					Joint.Vector frontL = new Joint.Vector(); // nactene ze souboru
					Joint.Vector backL = new Joint.Vector(); // nactene ze souboru
					Joint.Vector front = new Joint.Vector(); // nactene ze souboru
					Joint.Vector back = new Joint.Vector(); // nactene ze souboru
					Joint.Vector actual = new Joint.Vector(); 
					Joint.Rotation joinRotLoc = new Joint.Rotation();
					double angleBounds,angleToBack, angleToFront;

					getBoundsFromFile(ref frontL, ref backL);
					//prevedeni vektoru na aktualni smer (zavisly na rotacich v kloubech)
					getGlobalVectorFromLocal(flag,2,frontL,ref front);
					getGlobalVectorFromLocal(flag,2,backL,ref back);
					getGlobalVectorFromLocal(flag,2,hand[2].normal,ref actual);					

					angleBounds = getAngleVectorVector(front,back);
					angleToFront = getAngleVectorVector(front,actual);
					angleToBack = getAngleVectorVector(back,actual);
					//rotace urcuje osu pro rotaci, pro rotace front->back osa zustava
					getRotationVectorVector(frontL,backL,ref joinRotLoc); // osa zustava po celou dobu stejne, meni se orientace uhlu

					// prvni rotace je k front, dalsi od front k back a pak od back k actualni pozici
					// actual->front
					joinRotLoc.angle = -angleToFront;
					hand[2].moveLocalRotations.Add(new Joint.Rotation(joinRotLoc.x,joinRotLoc.y,joinRotLoc.z,joinRotLoc.angle));
					hand[2].composeRotation(joinRotLoc,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();
					
					//front->back
					joinRotLoc.angle = angleBounds/2;
					hand[2].moveLocalRotations.Add(new Joint.Rotation(joinRotLoc.x,joinRotLoc.y,joinRotLoc.z,joinRotLoc.angle));
					hand[2].composeRotation(joinRotLoc,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();

					joinRotLoc.angle = angleBounds/2;
					hand[2].moveLocalRotations.Add(new Joint.Rotation(joinRotLoc.x,joinRotLoc.y,joinRotLoc.z,joinRotLoc.angle));
					hand[2].composeRotation(joinRotLoc,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();

					//back->actual
					joinRotLoc.angle = -angleToBack;
					hand[2].moveLocalRotations.Add(new Joint.Rotation(joinRotLoc.x,joinRotLoc.y,joinRotLoc.z,joinRotLoc.angle));
					hand[2].composeRotation(joinRotLoc,ref hand[2].vrmlRotation,1);
					hand[2].addVrmlRotationToList();

				}
			}
			/// <summary>
			/// V�po�et p��m�ho pohybu, tak aby byl proveden kontakt.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="whereCoord">Kontakt kde.</param>
			/// <param name="whatCoord">Kontakt ��m.</param>
			/// <param name="moveDirection">Sm�r p��m�ho pohybu.</param>
			/// <param name="moveLength">D�lka pohybu.</param>			
			static public void findStraightMoveFromContact(int flag,Joint.Vector whereCoord,Joint.Vector whatCoord, ref Joint.Vector moveDirection, ref double moveLength)
			{
				if(((flag!=1)&&(flag!=0))||(whereCoord == null)||(whatCoord == null))
					throw new GenException.ParameterException("flag: " + flag+ ", " + "whereCoord: " + (whereCoord == null ? "NULL":whereCoord.ToString())+ ", " + "whatCoord: " + (whatCoord == null ? "NULL":whatCoord.ToString()));								

				Joint.Vector globalWrist = new Joint.Vector();
				Joint.Vector newPositionWrist = new Joint.Vector();
				Joint.Vector directWristWhat = new Joint.Vector();
				//nalezeni souradnic zapesti v prostoru
				getGlobalJointFromLocal(flag,1,0,new Joint.Vector(),ref globalWrist);
				//vektor od zapesti k bodu, ktery se ma dotykat
				getVectorFromPoints(globalWrist,whatCoord,ref directWristWhat);
				//nalezeni souradnic kam se ma presunout zapeti
				getNewPointFromPointAndVector(whereCoord,directWristWhat,getDistancePoints(globalWrist,whatCoord),ref newPositionWrist);
				//smer pohybu
				getVectorFromPoints(newPositionWrist,globalWrist,ref moveDirection);
				//delka pohybu
				moveLength = getDistancePoints(newPositionWrist,globalWrist);

			}

			/// <summary>
			/// V�po�et pohybu kroucen� z�p�st�m.
			/// </summary>
			/// <param name="flag">Identifikace ruky pro kterou se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="action">0 - doprava, 1 - doleva, 2 - doprava p�l, 3 - doleva p�l, 4 - se strany na stranu,
			/// 5 - alfa.</param>
			static public void makeRoundMove(int flag, int action)
			{
				if(((flag != 1) && (flag != 0)) || ((action < 0) || (action > 5)))
					throw new GenException.ParameterException("flag: " + flag + ", " + "action: " + action);

				System.Collections.ArrayList listOfVectOri1 = new System.Collections.ArrayList();
				System.Collections.ArrayList listOfVectOri2 = new System.Collections.ArrayList();
				Joint[] hand;
				Joint.Vector fingerDirect = new Joint.Vector();
				Joint.Vector fromGlobVectOri1 = new Joint.Vector();
				Joint.Vector fromGlobVectOri2 = new Joint.Vector();
				Joint.Vector toGlobaVectOri1 = new Joint.Vector();
				Joint.Vector toGlobaVectOri2 = new Joint.Vector();
				Joint.Rotation deltaLocRotOri1;
				Joint.Rotation deltaLocRotOri2;

				if(action == 5)
				{
					getPolygonOrListOfVectorFromFile(3,"a",ref listOfVectOri1);				
					getPolygonOrListOfVectorFromFile(4,"a",ref listOfVectOri2);
				}
				else
				{
					getPolygonOrListOfVectorFromFile(1,"v",ref listOfVectOri1);				
					getPolygonOrListOfVectorFromFile(2,"v",ref listOfVectOri2);
				}

				if((listOfVectOri1.Count != 0 ) && (listOfVectOri2.Count != 0))
				{
					if(flag == 0)
					{
						hand = leftHand;
						fingerDirect = dirFingerLeft;
						if(action == 4)
						{
							listOfVectOri1.Reverse(0,listOfVectOri1.Count);
							listOfVectOri2.Reverse(0,listOfVectOri2.Count);
						}
					}
					else
					{
						hand = rightHand;
						fingerDirect = dirFingerRight;
					}

					if((action == 1) || (action == 3))
					{
						listOfVectOri1.Reverse(0,listOfVectOri1.Count);
						listOfVectOri2.Reverse(0,listOfVectOri2.Count);
					}

					if((action == 2) || (action == 4) || (action == 3))
					{  
						listOfVectOri1.RemoveRange(4,3);
						listOfVectOri2.RemoveRange(4,3);

						if(action == 4)
						{
							System.Collections.ArrayList tmpList = new System.Collections.ArrayList();
							tmpList = (System.Collections.ArrayList)listOfVectOri1.Clone();
							tmpList.RemoveAt(tmpList.Count -1);
							tmpList.Reverse(0,tmpList.Count);
							listOfVectOri1.AddRange(tmpList);

							tmpList.Clear();
							tmpList = (System.Collections.ArrayList)listOfVectOri2.Clone();
							tmpList.RemoveAt(tmpList.Count -1);
							tmpList.Reverse(0,tmpList.Count);
							listOfVectOri2.AddRange(tmpList);
						}
					}

					if((action == 5) && (flag == 0))
					{
						foreach (Joint.Vector rot in listOfVectOri1)
						{
							rot.x *=  -1;
						}
						foreach (Joint.Vector rot in listOfVectOri2)
						{
							rot.x *= -1;
						}

					}

					if(listOfVectOri1.Count != listOfVectOri2.Count)
						throw new GenException.UsingFileException("Po�et vektor� v z�znamu roundVectorsOri1 a roundVectorsOri2 nen� shodn�.",moveInformationFileName);

					for(int z = 0;z < listOfVectOri1.Count;z++)
					{
						if (!checkNormalVectToVect((Joint.Vector)listOfVectOri1[z],(Joint.Vector)listOfVectOri2[z]))
							throw new GenException.ComputingException("Vektory nejsou kolm�.");
					}
					
					for(int i = 0; i < listOfVectOri1.Count;i++)
					{		
						getGlobalVectorFromLocal(flag,2,hand[2].normal,ref fromGlobVectOri1);
				
						getGlobalVectorFromLocal(flag,1,(Joint.Vector)listOfVectOri1[i],ref toGlobaVectOri1);
					
						deltaLocRotOri1 = new Joint.Rotation();
						keepOri(flag,fromGlobVectOri1,toGlobaVectOri1,ref deltaLocRotOri1);
						hand[2].moveLocalRotations.Add(deltaLocRotOri1);
					
						getGlobalVectorFromLocal(flag,2,fingerDirect,ref fromGlobVectOri2);
						getGlobalVectorFromLocal(flag,1,(Joint.Vector)listOfVectOri2[i],ref toGlobaVectOri2);
						deltaLocRotOri2 = new Joint.Rotation();
						keepOri(flag,fromGlobVectOri2,toGlobaVectOri2,ref deltaLocRotOri2);
						hand[2].moveLocalRotations.Add(deltaLocRotOri2);

						hand[2].addVrmlRotationToList();
					}
				}
				else
					throw new GenException.UsingFileException("Po�et vektor� v z�znamu roundVectorsOri1 nebo roundVectorsOri2 je nula.",moveInformationFileName);
			}

			/// <summary>
			/// V�po�et pohybu t�epot�n� nebo droben�. Dle parametru action.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="action">0 - t�epot�n�, 1 - droben�.</param>
			static public void makeFlapMove(int flag,int action)
			{
				Joint.Vector axisOfMove = new Joint.Vector();
				Joint.Rotation doRotation = new Joint.Rotation();
				int partOfRot;
				Joint[] hand;

				if(flag == 0)
					hand = leftHand;
				else if(flag == 1)
					hand = rightHand;
				else
					throw new GenException.ParameterException("Parametr flag je mimo rozsah 0/1, flag: " + flag + ".");

				getFlapRotFromFile(flag, ref axisOfMove);
				doRotation.setAxis(axisOfMove);

				if(action == 0)
				{
					makeDEZmove(flag,"petka"); // nastaveni do pocatecni pozice
					partOfRot = 12;
				}
				else if (action == 1)
				{
					makeDEZmove(flag,"Bstriska");
					partOfRot = -60;
				}
				else
					throw new GenException.ParameterException("Parametr action je mimo rozsah 0/1, action: " + action);

				double[][] arrayOfRotation =new double[4][];

				for(int index = 0; index < 4;index++)
					arrayOfRotation[index] = new double[27];

				for(int indexI= 0;indexI < 4; indexI++)
					for(int indexY = 0; indexY < 27; indexY++)
						arrayOfRotation[indexI][indexY] = 0;
	
				for(int prst = 0; prst < 4; prst++)
					for(int index = 0; index < 4; index++)
					{
						arrayOfRotation[prst][prst+index] = Math.PI/partOfRot;
						arrayOfRotation[prst][prst+index+4] = Math.PI/partOfRot*(-1);

						arrayOfRotation[prst][prst+index+8] = Math.PI/partOfRot;
						arrayOfRotation[prst][prst+index+12] = Math.PI/partOfRot*(-1);
						arrayOfRotation[prst][prst+index+16] = Math.PI/partOfRot;
						arrayOfRotation[prst][prst+index+20] = Math.PI/partOfRot*(-1);	
					}
				for(int prst= 0; prst<4; prst++)
					for(int index = 0; index < 27; index++)
					{
						doRotation.angle = arrayOfRotation[prst][index];
						hand[(prst+1)*3].moveLocalRotations.Add(new Joint.Rotation(doRotation.x,doRotation.y,doRotation.z,doRotation.angle));
						hand[(prst+1)*3].composeRotation(doRotation,ref hand[(prst+1)*3].vrmlRotation,1);								
						hand[(prst+1)*3].addVrmlRotationToList();
						hand[15].moveLocalRotations.Add(new Joint.Rotation(1,0,0,0));
						hand[15].addVrmlRotationToList();
						hand[16].moveLocalRotations.Add(new Joint.Rotation(1,0,0,0));
						hand[16].addVrmlRotationToList();
						hand[17].moveLocalRotations.Add(new Joint.Rotation(1,0,0,0));
						hand[17].addVrmlRotationToList();
												
						if(action == 0)
						{
							doRotation.angle = doRotation.angle/4;
							int idx = ((prst+1)*3 + 1);
							int idxx = ((prst+1)*3 + 2);
							hand[idx].moveLocalRotations.Add(new Joint.Rotation(doRotation.x,doRotation.y,doRotation.z,doRotation.angle));
							hand[idx].composeRotation(doRotation,ref hand[idx].vrmlRotation,1);
							hand[idx].addVrmlRotationToList();
							doRotation.angle = doRotation.angle/4;
							hand[idxx].moveLocalRotations.Add(new Joint.Rotation(doRotation.x, doRotation.y, doRotation.z, doRotation.angle));
							hand[idxx].composeRotation(doRotation,ref hand[idxx].vrmlRotation,1);
							hand[idxx].addVrmlRotationToList();
						}
						else
						{
							int idx = ((prst + 1) * 3 + 1);
							int idxx = ((prst + 1) * 3 + 2);
							hand[idx].moveLocalRotations.Add(new Joint.Rotation(doRotation.x,doRotation.y,doRotation.z,doRotation.angle));
							hand[idxx].composeRotation(doRotation,ref hand[idxx].vrmlRotation,1);
							hand[idx].addVrmlRotationToList();
							hand[idxx].moveLocalRotations.Add(new Joint.Rotation(doRotation.x,doRotation.y,doRotation.z,doRotation.angle));
							hand[idxx].composeRotation(doRotation,ref hand[idxx].vrmlRotation,1);
							hand[idxx].addVrmlRotationToList();
						}
					}
			}

			/// <summary>
			/// V�po�et pohybu kontakt.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="where">Kontakt kde.</param>
			/// <param name="what">Kontakt ��m.</param>
			static public void makeContactMove(int flag,string where, string what)
			{
				if(((flag!=1)&&(flag!=0))||(where == null)||(what == null))
					throw new GenException.ParameterException("flag: " + flag+ ", " + "where: " + (where == null ? "NULL":where)+ ", " + "what: " + (what == null ? "NULL":what));

				Joint.Vector whereCoordRelative = new Joint.Vector();
				Joint.Vector whatCoordRelative= new Joint.Vector();
				Joint.Vector whereCoordGlob = new Joint.Vector();
				Joint.Vector whatCoordGlob = new Joint.Vector();
				Joint.Vector directionOfMove = new Joint.Vector();
				int idOfContactJoint = 0;
				double lengthOfMove = 0.0;
				double partOfMove = 1.0;

				//nalezeni souradnic bodu kde, muze byt na tele nebo na ruce,
				getContactPointFromFile(where+ ',' + ((flag+1)%2),coordToContactFileName,ref whereCoordRelative,ref idOfContactJoint);

				// kontaktni misto neni na tele, musi se spocitat aktualni poloha
				//!!! pokud typ pohybu kde znakuji obe ruce provest jen polovicni pohyb ke kontaktu, druhy udela druha ruka
				if(idOfContactJoint!= -1)
				{	
					// spocti aktualni polohu v zavislosti na to ke kteremu joint je misto vztazeno					
					getGlobalJointFromLocal(((flag+1)%2),idOfContactJoint,1,whereCoordRelative,ref whereCoordGlob);
					if((typeOfSign.CompareTo("b1") == 0) && (flag == 1))
						partOfMove /=2.0;
				}
				else
					whereCoordGlob.copyVector(whereCoordRelative);

				//nalezeni souradnic bodu cim, ten musi byt na ruce
				getContactPointFromFile(what+ ',' + flag,coordToContactFileName,ref whatCoordRelative,ref idOfContactJoint);
				if(idOfContactJoint != -1)
				{
					// spocti aktualni polohu v zavislosti na to ke kteremu joint je misto vztazeno
					getGlobalJointFromLocal(flag,idOfContactJoint,1,whatCoordRelative,ref whatCoordGlob);
				}
				else
					throw new GenException.UsingFileException("Znakovac� m�sto zadan� v souboru m� b�t pou�ito jako ��m, ale je ozna�eno jako m�sto na t�le. ��m mus� b�t m�sto na ruce.",coordToContactFileName);

				findStraightMoveFromContact(flag,whereCoordGlob,whatCoordGlob,ref directionOfMove,ref lengthOfMove);				
				makeStraightMove(flag,directionOfMove,(lengthOfMove*partOfMove),1);
			}

			/// <summary>
			/// V�po�et pohybu ot��en� pa�e.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="where">0 - dovnit�, 1 - ven.</param>
			static public void makeWheelMove(int flag,int where)
			{
				if(((flag!= 0 ) && (flag != 1)) || ((where != 0) && (where != 1)))
					throw new GenException.ParameterException("flag: " + flag + ", " + "where: " + where);

				Joint[] hand;
				Joint.Vector actualElbow = new Joint.Vector();
				Joint.Vector actualWrist = new Joint.Vector();
				Joint.Vector rotAxis = new Joint.Vector();
				Joint.Rotation moveRotGlob = new Joint.Rotation();
				Joint.Rotation moveRotLoc = new Joint.Rotation();
				double angle = 0;

				if(flag == 0)
					hand = leftHand;
				else
					hand = rightHand;

				getInfoFromMoveFile(0,flag,where,ref angle);
				getGlobalJointFromLocal(flag,0,0,new Joint.Vector(),ref actualElbow);
				getGlobalJointFromLocal(flag,1,0,new Joint.Vector(),ref actualWrist);
				getVectorFromPoints(actualWrist,actualElbow,ref rotAxis);
				moveRotGlob.setAxis(rotAxis);
				moveRotGlob.angle = angle;
				
				getLocalRotationFromGlobal(flag,2,moveRotGlob,ref moveRotLoc); 
				hand[2].moveLocalRotations.Add(new Joint.Rotation(moveRotLoc.x,moveRotLoc.y,moveRotLoc.z,moveRotLoc.angle));
				hand[2].composeRotation(moveRotLoc,ref hand[2].vrmlRotation,1);
				hand[2].addVrmlRotationToList();
			}
			/// <summary>
			/// V�po�et pohybu v�m�na.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			static public void makeChangeMove(int flag)
			{
				if((flag != 0) && (flag != 1))
					throw new GenException.ParameterException("flag: " + flag);

				Joint.Vector moveUp = new Joint.Vector();
				Joint.Vector moveFrom = new Joint.Vector();
				Joint.Vector beginOri = new Joint.Vector();
				Joint.Vector endOri = new Joint.Vector();
				Joint.Vector fingerDirect = new Joint.Vector();
				Joint.Vector newFingerDirect = new Joint.Vector();
				Joint.Vector middleOri = new Joint.Vector(-1,0,0);
				Joint.Vector tmpVectOfOri = new Joint.Vector();
				double lengthOfMoveUp = 0;
				double lengthOfMoveFrom = 0;
				Joint.Rotation tmpRot = new Joint.Rotation();
				Joint[] hand = leftHand;



				makeContactMove(1,"povrchRukyDlan","povrchRukyDlan");
				makeContactMove(0,"povrchRukyDlan","povrchRukyDlan");

				for(int flagL =0; flagL < 2;flagL++ )
				{
					if(flagL == 1)
					{
						getGlobalVectorFromLocal(flagL,2,rightHand[2].normal,ref moveUp);
						getGlobalVectorFromLocal(flagL,2,dirFingerRight,ref fingerDirect);
						moveFrom.x = -1;
						lengthOfMoveUp = tabRLengthOfMove / 8;
						lengthOfMoveFrom = tabRLengthOfMove / 3;
						middleOri.minusVector();
						hand = rightHand;
					}
					else
					{
						getGlobalVectorFromLocal(flagL,2,leftHand[2].normal,ref moveUp);
						getGlobalVectorFromLocal(flagL,2,dirFingerLeft,ref fingerDirect);
						moveFrom.x = 1;
						lengthOfMoveUp = tabLLengthOfMove / 8;
						lengthOfMoveFrom = tabLLengthOfMove / 3;
					}
				
					beginOri.copyVector(moveUp);
					endOri.copyVector(moveUp);
					endOri.minusVector();
					moveUp.minusVector();

					makeStraightMove(flagL,moveUp,lengthOfMoveUp,1);				
					makeStraightMove(flagL,moveFrom,lengthOfMoveFrom,1);

					keepOri(flagL,beginOri,middleOri,ref tmpRot);

					if(flagL == 0)
						getGlobalVectorFromLocal(flagL,2,dirFingerLeft,ref newFingerDirect);					
					else
						getGlobalVectorFromLocal(flagL,2,dirFingerRight,ref newFingerDirect);					
					
					keepOri(flagL,newFingerDirect,fingerDirect, ref tmpRot);
					hand[2].addVrmlRotationToList();
					hand[0].addVrmlRotationToList();
					hand[1].addVrmlRotationToList();

					keepOri(flagL,middleOri,endOri,ref tmpRot);

					if(flagL == 0)
						getGlobalVectorFromLocal(flagL,2,dirFingerLeft,ref newFingerDirect);					
					else
						getGlobalVectorFromLocal(flagL,2,dirFingerRight,ref newFingerDirect);					
					
					keepOri(flagL,newFingerDirect,fingerDirect, ref tmpRot);
					hand[2].addVrmlRotationToList();
					hand[0].addVrmlRotationToList();
					hand[1].addVrmlRotationToList();

					getGlobalVectorFromLocal(flagL,2,hand[2].normal,ref tmpVectOfOri);
					keepOri(flagL,tmpVectOfOri,moveUp,ref tmpRot);
					hand[2].addVrmlRotationToList();
					hand[0].addVrmlRotationToList();
					hand[1].addVrmlRotationToList();

					moveUp.minusVector();
					makeStraightMove(flagL,moveUp,lengthOfMoveUp*2,1);				

				}				
				makeContactMove(1,"povrchRukyDlan","povrchRukyDlan");
				makeContactMove(0,"povrchRukyDlan","povrchRukyDlan");

			}
			/// <summary>
			/// V�po�et pohybu otev�r�n� nebo zav�r�n� do tvaru ruky.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="finalDEZ">Kone�n� tvar ruky.</param>
			static public void makeDEZmove(int flag,string finalDEZ)
			{ 
				if(((flag != 1) && (flag != 0)) || (finalDEZ == null))
					throw new GenException.ParameterException("flag: " + flag + ", " + "finalDEZ: " + (finalDEZ == null ? "NULL":finalDEZ));

				Joint[] hand;

				if(flag  == 0)
					hand = leftHand;
				else 
					hand = rightHand;
				
				Joint.Rotation tmpRot = new Joint.Rotation();
				Joint.Rotation newRot;

				for(int joint = 3; joint < numberJointHand; joint++)
				{  
					newRot = new Joint.Rotation(hand[joint].vrmlRotation.x,hand[joint].vrmlRotation.y,hand[joint].vrmlRotation.z,hand[joint].vrmlRotation.angle);
					//inverzn� rotace
					newRot.x *= -1;
					newRot.y *= -1;
					newRot.z *= -1;
					hand[joint].moveLocalRotations.Add(newRot);					
				}
				
				setDez(finalDEZ,flag,0);		

				for(int pos = 3; pos < numberJointHand; pos++)
				{
					tmpRot = (Joint.Rotation)hand[pos].moveLocalRotations[hand[pos].moveLocalRotations.Count -1];
					hand[pos].composeRotation(hand[pos].vrmlRotation,ref tmpRot,1);
					hand[pos].addVrmlRotationToList();
				}
			}
			/// <summary>
			/// O�et�en� nep�esnost� p�i zaokrouhlov�n�. V�po�et �hlu z cos a sin nesm� b�t vet�� jako |1|.
			/// </summary>
			/// <param name="cosAlfa">�hel.</param>
			/// <returns>Korektn� hodnota.</returns>
			static public double checkAngleRange(double cosAlfa)
			{
				if(cosAlfa > 1.0)
					return 1.0;
				if(cosAlfa < -1.0)
					return -1.0;				
				else 
					return cosAlfa;
			}

			/// <summary>
			/// P�et�en� funkce makeStraight move, kv�li rozli�en� ORI. Dodr�uje orientaci dlan� a prst�.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="destMoveDirection">Sm�r p��m�ho pohybu.</param>
			/// <param name="lengthOfMove">D�lka pohybu.</param>
			/// <param name="write">0 - nezapisovat do vrml rotac�, 1 - zapisovat.</param>
			static public void makeStraightMove(int flag,Joint.Vector destMoveDirection, double lengthOfMove, int write)
			{
				makeStraightMoveAskOri(flag,destMoveDirection,lengthOfMove,write,0);
			}
			/// <summary>
			/// V�po�et p��m�ho pohybu.
			/// </summary>
			/// <param name="flag">Identifikace pro kterou ruku se m� pohyb prov�d�t. 0 - lev�, 1 - prav�.</param>
			/// <param name="destMoveDirection">Sm�r pohybu.</param>
			/// <param name="lengthOfMove">D�lka pohybu.</param>
			/// <param name="write">0 - nezapisovat do vrml rotac�, 1 - zapisovat.</param>
			/// <param name="action">0 - dodr�ovat sm�ry ORI, 1 - nedodr�ovat sm�ry ORI.</param>
			static public void makeStraightMoveAskOri(int flag,Joint.Vector destMoveDirection, double lengthOfMove, int write, int action)
			{

				Joint[] hand;
				Joint.Vector dirFinger;

				Joint.Vector J0 = new Joint.Vector();	
				Joint.Vector J1 = new Joint.Vector();
				Joint.Vector J2 = new Joint.Vector();
				Joint.Vector finalJ2 = new Joint.Vector();
				Joint.Vector finalJ2InLine = new Joint.Vector();
				Joint.Vector directJ2FromJ0 = new Joint.Vector();
				Joint.Vector directFinalJ2FromJ0 = new Joint.Vector();
				Joint.Vector beginOri1 = new Joint.Vector();
				Joint.Vector beginOri2 = new Joint.Vector();
				Joint.Vector endOri1 = new Joint.Vector();
				Joint.Vector endOri2 = new Joint.Vector();
				Joint.Vector armGlobalNormal = new Joint.Vector();
				Joint.Vector directJ1FromJ0 = new Joint.Vector();
				Joint.Vector axisElbow;

				double distJ0AndJ1 = 0;
				double distJ1AndJ2 = 0;				
				double distJ0AndFinalJ2 = 0;
				double distJ0AndJ2 = 0;
				double angleJ1New = 0;
				double angleJ1Old = 0;				
				double angleJ0New = 0;
				double angleJ0Old = 0;
				double angleJ0Plane = 0;

				Joint.Rotation rotJ0InPlaneLoc = new Joint.Rotation();
				Joint.Rotation rotJ0InSpaceGlob = new Joint.Rotation();
				Joint.Rotation rotJ0InSpaceLoc = new Joint.Rotation();
				Joint.Rotation rotJ1InPlane = new Joint.Rotation();
				Joint.Rotation tmpRotToLocalRot = new Joint.Rotation();

				if((destMoveDirection == null) || (lengthOfMove < 0) || ((write!= 0) && (write != 1)))
					throw new GenException.ParameterException("destMoveDirection: " + (destMoveDirection == null ? "NULL":destMoveDirection.ToString()) + ", " + "lengthOfMove" + lengthOfMove + ", " + "write: " + write);

				// pokud je pohyb prilis kratky tak jej neprovade, v interpolatorech se skopiruji hodnoty predchozi rotace
				if(lengthOfMove < moveEpsilon)
					return;

				if(flag == 0)
				{
					hand = leftHand;
					dirFinger = dirFingerLeft;
					axisElbow = new Joint.Vector(0,0,1);
				}
				else
				{
					hand = rightHand;
					dirFinger = dirFingerRight;
					axisElbow = new Joint.Vector(0,0,-1);
				}
				/*******************************************************************************************************************
				 * Na�ten� vektoru sm�ru ze souboru.
				 * Spo��t�n� kde se glob�ln� nach�zej� klouby znakovac�ho pan��ka po tom co ji� byly provedeny n�jak� rotace.
				 * Spo��t�n� vzd�lenost� jednotliv�ch kloub�.
				 * Spo��t�n� sm�ru prst� a norm�ly dlan� z glob�ln�ho hlediska vzhledem k ji� proveden�m rotac�m. 
				 *******************************************************************************************************************/			

				getGlobalJoints(flag,ref J0,ref J1,ref J2);
				
				// presunout do inicializace 
				distJ0AndJ1 = getDistancePoints(J0,J1);
				distJ1AndJ2 = getDistancePoints(J1,J2);
				distJ0AndJ2 = getDistancePoints(J0,J2);


				getGlobalVectorFromLocal(flag,2,hand[2].normal, ref beginOri1);
				getGlobalVectorFromLocal(flag,2,dirFinger, ref beginOri2);

				/******************************************************************************************************************
					 * Spo��t�n� nov� pozice z�p�st� po dokon�en� po�adovan�ho pohybu.
					 * kontrola, zda nen� kone�n� pozice p��li� daleko, tedy neprovediteln�
					 * ****************************************************************************************************************/

				destMoveDirection.normalize();
				getNewPointFromPointAndVector(J2,destMoveDirection,lengthOfMove,ref finalJ2);
				
				getVectorFromPoints(finalJ2,J0,ref directFinalJ2FromJ0);
				distJ0AndFinalJ2 = getDistancePoints(J0,finalJ2);
				if(distJ0AndFinalJ2 > (distJ0AndJ1 + distJ1AndJ2))
				{
					throw new GenException.ComputingException("Nelze prov�st p��m� pohyb, po�adovan� pohyb je p��li� dlouh�. ");
				}

				/******************************************************************************************************************
					*
					* ****************************************************************************************************************/
				// sm�r p��mky na kter� m� le�et p�enesen� pozice posunut�ho z�p�st�
				getVectorFromPoints(J2,J0,ref directJ2FromJ0);
				getNewPointFromPointAndVector(J0,directJ2FromJ0,distJ0AndFinalJ2,ref finalJ2InLine);
				
				//nastaveni rotace v lokti, osa nutne do souboru				
				angleJ1New = Math.Acos(checkAngleRange((Math.Pow(distJ0AndJ1,2) + Math.Pow(distJ1AndJ2,2) - Math.Pow(distJ0AndFinalJ2,2))/(2*distJ0AndJ1*distJ1AndJ2)));								
				angleJ1Old = Math.Acos(checkAngleRange((Math.Pow(distJ0AndJ1,2) + Math.Pow(distJ1AndJ2,2) - Math.Pow(distJ0AndJ2,2))/(2*distJ0AndJ1*distJ1AndJ2)));
				
				angleJ0New = Math.Asin(checkAngleRange((distJ1AndJ2*Math.Sin(angleJ1New))/(distJ0AndFinalJ2)));
				angleJ0Old = Math.Asin(checkAngleRange((distJ1AndJ2*Math.Sin(angleJ1Old))/(distJ0AndJ2)));

				if (angleJ0New < 0) angleJ0New += Math.PI;
				if (angleJ0Old < 0) angleJ0Old += Math.PI;
				angleJ0Plane = angleJ0Old - angleJ0New;

				rotJ1InPlane.setAxis(axisElbow);
				rotJ1InPlane.angle = -angleJ1New + angleJ1Old;
				hand[1].moveLocalRotations.Add(new Joint.Rotation(rotJ1InPlane.x,rotJ1InPlane.y,rotJ1InPlane.z,rotJ1InPlane.angle));
				hand[1].composeRotation(rotJ1InPlane,ref hand[1].vrmlRotation,1);

				rotJ0InPlaneLoc.angle = angleJ0Plane;
				rotJ0InPlaneLoc.setAxis(axisElbow);
				hand[0].composeRotation(rotJ0InPlaneLoc,ref hand[0].vrmlRotation,1);

				//nastaveni rotace ramene v prostoru, otoceni		
				// smer J0 k FinalJ2InLine je stejny jako smer J0 k J2
				getRotationVectorVector(directJ2FromJ0,directFinalJ2FromJ0,ref rotJ0InSpaceGlob);						
				getLocalRotationFromGlobal(flag,0,rotJ0InSpaceGlob,ref rotJ0InSpaceLoc);					
				hand[0].composeRotation(rotJ0InSpaceLoc,ref hand[0].vrmlRotation,1);			

				hand[0].composeRotation(rotJ0InSpaceLoc,ref rotJ0InPlaneLoc,1);
				hand[0].moveLocalRotations.Add(new Joint.Rotation(rotJ0InPlaneLoc.x,rotJ0InPlaneLoc.y,rotJ0InPlaneLoc.z,rotJ0InPlaneLoc.angle));

				// dodr�et ORI prst� a dlan�
				if(action == 0)
				{
					getGlobalVectorFromLocal(flag,2,hand[2].normal, ref endOri1);				
					keepOri(flag,endOri1,beginOri1,ref tmpRotToLocalRot);
					getGlobalVectorFromLocal(flag,2,dirFinger, ref endOri2);
					keepOri(flag,endOri2,beginOri2,ref tmpRotToLocalRot);
					//pridani loc rotaci pro simultalni pohyb
					hand[2].moveLocalRotations.Add(tmpRotToLocalRot);
				}

				//rotace jsou sou��st� pohybu a je nutn� je zapsat do vrml move listu
				if(write == 1)
				{
					int end = 0;
					//pro action 1 se rotace v z�p�st� nem�n�
					if(action == 0)
						end = 3;
					else
						end = 2;

					for(int pos =0; pos < end; pos++)
						hand[pos].addVrmlRotationToList();
				}
				
			}

		}
	}

