/*
Copyright 2005 Alan Eckhardt, Vojt�ch Fried, Mat�j Hoffmann, David Hoksza, Martina Mat�skov�
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


/*
 * NOTE:
 * 
 * The following code is reused from dictionary mentioned above. 
 * 
 * This part of code is used for transformation signs saved in ASCII file into 
 * internal representation by Notation class. 
 * As this is not part of similarity evaluation algorithm the comments were 
 * not translated English (all the comments are done in Czech).
 * 
 * 2008, Jan Ulrych
 */


using System;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using System.Drawing;



public class Notation : ICloneable
{
	/// <summary>
	/// Maxim�ln� d�lka nota�n�ho z�pisu znaku v Unicodu.
	/// </summary>
	public const int delkaUnicodu = 150;
	/// <summary>
	/// Maxim�ln� d�lka nota�n�ho z�pisu pohybu jedn� ruky v Unicodu.
	/// </summary>
	public const int delkaUniSIG = 60;
	//Typy pro jednotlive komponenty notacniho zapisu
	/// <summary>
	/// Typ znaku.
	/// </summary>
	public enum Typ {nic,ax,b1,b2};
	/// <summary>
	/// M�sto znakov�n�.
	/// </summary>
	public enum TAB 
	{
		nic,celyOblicej,horniCastHlavy,celo,spanekL,spanekP,uchoL,uchoP,okoL,okoP,nos,tvarL,tvarP,
		ustaRty,celistL,celistP,brada,podBradou,krkL,krkP,krk,ramenoL,ramenoP,horniCastTrupuL,horniCastTrupuU,
		horniCastTrupuP,hrudL,hrudU,hrudP,neutralniProstor,hranaTrupuL,hranaTrupuP,pasL,pasU,pasP,
		dolniCastTrupuL,dolniCastTrupuP,bokL,bokP,stehnoL,stehnoP,odKoleneKeKotnikuL,
		odKoleneKeKotnikuP};
	/// <summary>
	/// Tvar ruky.
	/// </summary>
	public enum DEZ{nic,A,A0,Astriska,S_A,O,C,C0,C1,Bstriska,B1ii,Brovno,B0ii,B0iii,Dstriska,Dii,Diii,Drovno,D0iii,Pstriska,Pii,Piii,Provno,P0iii,Viii,Vrovno,V0iii,T_O,Ga,Gastriska,D,D0,I,Iii,P,R,V,V0,Y,B,B0,B1,B1iii,T_Bstriska,petka,petkaiii,petkarovno,ctyrka};
	/// <summary>
	/// Orientace dlan�/prst�.
	/// </summary>
	public enum ORI
	{
		nic,dopredu,dozadu,doleva,doprava,nahoru,dolu,dopreduDoleva,dopreduDoprava,dozaduDoleva,dozaduDoprava,dopreduNahoru,dozaduNahoru,dolevaNahoru,dopravaNahoru,dopreduDolu,dozaduDolu,
		dolevaDolu,dopravaDolu,dopreduDolevaNahoru,dopreduDopravaNahoru,dozaduDolevaNahoru,dozaduDopravaNahoru,dopreduDolevaDolu,dopreduDopravaDolu,dozaduDolevaDolu,dozaduDopravaDolu};	
	public enum HA{nic,pred,za,vlevoOd,vpravoOd,nad,pod,vlevoPred,vpravoPred,vlevoZa,vpravoZa,nahorePred,nahoreZa,vlevoNahoreOd,vpravoNahoreOd,dolePred,doleZa,vlevoDoleOd,vpravoDoleOd,vlevoNahorePred,vpravoNahorePred,vlevoNahoreZa,vpravoNahoreZa,vlevoDolePred,vpravoDolePred,vlevoDoleZa,vpravoDoleZa};
	//public enum KontaktCiJRUD {jednaRukaUvnitrDruhe,kontakt};
	/// <summary>
	/// M�sta kontaktu na ruce.
	/// </summary>
	public enum KdeRuka
	{nic,spickaPalce,spickaUkazovacku,spickaProstrednicku,spickaPrstenicku,spickaMalicku,upatiPalce,upatiUkazovacku,upatiProstrednicku,upatiPrstenicku,upatiMalicku,horniCastPaze,dolniCastPaze,loket,vnejsiZapesti,vnitrniZapesti,spickaPrstu,delkaPrstu,hranaRukyPalec,hranaRukyMalicek,povrchRukyHrbet,meziPrstyAe,meziPrstyEi,meziPrstyIo,meziPrstyOu,povrchRukyDlan};
		
		
	/// <summary>
	/// T��da obsahuj�c� r�zn� typy pohyb�, v pom�rn� bohat� hierarchii objekt�.
	/// </summary>
	public class SIG
	{
		/// <summary>
		/// V��tov� typy pro jednotliv� typy pohyb�.
		/// </summary>
		public enum ModifikatorPohybu{zadnyM,opakovanyPohyb,kratkyPohyb,prudkyPohyb};
		public enum CisloKruhovehoPohybu{zadne = 1,jedna,dve,tri,ctyri,pet,sest,sedm,osm,devet,deset,jedenact,dvanact};
		public enum CastKruhu{zadna,cely,pul,ctvrt};
		public enum JakKroutitZapestim{nijak,zeStranyNaStranu,doprava,doleva,alfa,dokolaDoprava,dokolaDoleva};
		public enum KamOtacetPazi{nikam,dovnitr,ven};
		public enum JakeKyvani {zadne,vertikalni,horizontalni};
		public enum JakaAtomZmenaDEZ {zadna,mavani,skrceniPrstu,trepotani,drobeniSpickamiPrstu};
		public enum OtevritCiZavritRuku{zadne,zavirani,otvirani};
		//public enum JakaZmenaHA{vymena,zkrizeni,vsunuti};
			
		/// <summary>
		/// Obsahuje prvky pohybu tak, jak n�sleduj� za sebou. Prvek pohybu m��e v sob� obsahovat i dal�� prvky pohybu. 
		/// </summary>
		public ArrayList prvkyPohybu; 
			
			
		/// <summary>
		/// Prvek pohybu m��e b�t
		/// a) atomick� pohyb
		/// b)simult�nn� pohyb skl�daj�c� se z atomick�ch pohyb�
		/// c)sekvence pohyb�, kter� m��e obsahovat simult�nn� a atomick� pohyby
		/// </summary>
		public class PrvekPohybu
		{
			/// <summary>
			/// Seznam modifik�tor� pro dan� prvek pohybu, tedy bu� pro atomick� pohyb, nebo pro simult�nn� pohyby, �i pro sekvenci pohyb�.
			/// </summary>
			public ArrayList modifikatoryPohybu; 
				

			/// <summary>
			/// Konstruktor vytvo�� ArrayList p��padn�ch modifik�tor� a napln� p�evodn�ky na 
			/// string, kv�li zobrazovn� notace v RichTextboxu.
			/// </summary>
			public PrvekPohybu()
			{
				modifikatoryPohybu = new ArrayList();
					
			}
			/// <summary>
			/// Virtu�ln� metoda, kter� bubl� od potomk� k p�edk�m a skl�d� v�sledn� string v
			/// Unicodu pro dan� prvek pohybu.
			/// </summary>
			/// <param name="odPotomkuS">Ji� vytvo�en� ��st Unicodu, kter� p�i�la od potomk�.</param>
			/// <returns>Unicodov� reprezentace prvku pohybu.</returns>
			public virtual string classToUnicodePrvekPohybu(string odPotomkuS)
			{
				string prvekUni = odPotomkuS;
				if (modifikatoryPohybu.Count > 0)
				{
					foreach (ModifikatorPohybu modifik in modifikatoryPohybu)
					{
						prvekUni += classToUnicodeModif(modifik);
					}
				}
				return prvekUni;
			}
			/// <summary>
			/// Pro vytvo�en� stringu, kter� bude zobrazen v RichTextBoxu se pou��vaj�
			/// Hashtably p�ev�d�j�c� enum na string (Na rozd�l od p�evodu na Unicode,
			/// kde se v�e �e�� procedurami s rozskokem - to je star�� a trochu prostorov�
			/// n�ro�n�j�� �e�en�). Pouze u t�ch typ� pohybu, kde nen� pro dan� typ v�ce
			/// alternativ (nap�. pot�ebujeme string pro Kyvani, to m� ale sv�j typ), pak
			/// string do procedury classToKvaziRTFPrvekPohybu vlo��me p��mo. 
			/// </summary>
			/// <param name="odPotomkuRTF">String, kter� p�ijde od potomk� a do n�j se
			/// postupn� skl�d� string, jak virtu�ln� metody volaj� sv� base.</param>
			/// <returns>KvaziRTF, nebo� pro zm�ny fontu jsou markery DEZ a TAB,
			/// ke zm�n� dojde a� v RichTextBoxu.</returns>
			public virtual string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				string prvekRTF = odPotomkuRTF;
				if (modifikatoryPohybu.Count > 0)
				{
					foreach (ModifikatorPohybu modifika in modifikatoryPohybu)
					{
						prvekRTF += modifToString[modifika];

					}
				}
				return prvekRTF;
			}
				
			public virtual string vypisPrvek()
			{
				string prvekS = "";
				if (modifikatoryPohybu.Count > 0)
				{
					if (!(modifikatoryPohybu[0].Equals(ModifikatorPohybu.zadnyM)))
					{
						prvekS += "modif:";
						foreach (ModifikatorPohybu modifik2 in modifikatoryPohybu)
						{
							prvekS += modifik2.ToString()+", ";
						}
					}
				}
				return prvekS;
			}
			
		}

		public class SekvencePohybu : PrvekPohybu
		{
			public ArrayList prvkySekvencePohybu ; //bude obsahovat bu� simultanniPohyby nebo atomickePohyby
			
			public SekvencePohybu() :base()
			{
					
				prvkySekvencePohybu = new ArrayList();
			}
			public override string classToUnicodePrvekPohybu(string odPotomkuS)
			{
				string sekUni = "";
				foreach (PrvekPohybu p in prvkySekvencePohybu)
				{
					sekUni += p.classToUnicodePrvekPohybu(""); 	
				}
				sekUni = "{"+sekUni+"}";
				return base.classToUnicodePrvekPohybu(sekUni);
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				string sekRTF = "";
				foreach (PrvekPohybu pr in prvkySekvencePohybu)
				{
					sekRTF += pr.classToKvaziRTFPrvekPohybu(""); 	
				}
				sekRTF = "{"+sekRTF+"}";
				return base.classToKvaziRTFPrvekPohybu(sekRTF);
			}
			public override string vypisPrvek()
			{
				string sekvenS = "Sekvence pohyb�:{";
				foreach (PrvekPohybu prvekSek in prvkySekvencePohybu)
				{
					sekvenS+= prvekSek.vypisPrvek();
				}
				sekvenS += "}"+base.vypisPrvek();
				return sekvenS;
			}

		}

		public class SimultanniPohyb: PrvekPohybu
		{
			public ArrayList atomickePohyby; //bude obsahovat pouze atomick� pohyby
			
			public SimultanniPohyb()
			{
				atomickePohyby = new ArrayList();
			}
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				string simUni = "";
				foreach (AtomickyPohyb a in atomickePohyby)
				{
					simUni += a.classToUnicodePrvekPohybu(""); 	
				}
				simUni = "("+simUni+")";
				return base.classToUnicodePrvekPohybu(simUni);
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				string simRTF = "";
				foreach (AtomickyPohyb at in atomickePohyby)
				{
					simRTF += at.classToKvaziRTFPrvekPohybu(""); 	
				}
				simRTF = "("+simRTF+")";
				return base.classToKvaziRTFPrvekPohybu(simRTF);
			}
			public override string vypisPrvek()
			{
				string simulS = "Simult�nn� pohyby:(";
				foreach (AtomickyPohyb atomPohyb in atomickePohyby)
				{
					simulS+= atomPohyb.vypisPrvek();
				}
				simulS += ")"+base.vypisPrvek();
				return simulS;
			}
		}

		public abstract class AtomickyPohyb: PrvekPohybu
		{
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu(odPotomku+"$"); //�ili modifik�tory p�ijdou a� za odd�lova�
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu(odPotomkuRTF);
			}
			public override string vypisPrvek()
			{
				return base.vypisPrvek ();
			}
				
		}
		public class PrimyPohyb : AtomickyPohyb
		{
			//obsahuje v sob� i nulov� pohyb
			public ORI hodnota;

			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("P"+classToUnicodeORI(hodnota)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu((string)(oriToString[hodnota]));
			}


			public override string vypisPrvek()
			{
				string primyS = "P��m� pohyb:"+hodnota.ToString()+" "+base.vypisPrvek();
				return primyS;
			}

		}
		public class KruhovyPohyb : AtomickyPohyb    //ORI1 a ORI2 se nem�n�
		{
			public CastKruhu cast;
			public CisloKruhovehoPohybu cislo;
			public double prumer;
				
			public KruhovyPohyb()
			{
				prumer = 0.0;
			}
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("@"+classToUnicodeCastKruhu(cast)+classToUnicodeCisloKruhovehoPohybu(cislo)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu((string)(castKruhuToString[cast])+(string)(cisloKruhovehoToString[cislo]));
			}

			public override string vypisPrvek()
			{
				string kruhovyS = "Kruhov� pohyb:"+cast.ToString()+","+cislo.ToString()+" "+base.vypisPrvek();
				return kruhovyS;
			}
		}
		public class ObloukovyPohyb: AtomickyPohyb  //ORI1 a/nebo ORI2 se m�n�
		{
			public CastKruhu cast;  //zde nesm� b�t ��st kruhu cel�, ale nebudeme d�lat nov� typ
			public CisloKruhovehoPohybu cislo;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("B"+classToUnicodeCastKruhu(cast)+classToUnicodeCisloKruhovehoPohybu(cislo)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu((string)(castObloukuToString[cast])+(string)(cisloKruhovehoToString[cislo]));
			}
			public override string vypisPrvek()
			{
				string oblS = "Obloukov� pohyb:"+cast.ToString()+","+cislo.ToString()+" "+base.vypisPrvek();
				return oblS;
			}
		}
		public abstract class ZmenaORI: AtomickyPohyb
		{
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("O"+odPotomku); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu (odPotomkuRTF);
			}

			public override string vypisPrvek()
			{
				return base.vypisPrvek ();
			}
		}
		public class KrouceniZapestim: ZmenaORI
		{
			public JakKroutitZapestim jak;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("w"+classToUnicodeJakKroutitZapestim(jak)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu ("9"+"["+JakKroutitZapestimToString[jak]+"]");
			}

			public override string vypisPrvek()
			{
				string kroS = "Kroucen� z�p�st�m:"+jak.ToString()+" "+base.vypisPrvek();
				return kroS;
			}
		}
		public class OtaceniPaze: ZmenaORI
		{
			public KamOtacetPazi kam;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("o"+classToUnicodeKamOtacetPazi(kam)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu ((string)KamOtacetPaziToString[kam]);
			}
			public override string vypisPrvek()
			{
				string otaS = "Ot��en� pa�e:"+kam.ToString()+" "+base.vypisPrvek();
				return otaS;
			}
		}
		public class Kyvani: ZmenaORI //ohyb v zapesti
		{
			public JakeKyvani jake;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("k"+classToUnicodeJakeKyvani(jake)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu ("4"+"["+JakeKyvaniToString[jake]+"]");
			}
			public override string vypisPrvek()
			{
				string kyvS = "K�v�n�:"+jake.ToString()+" "+base.vypisPrvek();
				return kyvS;
			}
		}
		public abstract class ZmenaDEZ: AtomickyPohyb
		{
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("D"+odPotomku); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu(odPotomkuRTF); 
			}
			public override string vypisPrvek()
			{
				return base.vypisPrvek ();
			}
		}
		public class AtomZmenaDEZ: ZmenaDEZ
		{
			public JakaAtomZmenaDEZ jaka;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu(classToUnicodeJakaAtomZmenaDEZ(jaka)); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu ((string)JakaAtomZmenaDEZToString[jaka]);
			}

			public override string vypisPrvek()
			{
				string atomDEZS = "Atomick� zm�na DEZ:"+jaka.ToString()+" "+base.vypisPrvek();
				return atomDEZS;
			}
		}
		public class OtviraniZaviraniRuky : ZmenaDEZ
		{
			public OtevritCiZavritRuku	ktere;
			public DEZ koncovyTvar;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu(classToUnicodeOtevritCiZavritRuku(ktere)+"["+classToUnicodeDEZ(koncovyTvar)+"]"); 
			}
			/// <summary>
			/// ! Zde nast�v� probl�m, proto�e pro koncov� tvar ruky pot�ebujeme ps�t v jin�m fontu, DEZ.
			/// Do stringu tedy d�me pomocn� symboly DEZ, nap�. DEZaDEZ, a ve v�sledn�m RichTextBoxu se 
			/// najdou a p�em�n� se na zm�nu fontu. 
			/// </summary>
			/// <param name="odPotomkuRTF"></param>
			/// <returns></returns>
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu(otevritCiZavritRukuToString[ktere]+"[DEZ"+dezToString[koncovyTvar]+"DEZ]");
			}
			public override string vypisPrvek()
			{
				string otevZavS = "Otv�r�n�/Zav�r�n� ruky:"+ktere.ToString()+","+koncovyTvar.ToString()+" "+base.vypisPrvek();
				return otevZavS;
			}
		}
		public abstract class ZmenaHA : AtomickyPohyb
		{
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("H"+odPotomku); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu (odPotomkuRTF);
			}

			public override string vypisPrvek()
			{
				return base.vypisPrvek ();
			}
		}
			
		public class Vymena: ZmenaHA
		{
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("v"); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu ("�");
			}
			public override string vypisPrvek()
			{
				string vymS = "V�m�na rukou "+base.vypisPrvek();
				return vymS;
			}
		}

		public class Zkrizeni: ZmenaHA
		{
			public ORI smerLeva;
			public ORI smerPrava;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("z"+"["+classToUnicodeORI(smerLeva)+","+classToUnicodeORI(smerPrava)+"]"); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu ("Z"+"["+oriToString[smerLeva]+"TAB,TAB"+oriToString[smerPrava]+"]");
			}

			public override string vypisPrvek()
			{
				string zkrS = "Zk��en� rukou:"+smerLeva.ToString()+","+smerPrava.ToString()+" "+base.vypisPrvek();
				return zkrS;
			}
		}
		public class Vsunuti: ZmenaHA
		{
			public TAB kdeNaTele;    
			//jen jedno z t�chto 'kde' bude zapln�n�, druh� bude pr�zdn� 
			public KdeRuka[] kdeNaRuce;
			public KdeRuka[] cim;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				string vsuUni = "s[";
				if (kdeNaTele != TAB.nic)
				{
					vsuUni = vsuUni + "T"+classToUnicodeTAB(kdeNaTele);
				}
				else
				{
					foreach (KdeRuka tlapa in kdeNaRuce)
					{
						vsuUni += classToUnicodeKdeRuka(tlapa);
					}	
				}
				vsuUni+=",";
				foreach (KdeRuka tlapa2 in cim)
				{
					vsuUni += classToUnicodeKdeRuka(tlapa2);
				}
				vsuUni+="]";
				return base.classToUnicodePrvekPohybu(vsuUni); 
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				string vsuRTF = "Q[TAB";
				if (kdeNaTele != TAB.nic)
				{
					vsuRTF = vsuRTF + tabToString[kdeNaTele];
				}
				else
				{
					foreach (KdeRuka tlapa in kdeNaRuce)
					{
						vsuRTF += (string)(kdeRukaToString[tlapa]);
					}	
				}
				vsuRTF+=",";
				foreach (KdeRuka tlapa2 in cim)
				{
					vsuRTF += (string)(kdeRukaToString[tlapa2]);
				}
				vsuRTF+= "TAB";
				vsuRTF+="]";
				return base.classToKvaziRTFPrvekPohybu(vsuRTF); 
			}

				
			public override string vypisPrvek()
			{
				string vsuS = "Vsunut�:kde:";
				if (kdeNaTele != TAB.nic)
				{
					vsuS = vsuS + kdeNaTele.ToString();
				}
				else
				{
					foreach (KdeRuka tlapa3 in kdeNaRuce)
					{
						vsuS += tlapa3.ToString()+",";
					}	
				}
				vsuS+=",��m:";
				foreach (KdeRuka tlapa4 in cim)
				{
					vsuS += tlapa4.ToString();
				}	
				vsuS = vsuS + " "+base.vypisPrvek();
				return vsuS;
			}
		}
		public abstract class Kontakt: AtomickyPohyb
		{
				
			public KdeRuka[] cim;
				
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				string konUni ="";
				string cimUni = "";
				foreach (KdeRuka tlapa5 in cim)
				{
					cimUni += classToUnicodeKdeRuka(tlapa5);
				}	
				konUni= "X["+odPotomku+","+cimUni+"]";
				return base.classToUnicodePrvekPohybu(konUni);
						
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				string konRTF ="";
				string cimRTF = "";
				foreach (KdeRuka tlapa5 in cim)
				{
					cimRTF += kdeRukaToString[tlapa5];
				}	
					
				konRTF= "0["+"TAB"+odPotomkuRTF+","+cimRTF+"TAB"+"]";
				return base.classToKvaziRTFPrvekPohybu(konRTF);
			}

			public override string vypisPrvek()
			{
				string konS ="��m:";
				foreach (KdeRuka tlapa6 in cim)
				{
					konS += tlapa6.ToString()+",";
				}	
				konS = konS + " "+base.vypisPrvek();
				return konS;
			}
		}
		public class KKdeTelo : Kontakt
		{
			public TAB kde;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				return base.classToUnicodePrvekPohybu("T"+classToUnicodeTAB(kde));
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				return base.classToKvaziRTFPrvekPohybu((string)(tabToString[kde]));
			}

			public override string vypisPrvek()
			{	
				string kTeS = "Kontakt:kde:"+kde.ToString()+",";
				kTeS = kTeS+" "+base.vypisPrvek();
				return kTeS;
			}
		}
		public class KKdeRuka: Kontakt
		{
			public KdeRuka[] kde;
			public override string classToUnicodePrvekPohybu(string odPotomku)
			{
				string kdeRuUni = "";
				foreach (KdeRuka tlapa7 in kde)
				{
					kdeRuUni += classToUnicodeKdeRuka(tlapa7);
				}	
				return base.classToUnicodePrvekPohybu(kdeRuUni);
			}
			public override string classToKvaziRTFPrvekPohybu(string odPotomkuRTF)
			{
				string kdeRuRTF = "";
				foreach (KdeRuka tlapa7 in kde)
				{
					kdeRuRTF += kdeRukaToString[tlapa7];
				}	
				return base.classToKvaziRTFPrvekPohybu (kdeRuRTF);
			}

			public override string vypisPrvek()
			{	
				string kRuS = "Kontakt:kde:";
				foreach (KdeRuka tlapa8 in kde)
				{
					kRuS += tlapa8.ToString()+",";
				}	
				kRuS = kRuS+" "+base.vypisPrvek();
				return kRuS;
			}
				
		}
			

		public SIG()
		{
			prvkyPohybu = new ArrayList();
				
		} 
		/// <summary>
		/// Slou�� k testovac�mu v�pisu instance t��dy SIG - pohybu. Pro ka�d� prvek pohybu v poli prvkyPohybu
		///  vol� virtu�ln� metodu vypisPrvek(), kter� p�isp�je k v�sledn�mu stringu.
		/// </summary>
		/// <returns>Testovac� v�pis instance pohybu.</returns>
		public string vypisSIG()
		{
			string outputS = "";
			foreach (PrvekPohybu prvek in prvkyPohybu)
			{
				outputS += prvek.vypisPrvek()+"; ";
			}
			return outputS;
		}
		/// <summary>
		/// Slou�� k v�pisu instance t��dy SIG - pohybu - do RichTextBoxu. Pro ka�d� prvek pohybu v poli prvkyPohybu
		///  vol� virtu�ln� metodu classToKvaziRTFPrvekPohybu(""), kter� p�isp�je k v�sledn�mu stringu. V�sledek je string,
		///  kter� obsahuje zna�ky DEZxxxDEZ, TABxxxTAB, �i UNDxxxUND, je-li ve v�sledn�m v�stupu pot�eba m�nit font �i
		///  podtrhnout text mezi zna�kami. Proto je v�sledek 'kvaziRTF'.
		/// </summary>
		/// <returns>V�pis instance pohybu k zobrazen� v RichTextBoxu. Zb�v� je�t� m�nit fonty a podtrh�vat.</returns>
		public string classToKvaziRTFSIG()
		{
			StringBuilder outRTF = new StringBuilder("");
			foreach (PrvekPohybu prvek in prvkyPohybu)
				{
					if (prvek != null)
					{
						outRTF.Append(prvek.classToKvaziRTFPrvekPohybu(""));	
					}
					else
					{
						throw new NotationException("ClassToUnicodeSIG: Pole prvk� pohyb� obsahuje prvky, kter� jsou null.");
					}
				}
			return outRTF.ToString();
			
		}
			
		/// <summary>
		/// Tato procedura v textu RichTextBoxu hled� �et�zce 'DEZ', kter� se pou��vaj� p�rov� - textu mezi nimi
		/// je pot�eba zm�nit font na DEZ.
		///  Podm�nkou spr�vn�ho fungov�n� je, aby RichTextBox nebyl Readonly 9jinak se toti� ned� pracovat se Selection...). Pokud ano
		///  procedura si ho sama p�epne, p�ep�e a pak p�epne zp�t.
		/// </summary>
		/// <param name="cilRTBox">C�lov� RichTextbox</param>
		/// <param name="fontVelikost">Velikost fontu, jak�m se m� ps�t.</param>
		public static void PrefontujDEZ(System.Windows.Forms.RichTextBox cilRTBox,float fontVelikost)
		{
				 
			bool jsouTamDEZ = true;
			bool readOnlyBylTrue = false;
			if (cilRTBox.ReadOnly == true)
			{
				cilRTBox.ReadOnly = false;
				readOnlyBylTrue = true;
			}
			while (jsouTamDEZ)
				{
					int dezPozice = cilRTBox.Find("DEZ",0);
					if (dezPozice >= 0)
					{
						cilRTBox.Select(dezPozice,3); 
						cilRTBox.SelectedText = cilRTBox.SelectedText.Replace("DEZ",""); //pro fungov�n� mus� m�t RTBox Readonly false
						//cilRTBox.Text = cilRTBox.Text.Remove(dezPozice,3); //pozor to nefach�, pa� to nev�m pro� zm�n� font cel�mu text boxu
						int dezPozice2 = cilRTBox.Find("DEZ",0); //koncov� DEZ, !pozor hled�m po odebr�n� prvn�ho DEZu
						if (dezPozice2 <0)
						{
							throw new NotationException("Form�tov�n� pohybu v richTextBoxu (bu� na klikadle nebo v informac�ch o znaku): chyb� druh� zna�ka 'DEZ'!");
							//jsouTamDEZ = false; //proti opakovani okna
						}
						else if (dezPozice2 != (dezPozice+1))
						{
							throw new NotationException("Form�tov�n� pohybu v richTextBoxu (bu� na klikadle nebo v informac�ch o znaku): mezi DEZ a DEZ bu� nic nen�, �emu bych mohl zm�nit font (pr�zdn� DEZ), nebo je tam n�co del��ho ne� jeden znak!");
							//jsouTamDEZ = false; //proti opakovani okna
						}
						else
						{
							cilRTBox.Select(dezPozice,1);
							cilRTBox.SelectionFont = new Font("DEZ",fontVelikost);
							cilRTBox.SelectionLength = 0; //zm�nu jsme ji� provedli
							cilRTBox.Select(dezPozice2,3);
							cilRTBox.SelectedText = cilRTBox.SelectedText.Replace("DEZ","");
							//cilRTBox.Text = cilRTBox.Text.Remove(dezPozice2,3); // Nefach�!
						}
					}
					else
					{
						jsouTamDEZ = false;
					}
				}//while
			
				if (readOnlyBylTrue)
				{
					cilRTBox.ReadOnly = true;
				}
			
		}
		/// <summary>
		/// Tato procedura v textu RichTextBoxu hled� �et�zce 'TAB', kter� se pou��vaj� p�rov� - textu mezi nimi
		/// je pot�eba zm�nit font na TAB.
		///  Podm�nkou spr�vn�ho fungov�n� je, aby RichTextBox nebyl Readonly - jinak se toti� ned� pracovat se Selection...). Pokud ano
		///  procedura si ho sama p�epne, p�ep�e a pak p�epne zp�t.
		/// </summary>
		/// <param name="cilRTBox">C�lov� RichTextbox</param>
		/// <param name="fontVelikost">Velikost fontu, jak�m se m� ps�t.</param>
		public static void PrefontujTAB(System.Windows.Forms.RichTextBox cilRTBox,float fontVelikost)
		{
			bool jsouTamTAB = true;
			bool readOnlyBylTrue = false;
			if (cilRTBox.ReadOnly == true)
			{
				cilRTBox.ReadOnly = false;
				readOnlyBylTrue = true;
			}
			
				while (jsouTamTAB)
				{
					int tabPozice = cilRTBox.Find("TAB",0);
					if (tabPozice >= 0)
					{
						cilRTBox.Select(tabPozice,3);
						cilRTBox.SelectedText = cilRTBox.SelectedText.Replace("TAB","");//pro fungov�n� mus� m�t RTBox Readonly false
						//cilRTBox.Text = cilRTBox.Text.Remove(tabPozice,3);   //pozor to nefachalo, pa� to nev�m pro� m�nilo font cel�mu text boxu
						int tabPozice2 = cilRTBox.Find("TAB",0); //koncov� TAB, !pozor hled�m po odebr�n� prvn�ho TABu
						if (tabPozice2 <0)
						{
							throw new NotationException("Form�tov�n� pohybu v richTextBoxu (bu� na klikadle nebo v informac�ch o znaku): chyb� druh� zna�ka 'TAB'!");
							//jsouTamTAB = false; //proti opakovani okna
						}
						else if (tabPozice2 == tabPozice)
						{
							throw new NotationException("Form�tov�n� pohybu v richTextBoxu (bu� na klikadle nebo v informac�ch o znaku): mezi TAB a TAB nic nen�, �emu bych mohl zm�nit font (pr�zdn� TAB)!");
							//jsouTamTAB = false; //proti opakovani okna
						}
						else
						{
							cilRTBox.Select(tabPozice,tabPozice2-tabPozice);
							cilRTBox.SelectionFont = new Font("TAB",fontVelikost);
							cilRTBox.SelectionLength = 0; //zm�nu jsme ji� provedli
							cilRTBox.Select(tabPozice2,3);
							cilRTBox.SelectedText = cilRTBox.SelectedText.Replace("TAB","");
							//cilRTBox.Text = cilRTBox.Text.Remove(tabPozice2,3); // Nefachalo!
						}
					}
					else
					{
						jsouTamTAB = false;
					}
				}//while
			
				if (readOnlyBylTrue)
				{
					cilRTBox.ReadOnly = true;
				}
			
		}

		public static void podtrhejVystup(System.Windows.Forms.RichTextBox cilRTBox)
		{
			bool jsouTamUND = true;
			bool readOnlyBylTrue = false;
			if (cilRTBox.ReadOnly == true)
			{
				cilRTBox.ReadOnly = false;
				readOnlyBylTrue = true;
			}
			
				while (jsouTamUND)
				{
					int undPozice = cilRTBox.Find("UND",0);
					if (undPozice >= 0)
					{
						cilRTBox.Select(undPozice,3);
						cilRTBox.SelectedText = cilRTBox.SelectedText.Replace("UND","");
						//cilRTBox.Text = cilRTBox.Text.Remove(undPozice,3); //pozor to nefach�, pa� to nev�m pro� zm�n� font cel�mu text boxu
						int undPozice2 = cilRTBox.Find("UND",0); //koncov� UND, !pozor hled�m po odebr�n� prvn�ho UNDu
						if (undPozice2 <0)
						{
							throw new NotationException("FrameSign:vyplnZjednodusenouNotaci:chyb� druh� UND!");
							//jsouTamUND = false; //proti opakovani okna
						}
						else if (undPozice2 == undPozice)
						{
							throw new NotationException("FrameSign:vyplnZjednodusenouNotaci:mezi UND a UND nic nen�, �emu bych mohl zm�nit font (pr�zdn� UND)!");
							//jsouTamUND = false; //proti opakovani okna
						}
						else
						{
							cilRTBox.Select(undPozice,undPozice2-undPozice);
							System.Drawing.FontStyle newFontStyle2;
							newFontStyle2 = FontStyle.Underline;
							cilRTBox.SelectionFont = new Font(cilRTBox.SelectionFont,newFontStyle2);
							cilRTBox.SelectionLength = 0; //zm�nu jsme ji� provedli
							cilRTBox.Select(undPozice2,3);
							cilRTBox.SelectedText = cilRTBox.SelectedText.Replace("UND","");
							//cilRTBox.Text = cilRTBox.Text.Remove(undPozice2,3); // Nefach�!
						}
					}
					else
					{
						jsouTamUND = false;
					}
				}//while
			
				if (readOnlyBylTrue)
				{
					cilRTBox.ReadOnly = true;
				}
		}
		/// <summary>
		/// Testuje, zda se v Unicodu jedn� o za��tek atomick�ho pohybu.
		/// </summary>
		/// <param name="c"></param>
		/// <returns></returns>
		public static bool zacatekAtomickeho(char c)
		{
			if ( (c=='P') || (c=='@') || (c=='B') || (c=='O') || (c=='D') || (c=='H')|| (c=='X') )
			{
				return true;
			}
			else return false;
		}
			
		/// <summary>
		/// Testuje, zda se v Unicodu jedn� o modifik�tor.
		/// </summary>
		/// <param name="c"></param>
		/// <returns></returns>
		public static bool jeModif(char m)
		{
			if ( (m=='.') || (m=='*') || (m=='!') )
			{
				return true;
			}
			else return false;
		}
		/// <summary>
		/// V unicodov� reprezentaci notace od zadan� pozice, pozic, zji��uje, o jak� atomick�
		/// pohyb se jedn�. Ten (s pomoc� specifick�ch procedur pro r�zn� atomick� pohyby) 
		/// rozpozn�, p�id� k n�mu i p��padn� modifik�tory a vr�t� onen pohyb. Posouv� se
		/// ve stringu a v�lednou pozici vr�t� volaj�c�mu.
		/// </summary>
		/// <param name="celyPohybS">String reprezentuj�c� cel� pohyb</param>
		/// <param name="pozic">Aktu�ln� pozice v n�m. Odtud za��t rozpozn�vat atomick� pohyb.</param>
		/// <returns>Instance atomick�ho pohybu.</returns>
		public static AtomickyPohyb unicodeToClassAtom(string celyPohybS,ref int pozic)
		{
			SIG.AtomickyPohyb atomOut = null; //sem se dosad� konkr�tn� atomick� pohyb, p�idaj� se modifik�tory a
			//vr�t� se to; N.B. douf�m, �e typ z�stane ten specifi�t�j�� ne� AtomickyPohyb. Ano.
			
			int i = pozic;
			while ((celyPohybS[i] != '$') && (pozic <=(delkaUniSIG-1)))
			{
				i++;
			}
			if (celyPohybS[i] != '$')
			{
				throw new NotationException("unicodeToClassAtom: chyb� koncov� '$' atomick�ho pohybu.");
				//return null;
			}
			int delkaPohybu = i - pozic; // '$' se nepo��t� 
			string atomPohybString = celyPohybS.Substring(pozic,delkaPohybu);
			pozic = i + 1; //zde naopak a� za dolar
			switch (atomPohybString[0])
			{
				case 'P':
					PrimyPohyb primyPohybLocal = new PrimyPohyb();
					primyPohybLocal.hodnota = unicodeToClassORI(atomPohybString.Substring(1,3));
					if (primyPohybLocal.hodnota == ORI.nic)
					{
						throw new NotationException("unicodeToClassZmenaAtom: p��m� pohyb: z unicodeToClassORI se vr�tilo ORI.nic, poslal jsem n�co �patn�ho z Unicodu:"+atomPohybString.Substring(1,3));
					}
					atomOut = primyPohybLocal;
					break;
				case '@':
					KruhovyPohyb kruhovyPohybLocal = new KruhovyPohyb();
					kruhovyPohybLocal.cast = unicodeToClassCastKruhu(atomPohybString.Substring(1,1));
					if (kruhovyPohybLocal.cast == CastKruhu.zadna)
					{
						throw new NotationException("unicodeToClassZmenaAtom: kruhov� pohyb: z unicodeToClassCastKruhu se vr�tilo CastKruhu.zadna, poslal jsem n�co �patn�ho z Unicodu:"+atomPohybString.Substring(1,1));
					}
					kruhovyPohybLocal.cislo = unicodeToClassCisloKruhovehoPohybu(atomPohybString.Substring(2,(atomPohybString.Length-2)));
					/*z�vis�, zda je ��slo kruhov�ho jedno- �i dvoucifern�*/
					if (kruhovyPohybLocal.cislo == CisloKruhovehoPohybu.zadne)
					{
						throw new NotationException("unicodeToClassZmenaAtom: kruhov� pohyb: z unicodeToClassCisloKruhovehoPohybu se vr�tilo CisloKruhovehoPohybu.zadne, poslal jsem n�co �patn�ho z Unicodu:"+atomPohybString.Substring(2,atomPohybString.Length-2));
					}
					atomOut = kruhovyPohybLocal;
					break;
				case 'B':
					ObloukovyPohyb obloukovyPohybLocal = new ObloukovyPohyb();
					obloukovyPohybLocal.cast = unicodeToClassCastKruhu(atomPohybString.Substring(1,1));
					if (obloukovyPohybLocal.cast == CastKruhu.zadna)
					{
						throw new NotationException("unicodeToClassZmenaAtom: obloukov� pohyb: z unicodeToClassCastKruhu se vr�tilo CastKruhu.zadna, poslal jsem n�co �patn�ho z Unicodu:"+atomPohybString.Substring(1,1));
					}
					obloukovyPohybLocal.cislo = unicodeToClassCisloKruhovehoPohybu(atomPohybString.Substring(2,(atomPohybString.Length-2)));
					/*z�vis�, zda je ��slo kruhov�ho jedno- �i dvoucifern�*/
					if (obloukovyPohybLocal.cislo == CisloKruhovehoPohybu.zadne)
					{
						throw new NotationException("unicodeToClassZmenaAtom: obloukov� pohyb: z unicodeToClassCisloKruhovehoPohybu se vr�tilo CisloKruhovehoPohybu.zadne, poslal jsem n�co �patn�ho z Unicodu:"+atomPohybString.Substring(2,atomPohybString.Length-2));
					}
					atomOut = obloukovyPohybLocal;
					break;
				case 'O':
					atomOut = unicodeToClassZmenaORI(atomPohybString.Substring(1,2));
					break;
				case 'D':
					atomOut = unicodeToClassZmenaDEZ(atomPohybString.Substring(1,(atomPohybString.Length-1)));
					break;
				case 'H':
					atomOut = unicodeToClassZmenaHA(atomPohybString.Substring(1,(atomPohybString.Length-1)));
					break;
				case 'X':
					atomOut = unicodeToClassKontakt(atomPohybString.Substring(1,(atomPohybString.Length-1)));
					break;
						
				default: throw new NotationException("unicodeToClassAtom: Nezn�m� atomick� pohyb.");
					//return null;
			

			}
			bool jeTamMod = false;
			while ((pozic<=(delkaUniSIG-1)) && (SIG.jeModif(celyPohybS[pozic])))
			{
				atomOut.modifikatoryPohybu.Add(SIG.unicodeToClassModif(celyPohybS[pozic]));
				pozic++;
				jeTamMod = true;
			}
			if (!jeTamMod) atomOut.modifikatoryPohybu.Add(SIG.ModifikatorPohybu.zadnyM);
			/*test*/ //MessageBox.Show("Typ v�stupn�ho pohybu:"+atomOut.GetType().ToString());
			
			return	atomOut;
			
		}
		public static void zpracujModifikatory(string modStr,ref ArrayList poleModif)
		{
			for (int j=0; j<modStr.Length;j++)
			{
				poleModif.Add(unicodeToClassModif(modStr[j]));
			}
		}
		/// <summary>
		/// V unicodov� reprezentaci notace od zadan� pozice, pozic, rozpozn�v� simult�nn� pohyb.
		///  Ten (s pomoc� specifick�ch procedur pro atomick� pohyby, modifik�tory) 
		/// rozpozn�, p�id� k n�mu i p��padn� modifik�tory a vr�t� onen pohyb. Posouv� se
		/// ve stringu a v�lednou pozici vr�t� volaj�c�mu.
		/// </summary>
		/// <param name="celejPohybS">String reprezentuj�c� cel� pohyb</param>
		/// <param name="pozi">Aktu�ln� pozice v n�m. Odtud za��t rozpozn�vat simult�nn� pohyb.</param>
		/// <returns>Instance simult�nn�ho pohybu.</returns>
		public static SimultanniPohyb unicodeToClassSimul(string celejPohybS,ref int pozi)
		{
			SimultanniPohyb	simulPohybOut = new SimultanniPohyb();
			while ((celejPohybS[pozi] != ')') && (pozi <=(delkaUniSIG-1)))
				{
					//N.B. Atomick� pohyby uvnit� simult�nn�ho asi nebudou m�t modifik�tory, ale specieln� zat�m nezak�eme. Teoreticky by t�eba jeden z pohyb� mohl b�t kr�tk�.)
					AtomickyPohyb atomPohybSim = SIG.unicodeToClassAtom(celejPohybS,ref pozi);
					simulPohybOut.atomickePohyby.Add(atomPohybSim);
				}
			if (celejPohybS[pozi] != ')')
				{
					throw new NotationException("unicodeToClassSimul: chyb� koncov� z�vorka ')' simult�nn�ch pohyb�.");
					//return null;
				}
			pozi++; //to byla z�vorka ')'
			//za z�vorkou je�t� mohou b�t modifik�tory
			bool bylTamM = false;
			while ((pozi<=(delkaUniSIG-1)) && (SIG.jeModif(celejPohybS[pozi])))
				{
					simulPohybOut.modifikatoryPohybu.Add(SIG.unicodeToClassModif(celejPohybS[pozi]));
					pozi++;
					bylTamM = true;
				}
			if (!bylTamM) simulPohybOut.modifikatoryPohybu.Add(ModifikatorPohybu.zadnyM); 
			return simulPohybOut;
		}

		/// <summary>
		/// Ve stringu rozpozn� instanci prvku pohybu Zm�naORI a vr�t� ji.
		/// </summary>
		/// <param name="zmenaORIS">Unicodov� reprezentace zm�ny ORI</param>
		/// <returns>Instance zm�ny ORI</returns>
		public static ZmenaORI unicodeToClassZmenaORI(string zmenaORIS)
		{
			ZmenaORI zmenaORILocal = null;
			switch(zmenaORIS[0])
				{
					case 'w':
					
						KrouceniZapestim krouceniLocal = new KrouceniZapestim();
						krouceniLocal.jak = unicodeToClassJakKroutitZapestim(zmenaORIS[1]);
						if (krouceniLocal.jak == JakKroutitZapestim.nijak)
						{
							throw new NotationException("unicodeToClassZmenaORI: z unicodeToClassJakKroutitZapestim se vr�tilo JakKroutiZapestim.nijak, poslal jsem n�co �patn�ho z Unicodu:"+zmenaORIS[1]);
						}
						zmenaORILocal = krouceniLocal;
						break;
					
					case 'o':
						OtaceniPaze otaceniPazeLocal = new OtaceniPaze(); 
						if (zmenaORIS[1] == 'd') otaceniPazeLocal.kam = KamOtacetPazi.dovnitr;
						else if (zmenaORIS[1] == 'v') otaceniPazeLocal.kam = KamOtacetPazi.ven;
						else
						{
							otaceniPazeLocal.kam = KamOtacetPazi.nikam;
							throw new NotationException("unicodeToClassZmenaORI: Nezn�m� ot��en� pa�e.");
						}
						zmenaORILocal = otaceniPazeLocal;
						break;
						
					case 'k':
						Kyvani kyvaniLocal = new Kyvani(); 
						if (zmenaORIS[1] == 'v') kyvaniLocal.jake = JakeKyvani.vertikalni;
						else if (zmenaORIS[1] == 'h') kyvaniLocal.jake = JakeKyvani.horizontalni;
						else
						{
							kyvaniLocal.jake = JakeKyvani.zadne;
							throw new NotationException("unicodeToClassZmenaORI: Nezn�m� k�v�n�.");
						}
						zmenaORILocal = kyvaniLocal;
						break;
					default:
						throw new NotationException("unicodeToClassZmenaORI: Nezn�m� zm�na orientace.");
						
				}
				return zmenaORILocal;
		}
		/// <summary>
		/// Ve stringu rozpozn� instanci prvku pohybu Zm�naDEZ a vr�t� ji.
		/// </summary>
		/// <param name="zmenaDEZS">Unicodov� reprezentace zm�ny DEZ</param>
		/// <returns>Instance zm�ny DEZ</returns>
		public static ZmenaDEZ unicodeToClassZmenaDEZ(string zmenaDEZS)
		{
			switch(zmenaDEZS[0])
			{
				case 'm':
					AtomZmenaDEZ atomZmenaDEZLocal = new AtomZmenaDEZ();
					atomZmenaDEZLocal.jaka = JakaAtomZmenaDEZ.mavani;
					return atomZmenaDEZLocal;
				case 's':
					AtomZmenaDEZ atomZmenaDEZLocal2 = new AtomZmenaDEZ();
					atomZmenaDEZLocal2.jaka = JakaAtomZmenaDEZ.skrceniPrstu;
					return atomZmenaDEZLocal2;
				case 't':
					AtomZmenaDEZ atomZmenaDEZLocal3 = new AtomZmenaDEZ();
					atomZmenaDEZLocal3.jaka = JakaAtomZmenaDEZ.trepotani;
					return atomZmenaDEZLocal3;
				case 'd':
					AtomZmenaDEZ atomZmenaDEZLocal4 = new AtomZmenaDEZ();
					atomZmenaDEZLocal4.jaka = JakaAtomZmenaDEZ.drobeniSpickamiPrstu;
					return atomZmenaDEZLocal4;
				case 'z':
					OtviraniZaviraniRuky otvZavLocal = new OtviraniZaviraniRuky();
					otvZavLocal.ktere = OtevritCiZavritRuku.zavirani;
					otvZavLocal.koncovyTvar = unicodeToClassDEZ(zmenaDEZS.Substring(2,3)); //p�esko�ili jsme 'z['
					if (otvZavLocal.koncovyTvar == DEZ.nic)
					{
						throw new NotationException("unicodeToClassZmenaDEZ: z unicodeToClassDEZ se vr�tilo DEZ.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaDEZS.Substring(2,3));
					}
					return otvZavLocal;
				case 'o':
					OtviraniZaviraniRuky otvZavLocal2 = new OtviraniZaviraniRuky();
					otvZavLocal2.ktere = OtevritCiZavritRuku.otvirani;
					otvZavLocal2.koncovyTvar = unicodeToClassDEZ(zmenaDEZS.Substring(2,3)); //p�esko�ili jsme 'z['
					if (otvZavLocal2.koncovyTvar == DEZ.nic)
					{
						throw new NotationException("unicodeToClassZmenaDEZ: z unicodeToClassDEZ se vr�tilo DEZ.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaDEZS.Substring(2,3));
					}
					return otvZavLocal2;
				default:
					throw new NotationException("unicodeToClassZmenaDEZ: Nezn�m� zm�na tvaru ruky.");
					//return null;

			}	
		}
			
		/// <summary>
		/// Ve stringu rozpozn�, o jakou instanci prvku pohybu Zm�naHA se jedn�, a vr�t� ji.
		/// </summary>
		/// <param name="zmenaHAS">Unicodov� reprezentace zm�ny ORI</param>
		/// <returns>Instance zm�ny HA</returns>
		public static ZmenaHA unicodeToClassZmenaHA(string zmenaHAS)
		{
			switch (zmenaHAS[0])
			{
				case 'v':
					return new Vymena();
				case 'z':
					Zkrizeni zkrizeniLocal = new Zkrizeni();
					zkrizeniLocal.smerLeva = unicodeToClassORI(zmenaHAS.Substring(2,3)); //p�esko��me '['
					if (zkrizeniLocal.smerLeva == ORI.nic)
					{
						throw new NotationException("unicodeToClassZmenaHA: z unicodeToClassORI se vr�tilo ORI.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaHAS.Substring(2,3));
					}
					zkrizeniLocal.smerPrava = unicodeToClassORI(zmenaHAS.Substring(6,3)); //p�esko��me z[p00,
					if (zkrizeniLocal.smerLeva == ORI.nic)
					{
						throw new NotationException("unicodeToClassZmenaHA: z unicodeToClassORI se vr�tilo ORI.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaHAS.Substring(6,3));
					}
					return zkrizeniLocal;
				case 's':
					int zacatekCim = 0;
					Vsunuti vsunutiLocal = new Vsunuti();
					if (zmenaHAS[2] == 'T')
					{
						vsunutiLocal.kdeNaTele = unicodeToClassTAB(zmenaHAS.Substring(3,3));
						if (vsunutiLocal.kdeNaTele == TAB.nic)
						{
							throw new NotationException("unicodeToClassZmenaHA: vsunut�, kde: z unicodeToClassTAB se vr�tilo TAB.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaHAS.Substring(3,3));
						}
						zacatekCim =  7; //p�esko��me s[TA00,
					}
					else
					{
						KdeRuka[] tempPoleKde = new KdeRuka[5]; //do toho napln�m z ASCII a pak p�ekop�ruju do nov�ho, kter� ud�l�m p�esn� tak velk�, kolik bude prvk�	
						int kdeVeStringu = 2;
						int kdeVPoli = -1;
						while (zmenaHAS[kdeVeStringu] != ',')
						{
							kdeVPoli++;
							if (kdeVPoli > 4)
							{
								throw new NotationException("unicodeToClassZmenaHA: vsunut�, kde, ruka: u� bylo 5 parametr� do pole kde, asi v Unicodu chyb� ��rka:"+zmenaHAS);
								//break; //kdeVeStringu nech�me a zkus�me to d�t do ,��m�
							}
							tempPoleKde[kdeVPoli] = unicodeToClassKdeRuka(zmenaHAS[kdeVeStringu]);
							if (tempPoleKde[kdeVPoli] == KdeRuka.nic)
							{
								throw new NotationException("unicodeToClassZmenaHA: vsunut�, kde: z unicodeToClassKdeRuka se vr�tilo KdeRuka.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaHAS[kdeVeStringu]);
							}
							kdeVeStringu ++;
						}
						if (zmenaHAS[kdeVeStringu] == ',') {kdeVeStringu ++;}
						zacatekCim = kdeVeStringu;
						KdeRuka[] outPoleKde = new KdeRuka[kdeVPoli+1];
						for (int p=0;p<=kdeVPoli;p++)
						{
							outPoleKde[p]=tempPoleKde[p];	
						}
						vsunutiLocal.kdeNaRuce = outPoleKde;
					}
					int kdeVeStringu2 = zacatekCim;
					KdeRuka[] tempPoleCim = new KdeRuka[5]; //do toho napln�m z ASCII a pak p�ekop�ruju do nov�ho, kter� ud�l�m p�esn� tak velk�, kolik bude prvk�	
					int kdeVPoli2 = -1;
					while (zmenaHAS[kdeVeStringu2] != ']')
					{
						kdeVPoli2++;
						if (kdeVPoli2 > 4)
						{
							throw new NotationException("unicodeToClassZmenaHA: vsunut�, ��m, ruka: u� bylo 5 parametr� do pole ��m, asi v Unicodu chyb� koncov� z�vorka ']':"+zmenaHAS);
							//break;
						}
						tempPoleCim[kdeVPoli2] = unicodeToClassKdeRuka(zmenaHAS[kdeVeStringu2]);
						if (tempPoleCim[kdeVPoli2] == KdeRuka.nic)
						{
							throw new NotationException("unicodeToClassZmenaHA: vsunut�, ��m: z unicodeToClassKdeRuka se vr�tilo KdeRuka.nic, poslal jsem n�co �patn�ho z Unicodu:"+zmenaHAS[kdeVeStringu2]);
						}
						kdeVeStringu2 ++;
					}
					KdeRuka[] outPoleCim = new KdeRuka[kdeVPoli2+1];
					for (int q=0;q<=kdeVPoli2;q++)
					{
						outPoleCim[q]=tempPoleCim[q];	
					}
					vsunutiLocal.cim = outPoleCim;
					return vsunutiLocal;
				
				default:
					throw new NotationException("unicodeToClassZmenaHA: Nezn�m� zm�na vz�jemn� polohy rukou.");
					//return null;
			}
		}
		
		/// <summary>
		/// Ve stringu rozpozn�, o jakou instanci prvku pohybu Kontakt se jedn�, a vr�t� ji.
		/// </summary>
		/// <param name="kontaktS">Unicodov� reprezentace zm�ny ORI</param>
		/// <returns>Instance Kontaktu</returns>
		public static Kontakt unicodeToClassKontakt(string kontaktS)
		{
			int zacatekCim = 0;
			Kontakt kontaktLocal;
			if (kontaktS[0] != '[')
			{
				throw new NotationException("unicodeToClassKontakt: Po 'X' nen�sleduje '['.");
				//return null;
			}
			if (kontaktS[1] == 'T')
			{
				kontaktLocal = new KKdeTelo();
				((KKdeTelo)(kontaktLocal)).kde = unicodeToClassTAB(kontaktS.Substring(2,3));
				if (((KKdeTelo)(kontaktLocal)).kde == TAB.nic)
				{
					throw new NotationException("unicodeToClassKontakt: kde na t�le: z unicodeToClassTAB se vr�tilo TAB.nic, poslal jsem n�co �patn�ho z Unicodu:"+kontaktS.Substring(2,3));
				}
				zacatekCim =  6; //p�esko��me [TA00,
			}
			else
			{
				kontaktLocal = new KKdeRuka();
				KdeRuka[] tempPoleKde = new KdeRuka[5]; //do toho napln�m z ASCII a pak p�ekop�ruju do nov�ho, kter� ud�l�m p�esn� tak velk�, kolik bude prvk�	
				int kdeVeStringu = 1;
				int kdeVPoli = -1;
				while (kontaktS[kdeVeStringu] != ',')
				{
					kdeVPoli++;
					if (kdeVPoli > 4)
					{
						throw new NotationException("unicodeToClassKontakt: kde, ruka: u� bylo 5 parametr� do pole kde, asi v Unicodu chyb� ��rka:"+kontaktS);
						//break; //kdeVeStringu nech�me a zkus�me to d�t do ,��m�
					}
					tempPoleKde[kdeVPoli] = unicodeToClassKdeRuka(kontaktS[kdeVeStringu]);
					if (tempPoleKde[kdeVPoli] == KdeRuka.nic)
					{
						throw new NotationException("unicodeToClassKontakt: kde, ruka: z unicodeToClassKdeRuka se vr�tilo KdeRuka.nic, poslal jsem n�co �patn�ho z Unicodu:"+kontaktS[kdeVeStringu]);
					}
					kdeVeStringu ++;
				}
				if (kontaktS[kdeVeStringu] == ',') {kdeVeStringu ++;}
				zacatekCim = kdeVeStringu;
				KdeRuka[] outPoleKde = new KdeRuka[kdeVPoli+1];
				for (int p=0;p<=kdeVPoli;p++)
				{
					outPoleKde[p]=tempPoleKde[p];	
				}
				((KKdeRuka)(kontaktLocal)).kde = outPoleKde;
			}
			int kdeVeStringu2 = zacatekCim;
			KdeRuka[] tempPoleCim = new KdeRuka[5]; //do toho napln�m z ASCII a pak p�ekop�ruju do nov�ho, kter� ud�l�m p�esn� tak velk�, kolik bude prvk�	
			int kdeVPoli2 = -1;
			while (kontaktS[kdeVeStringu2] != ']')
			{
				kdeVPoli2++;
				if (kdeVPoli2 > 4)
				{
					throw new NotationException("unicodeToClassZmenaHA: vsunut�, ��m, ruka: u� bylo 5 parametr� do pole ��m, asi v Unicodu chyb� koncov� z�vorka ']':"+kontaktS);
					//break;
				}
				tempPoleCim[kdeVPoli2] = unicodeToClassKdeRuka(kontaktS[kdeVeStringu2]);
				if (tempPoleCim[kdeVPoli2] == KdeRuka.nic)
				{
					throw new NotationException("unicodeToClassZmenaHA: vsunut�, ��m: z unicodeToClassKdeRuka se vr�tilo KdeRuka.nic, poslal jsem n�co �patn�ho z Unicodu:"+kontaktS[kdeVeStringu2]);
				}
				kdeVeStringu2 ++;
			}
			KdeRuka[] outPoleCim = new KdeRuka[kdeVPoli2+1];
			for (int q=0;q<=kdeVPoli2;q++)
			{
				outPoleCim[q]=tempPoleCim[q];	
			}
			kontaktLocal.cim = outPoleCim;
			return kontaktLocal;
		}
		/// <summary>
		/// Z charu rozpozn�, o jak� modifik�tor pohybu se jedn�, a vr�t� jej.
		/// </summary>
		/// <param name="ch">Unicodov� reprezentace zm�ny ORI</param>
		/// <returns>Modifik�tor pohybu</returns>
		public static ModifikatorPohybu unicodeToClassModif(char ch)
		{
			switch (ch)
			{
				case '.': 
					return SIG.ModifikatorPohybu.opakovanyPohyb;
				case '*': 
					return SIG.ModifikatorPohybu.kratkyPohyb;
				case '!': 
					return SIG.ModifikatorPohybu.prudkyPohyb;
				default: throw new NotationException("unicodeToClassModif: Nezn�m� modifik�tor pohybu.");
					//return SIG.ModifikatorPohybu.zadnyM;
			}
		}
		public static string classToUnicodeModif(ModifikatorPohybu mo)
		{
			switch (mo)
			{
				case ModifikatorPohybu.opakovanyPohyb:
					return ".";
				case ModifikatorPohybu.kratkyPohyb:
					return "*";
				case ModifikatorPohybu.prudkyPohyb:
					return "!";
				case ModifikatorPohybu.zadnyM:
					return "";
				default: throw new NotationException("classToUnicodeModif: Nezn�m� modifik�tor pohybu.");
					//return "";
			}
		}
		public static CastKruhu unicodeToClassCastKruhu(string castKruhuS)
		{
			switch (castKruhuS)
			{
				case "k":
					return CastKruhu.cely;
				case "p":
					return CastKruhu.pul;
				case "c":
					return CastKruhu.ctvrt;
				default: throw new NotationException("unicodeToClassCastKruhu: Nezn�m� ��st kruhov�ho pohybu.");
					//return CastKruhu.zadna;
			}	
		}
		public static string classToUnicodeCastKruhu(SIG.CastKruhu castKruhuC)
		{
			switch (castKruhuC)
			{
				case CastKruhu.cely:
					return "k";
				case CastKruhu.pul:
					return "p";
				case CastKruhu.ctvrt:
					return "c";
				default: throw new NotationException("classToUnicodeCastKruhu: Nezn�m� ��st kruhov�ho pohybu.");
					//return "";
			}	
		}
		public static CisloKruhovehoPohybu unicodeToClassCisloKruhovehoPohybu(string cisloS)
		{
			switch (cisloS)
			{
				case "1":
					return SIG.CisloKruhovehoPohybu.jedna;
				case "2":
					return SIG.CisloKruhovehoPohybu.dve;
				case "3":
					return SIG.CisloKruhovehoPohybu.tri;
				case "4":
					return SIG.CisloKruhovehoPohybu.ctyri;
				case "5":
					return SIG.CisloKruhovehoPohybu.pet;
				case "6":
					return SIG.CisloKruhovehoPohybu.sest;
				case "7":
					return SIG.CisloKruhovehoPohybu.sedm;
				case "8":
					return SIG.CisloKruhovehoPohybu.osm;
				case "9":
					return SIG.CisloKruhovehoPohybu.devet;
				case "10":
					return SIG.CisloKruhovehoPohybu.deset;
				case "11":
					return SIG.CisloKruhovehoPohybu.jedenact;
				case "12":
					return SIG.CisloKruhovehoPohybu.dvanact;
				default: throw new NotationException("unicodeToClassCisloKruhovehoPohybu: Nezn�m� ��slo kruhov�ho pohybu.");
					//return CisloKruhovehoPohybu.zadne;
			}
		}
			
		public static string classToUnicodeCisloKruhovehoPohybu(SIG.CisloKruhovehoPohybu cisloC)
		{
			switch (cisloC)
			{
				case SIG.CisloKruhovehoPohybu.jedna:
					return "1";
				case SIG.CisloKruhovehoPohybu.dve:
					return "2";
				case SIG.CisloKruhovehoPohybu.tri:
					return "3";
				case SIG.CisloKruhovehoPohybu.ctyri:
					return "4";
				case SIG.CisloKruhovehoPohybu.pet:
					return "5";
				case SIG.CisloKruhovehoPohybu.sest:
					return "6";
				case SIG.CisloKruhovehoPohybu.sedm:
					return "7";
				case SIG.CisloKruhovehoPohybu.osm:
					return "8";
				case SIG.CisloKruhovehoPohybu.devet:
					return "9";
				case SIG.CisloKruhovehoPohybu.deset:
					return "10";
				case SIG.CisloKruhovehoPohybu.jedenact:
					return "11";
				case SIG.CisloKruhovehoPohybu.dvanact:
					return "12";
				case SIG.CisloKruhovehoPohybu.zadne:
					return "";
				default: throw new NotationException("classToUnicodeCisloKruhovehoPohybu: Nezn�m� ��slo kruhov�ho pohybu.");
					//return "";
			}
		}
		public static JakKroutitZapestim unicodeToClassJakKroutitZapestim(char jakKroutitS)
		{
			switch (jakKroutitS)
			{
				case 'z':
					return JakKroutitZapestim.zeStranyNaStranu;
				case 'r':
					return JakKroutitZapestim.doprava;
				case 'l':
					return JakKroutitZapestim.doleva;
				case 'a':
					return JakKroutitZapestim.alfa;
				case 'd':
					return JakKroutitZapestim.dokolaDoprava;
				case 'e':
					return JakKroutitZapestim.dokolaDoleva;
				default: throw new NotationException("unicodeToClassJakKroutitZapestim: Nezn�m� kroucen� z�p�st�m.");
					//return JakKroutitZapestim.nijak;
			}
		}
		public static string classToUnicodeJakKroutitZapestim(SIG.JakKroutitZapestim jakKroutitC)
		{
			switch (jakKroutitC)
			{
				case SIG.JakKroutitZapestim.zeStranyNaStranu:
					return "z";
				case SIG.JakKroutitZapestim.doprava:
					return "r";
				case SIG.JakKroutitZapestim.doleva:
					return "l";
				case SIG.JakKroutitZapestim.alfa:
					return "a";
				case SIG.JakKroutitZapestim.dokolaDoprava:
					return "d";
				case SIG.JakKroutitZapestim.dokolaDoleva:
					return "e";
				default: throw new NotationException("classToUnicodeJakKroutitZapestim: Nezn�m� kroucen� z�p�st�m.");
					//return "";
			}
		}
		public static string classToUnicodeKamOtacetPazi(SIG.KamOtacetPazi kamOtacetC)
		{
			switch (kamOtacetC)
			{
				case SIG.KamOtacetPazi.dovnitr:
					return "d";
				case SIG.KamOtacetPazi.ven:
					return "v";
				default: throw new NotationException("classToUnicodeKamOtacetPazi: Nezn�m� ot��en� pa��.");
					//return "";
			}
									   
		}
		public static string classToUnicodeJakeKyvani(SIG.JakeKyvani jakeKyvaniC)
		{
			switch (jakeKyvaniC)
			{
				case SIG.JakeKyvani.vertikalni:
					return "v";
				case SIG.JakeKyvani.horizontalni:
					return "h";
				default: throw new NotationException("classToUnicodeJakeKyvani: Nezn�m� k�v�n�.");
					//return "";
			}
		}
		public static string classToUnicodeJakaAtomZmenaDEZ(SIG.JakaAtomZmenaDEZ jakaZmenaDEZC)
		{
			switch (jakaZmenaDEZC)
			{
				case SIG.JakaAtomZmenaDEZ.mavani:
					return "m";
				case SIG.JakaAtomZmenaDEZ.skrceniPrstu:
					return "s";
				case SIG.JakaAtomZmenaDEZ.trepotani:
					return "t";
				case SIG.JakaAtomZmenaDEZ.drobeniSpickamiPrstu:
					return "d";
				default: throw new NotationException("classToUnicodeJakaAtomZmenaDEZ: Nezn�m� atomick� zm�na DEZu.");
					//return "";
			}
		}
		public static string classToUnicodeOtevritCiZavritRuku(SIG.OtevritCiZavritRuku otevZavRukuC)
		{
			switch (otevZavRukuC)
			{
				case SIG.OtevritCiZavritRuku.zavirani:
					return "z";
				case SIG.OtevritCiZavritRuku.otvirani:
					return "o";
				default: throw new NotationException("classToUnicodeOtevritCiZavritRuku: Nezn�m� otev��t/zav��t ruku.");
					//return "";
			}
		}

			
	} //class SIG		

		
	//promenne pro jeden notacni zapis, reprezentaci jednoho znaku
	/// <summary>
	/// Polo�ka s typem znaku pro dan� nota�n� z�pis.
	/// </summary>
	public Typ typ;
	/// <summary>
	/// Polo�ka s m�stem znakov�n� prav� ruky pro dan� nota�n� z�pis.
	/// </summary>
	public TAB tabP;
	/// <summary>
	/// Polo�ka s tvarem prav� ruky pro dan� nota�n� z�pis.
	/// </summary>
	public DEZ dezP;
	/// <summary>
	/// Polo�ka s m�stem znakov�n� lev� ruky pro dan� nota�n� z�pis.
	/// </summary>
	public TAB tabL;
	/// <summary>
	///  Polo�ka s tvarem lev� ruky pro dan� nota�n� z�pis.
	/// </summary>
	public DEZ dezL;
	//konec komponent�, podle kter�ch se vyhled�v�
	/// <summary>
	/// Polo�ky s orientac� dlan� a prst� pro levou a pravou ruku pro dan� nota�n� z�pis.
	/// </summary>
	public ORI ori1P,ori2P,ori1L,ori2L;
	/// <summary>
	/// Polo�ka s vz�jemnou polohou rukou pro dan� nota�n� z�pis.
	/// </summary>
	public HA ha;
	/// <summary>
	/// Polo�ka s pohybem prav� ruky pro dan� nota�n� z�pis.
	/// </summary>
	public SIG sigP;
	/// <summary>
	/// Polo�ka s pohybem lev� ruky pro dan� nota�n� z�pis.
	/// </summary>
	public SIG sigL;

	/// <summary>
	/// Hashtably slou��c� k z�sk�n� stringu pro dan� typ. String se pak zobraz� ve specieln�ch fontech (TAB, DEZ, ORI-HA-SIG)
	/// v RichTextBoxu, kde se zobrazuje zjednodu�en� notace (v informac�ch o znaku).
	/// Nap�. pro notaci not z�sk�m z Hashtablu string pro m�sto znakov�n� prav� ruky takto
	///  not.tabToString[not.tabP].ToString(), pro TAB.neutralniProstor to bude "q".
	/// </summary>
	public static Hashtable tabToString, dezToString, oriToString, haToString,
		modifToString, castKruhuToString, cisloKruhovehoToString, castObloukuToString,
		JakKroutitZapestimToString,KamOtacetPaziToString, JakeKyvaniToString,
		JakaAtomZmenaDEZToString,otevritCiZavritRukuToString,kdeRukaToString; 
	public static Hashtable tabToToolTip;
	

	/// <summary>
	/// Konstruktor, kter� vytvo�� pr�zdnou t��du. Tak� vypln� hashtably pot�ebn� pro zobrazov�n� zjednodu�en� notace (t��da na string) 
	/// </summary>
	public Notation()
	{
		naplnPrevodnikyNaString();
		naplnPrevodnikyNaToolTipy();
	}

		
	/// <summary>
	/// Konstruktor, kter� napln� t��du z textov� podoby (k�dov�n� Unicode) znaku. Tak� vypln� hashtably pot�ebn� pro zobrazov�n� zjednodu�en� notace (t��da na string) 
	/// </summary>
	/// <param name="kZnakUnicode">notace v Unicodu (ze serveru)</param>
	public Notation(String kZnakUnicode)
	{
		fromUnicode(kZnakUnicode);
		naplnPrevodnikyNaString();
		naplnPrevodnikyNaToolTipy();
			
	}
	/// <summary>
	/// Vytvo�� dotaz na vyhled�v�n� znak� dle komponent� notace v datab�zi.
	/// </summary>
	/// <returns>Vrac� Hashtable, v n�m� m��e b�t ulo�eno a� p�t vyhled�vac�ch parametr�. 
	/// Pod kl��em "typ" je p��slu�n� Unicodov� reprezentace typu, obdobn� pro tab prav�, lev� a dez prav� a lev�.</returns>
	public Hashtable vytvorDotaz()
	{
		Hashtable dotaz = new Hashtable();
		if (typ != Typ.nic)
		{
			dotaz["typ"] = classToUnicodeTyp(typ);
		}
		if (tabP != TAB.nic)
		{
			dotaz["tabP"] = classToUnicodeTAB(tabP);
		}
		if (dezP != DEZ.nic)
		{
			dotaz["dezP"] = classToUnicodeDEZ(dezP);
		}
		if (tabL != TAB.nic)
		{
			dotaz["tabL"] = classToUnicodeTAB(tabL);
		}
		if (dezL != DEZ.nic)
		{
			dotaz["dezL"] = classToUnicodeDEZ(dezL);
		}

		return dotaz;
	}

	/// <summary>
	/// P�ev�d� notaci ZJ z t��dy na Unicode - ta je pak ulo�ena na serveru.
	/// </summary>
	/// <returns></returns>
	public String ToUnicode()
	{
		String outS = "";
		outS = outS + classToUnicodeTyp(typ) + classToUnicodeTAB(tabP) + classToUnicodeDEZ(dezP)+ classToUnicodeTAB(tabL) + classToUnicodeDEZ(dezL)
			+ classToUnicodeORI(ori1P) + classToUnicodeORI(ori2P) + classToUnicodeORI(ori1L) + classToUnicodeORI(ori2L)+classToUnicodeHA(ha)
			+ classToUnicodeSIG(sigP)+ classToUnicodeSIG(sigL)+"0";
			
		// m�sto pohybu zat�m vycpeme (na d�lku delkaUnicodu) 99 nulami
		//outS+= "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
		if (outS.Length != delkaUnicodu)
		{
			throw new NotationException("V�stupn� Unicode m� �patnou d�lku:"+outS.Length);
		}
		return outS;
	}
	
	/// <summary>
	/// Sb�r� chyby souvisej�c� s na�� intern� notac� znakov�ho jazyka (popis chyby jako parametr string) 
	/// a jednotn� je zpracov�v�.
	/// </summary>
	/// <param name="s"></param>
	/*
	public static void chybaNotation(String s)
	{
		throw new Exception(s + ":Matej-klient");
		//MessageBox.Show(s + ":Matej-klient");
	}
	*/
			
	    
	/// <summary>
	/// Zjist�, zda p��slu�n� instance t��dy p�edstavuje validn� kompletn� notaci znaku, �ili zda 
	/// pro dan� typ znaku jsou vypln�n� p��slu�n� komponenty. Pohyb povol�me nulov�, �ili m��e b�t null.
	/// </summary>
	/// <returns>Vrac� true, jedn�-li se o validn� znak.</returns>
	public bool JsemValidniZnak()
	{
		switch (typ)
		{
			case Typ.ax:
				if ((tabP != TAB.nic) && (dezP != DEZ.nic) && (ori1P != ORI.nic) && (ori2P != ORI.nic) &&
					(ha == HA.nic) && (tabL == TAB.nic) && (dezL == DEZ.nic) && (ori1L == ORI.nic) && (ori2L == ORI.nic) && (sigL == null))
				{
					return true;
				}
				else return false;
			case Typ.b1:
				if ((tabP != TAB.nic) && (dezP != DEZ.nic) && (ori1P != ORI.nic) && (ori2P != ORI.nic) &&
					(ha != HA.nic) && (tabL != TAB.nic) && (dezL != DEZ.nic) && (ori1L != ORI.nic) && (ori2L != ORI.nic))
				{
					return true;
				}
				else return false;
			case Typ.b2:
				if ((tabP != TAB.nic) && (dezP != DEZ.nic) && (ori1P != ORI.nic) && (ori2P != ORI.nic) &&
					(ha != HA.nic) && (tabL != TAB.nic) && (dezL != DEZ.nic) && (ori1L != ORI.nic) && (ori2L != ORI.nic) && (sigL == null))
				{
					return true;
				}
				else return false;
			case Typ.nic:
				return false;
			default:
				return false;
		}
	}
	/// <summary>
	/// Zji��uje, zda se jedn� o pr�zdnou notaci. To je n�kdy d�le�it� rozpoznat  -
	///  nap�. umo�nujeme ulo�it znak s pr�zdnou notac�, tj. bez notace, ale ne se
	///  �patnou - nevalidn� (t� nekompletn�)  notac�.
	/// </summary>
	/// <returns></returns>
	public bool prazdnaNotace()
	{
		if((typ == Notation.Typ.nic)&& (tabL == Notation.TAB.nic) && (tabP == Notation.TAB.nic)
			&& (dezL == Notation.DEZ.nic) && (dezP == Notation.DEZ.nic) && (ori1L == Notation.ORI.nic)
			 && (ori2L == Notation.ORI.nic) && (ori1P == Notation.ORI.nic) && (ori2P == Notation.ORI.nic)
			  && (sigL == null) && (sigP == null)&& (ha == Notation.HA.nic))
		{
			return true;
		}
		else return false;
	}

	/// <summary>
	/// Ze stringu p�edstavuj�c�ho textovou reprezentaci notace (ta je ulo�ena na serveru)
	/// rozpozn� p��slu�n� komponenty a napln� polo�ky instance notace. 
	/// </summary>
	/// <param name="znakUnicode">Textov� reprezentace notace</param>
	private void fromUnicode(String znakUnicode)
	{
		try 
		{
			if (znakUnicode.Length == delkaUnicodu)
			{
				String typString = znakUnicode.Substring(0,2);
				/*test*/ //Console.WriteLine(typString);
				String tabPString = znakUnicode.Substring(2,3);
				String dezPString = znakUnicode.Substring(5,3);
				String tabLString = znakUnicode.Substring(8,3);
				String dezLString = znakUnicode.Substring(11,3);
				String ori1PString = znakUnicode.Substring(14,3);
				String ori2PString = znakUnicode.Substring(17,3);
				String ori1LString = znakUnicode.Substring(20,3);
				String ori2LString = znakUnicode.Substring(23,3);
				String haString = znakUnicode.Substring(26,3);
				String sigPString = znakUnicode.Substring(29,60);
				String sigLString = znakUnicode.Substring(89,60);
				String alterString = znakUnicode.Substring(149,1);
				typ = unicodeToClassTyp(typString);
				tabP = unicodeToClassTAB(tabPString);
				dezP = unicodeToClassDEZ(dezPString);
				tabL = unicodeToClassTAB(tabLString);
				dezL = unicodeToClassDEZ(dezLString);
				ori1P = unicodeToClassORI(ori1PString);
				ori2P = unicodeToClassORI(ori2PString);
				ori1L = unicodeToClassORI(ori1LString);
				ori2L = unicodeToClassORI(ori2LString);
				ha = unicodeToClassHA(haString);
				sigP = unicodeToClassSIG(sigPString);
				sigL = unicodeToClassSIG(sigLString);
			}
			else
			{
				/*!*/ throw new NotationException("Chyba: ASCII reprezentace znaku m� d�lku "+znakUnicode.Length+", ale po�adov�no je "+delkaUnicodu+".");
			}
		}
		catch(System.Exception e)
		{
			throw new NotationException("Notation::fromUnicode: " + e.Message);
		}
	}
	
			  
	//n�sleduj� servisn� procedury, kter� nepracuj� s instanc�, proto jsou static, m��ou
	//pak b�t pou�ity i nap�. zevnit� t��dy SIG 
	private static Typ unicodeToClassTyp(String typS)
	{
		switch(typS)
		{
			case "AX" :
				return Typ.ax;
			case "B1" :
				return Typ.b1;					
			case "B2" :
				return Typ.b2;					
			case "00" :
				return Typ.nic;					
			default :
				/*!*/throw new NotationException("Chyba: Nezn�m� typ znaku");
				//return Typ.nic;
		}
	}
	private static String classToUnicodeTyp(Typ typC)
	{
		switch(typC)
		{
			case Typ.ax :
				return "AX";
			case Typ.b1:
				return "B1";					
			case Typ.b2 :
				return "B2";					
			case Typ.nic:
				return "00";					
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� typ znaku");
				//return "00";
		}
	}

	private static TAB unicodeToClassTAB(String tabS)
	{
		
		switch (tabS)
		{
			case "A00":
				return TAB.celyOblicej;
			case "Aa0":
				return TAB.horniCastHlavy;
			case "Ab0":
				return TAB.celo;
			case "Acl":
				return TAB.spanekL;
			case "Acr":
				return TAB.spanekP;
			case "Adl":
				return TAB.uchoL;
			case "Adr":
				return TAB.uchoP;
			case "Ael":
				return TAB.okoL;
			case "Aer":
				return TAB.okoP;
			case "Af0":
				return TAB.nos;
			case "Agl":
				return TAB.tvarL;
			case "Agr":
				return TAB.tvarP;
			case "Ah0":
				return TAB.ustaRty;
			case "Ail":
				return TAB.celistL;
			case "Air":
				return TAB.celistP;
			case "Aj0":
				return TAB.brada;
			case "Ak0":
				return TAB.podBradou;

			case "Bal":
				return TAB.krkL;
			case "Bar":
				return TAB.krkP;
			case "Bb0":
				return TAB.krk;
			case "Bcl":
				return TAB.ramenoL;
			case "Bcr":
				return TAB.ramenoP;
			case "Bdl":
				return TAB.horniCastTrupuL;
			case "Bdr":
				return TAB.horniCastTrupuP;
			case "Bel":
				return TAB.hrudL;
			case "Beu":
				return TAB.hrudU;
			case "Ber":
				return TAB.hrudP;

			case "C00":
				return TAB.neutralniProstor;

			case "Dal":
				return TAB.hranaTrupuL;
			case "Dar":
				return TAB.hranaTrupuP;
			case "Dbl":
				return TAB.pasL;
			case "Dbu":
				return TAB.pasU;
			case "Dbr":
				return TAB.pasP;
				
			case "Eal":
				return TAB.dolniCastTrupuL;
			case "Ear":
				return TAB.dolniCastTrupuP;
			case "Ebl":
				return TAB.bokL;
			case "Ebr":
				return TAB.bokP;

			case "Fal":
				return TAB.stehnoL;
			case "Fab":
				return TAB.stehnoP;
			case "Fbl":
				return TAB.odKoleneKeKotnikuL;
			case "Fbr":
				return TAB.odKoleneKeKotnikuP;

			case "000":
				return TAB.nic;
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� TAB (m�sto znakov�n�).");
				//return TAB.nic;

		} //switch
	}
	private static String classToUnicodeTAB(TAB tabC)
	{
		switch (tabC)
		{
			case TAB.celyOblicej:
				return "A00";
			case TAB.horniCastHlavy:
				return "Aa0";
			case TAB.celo:
				return "Ab0";
			case TAB.spanekL:
				return "Acl";
			case TAB.spanekP:
				return "Acr";
			case TAB.uchoL:
				return "Adl";
			case TAB.uchoP:
				return "Adr";
			case TAB.okoL:
				return "Ael";
			case TAB.okoP:
				return "Aer";
			case TAB.nos:
				return "Af0";
			case TAB.tvarL:
				return "Agl";
			case TAB.tvarP:
				return "Agr";
			case TAB.ustaRty:
				return "Ah0";
			case TAB.celistL:
				return "Ail";
			case TAB.celistP:
				return "Air";
			case TAB.brada:
				return "Aj0";
			case TAB.podBradou:
				return "Ak0";

			case TAB.krkL:
				return "Bal";
			case TAB.krkP:
				return "Bar";
			case TAB.krk:
				return "Bb0";
			case TAB.ramenoL:
				return "Bcl";
			case TAB.ramenoP:
				return "Bcr";
			case TAB.horniCastTrupuL:
				return "Bdl";
			case TAB.horniCastTrupuP:
				return "Bdr";
			case TAB.hrudL:
				return "Bel";
			case TAB.hrudU:
				return "Beu";
			case TAB.hrudP:
				return "Ber";

			case TAB.neutralniProstor:
				return "C00";

			case TAB.hranaTrupuL:
				return "Dal";
			case TAB.hranaTrupuP:
				return "Dar";
			case TAB.pasL:
				return "Dbl";
			case TAB.pasU:
				return "Dbu";
			case TAB.pasP:
				return "Dbr";
				
			case TAB.dolniCastTrupuL:
				return "Eal";
			case TAB.dolniCastTrupuP:
				return "Ear";
			case TAB.bokL:
				return "Ebl";
			case TAB.bokP:
				return "Ebr";

			case TAB.stehnoL:
				return "Fal";
			case TAB.stehnoP:
				return "Fab";
			case TAB.odKoleneKeKotnikuL:
				return "Fbl";
			case TAB.odKoleneKeKotnikuP:
				return "Fbr";

			case TAB.nic:
				return "000";
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� TAB (m�sto znakov�n�).");
				//return "000";

		} //switch
	}

	private static DEZ unicodeToClassDEZ(String dezS)
	{
		switch (dezS)
		{
				//zav�en� ruka
			case "Aa0":
				return DEZ.A;
			case "Ab0":
				return DEZ.A0;
			case "Aca":
				return DEZ.Astriska;
			case "Acb":
				return DEZ.S_A;
				//pokr�en� ruka
			case "Ba0":
				return DEZ.O;
			case "Bba":
				return DEZ.C;
			case "Bbb":
				return DEZ.C0;
			case "Bbc":
				return DEZ.C1;
			case "Bca":
				return DEZ.Bstriska;
			case "Bcb":
				return DEZ.B1ii;
			case "Bcc":
				return DEZ.Brovno;
			case "Bcd":
				return DEZ.B0ii;
			case "Bce":
				return DEZ.B0iii;
			case "Bda":
				return DEZ.Dstriska;
			case "Bdb":
				return DEZ.Dii;
			case "Bdc":
				return DEZ.Diii;
			case "Bdd":
				return DEZ.Drovno;
			case "Bde":
				return DEZ.D0iii;
			case "Bea":
				return DEZ.Pstriska;
			case "Beb":
				return DEZ.Pii;
			case "Bec":
				return DEZ.Piii;
			case "Bed":
				return DEZ.Provno;
			case "Bee":
				return DEZ.P0iii;
			case "Bfa":
				return DEZ.Viii;
			case "Bfb":
				return DEZ.Vrovno;
			case "Bfc":
				return DEZ.V0iii;
				//ruka s vytr�en�mi n�kter�mi prsty
			case "Caa":
				return DEZ.T_O;
			case "Cba":
				return DEZ.Ga;
			case "Cbb":
				return DEZ.Gastriska;
			case "Cca":
				return DEZ.D;
			case "Ccb":
				return DEZ.D0;
			case "Cda":
				return DEZ.I;
			case "Cdb":
				return DEZ.Iii;
			case "Ce0":
				return DEZ.P;
			case "Cf0":
				return DEZ.R;
			case "Cga":
				return DEZ.V;
			case "Cgb":
				return DEZ.V0;
			case "Cha":
				return DEZ.Y;
				//otev�en� ruka
			case "Daa":
				return DEZ.B;
			case "Dab":
				return DEZ.B0;
			case "Dac":
				return DEZ.B1;
			case "Dad":
				return DEZ.B1iii;
			case "Dae":
				return DEZ.T_Bstriska;
			case "Dba":
				return DEZ.petka;
			case "Dbb":
				return DEZ.petkaiii;
			case "Dbc":
				return DEZ.petkarovno;
			case "Dbd":
				return DEZ.ctyrka;

			case "000":
				return DEZ.nic;
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� tvar ruky (DEZ)");
				//return DEZ.nic;
				
		}
	}
	private static String classToUnicodeDEZ(DEZ dezC)
	{
		switch (dezC)
		{
				//zav�en� ruka
			case DEZ.A:
				return "Aa0";
			case DEZ.A0:
				return "Ab0";
			case DEZ.Astriska:
				return "Aca";
			case DEZ.S_A:
				return "Acb";
				//pokr�en� ruka
			case DEZ.O:
				return "Ba0";
			case DEZ.C:
				return "Bba";
			case DEZ.C0:
				return "Bbb";
			case DEZ.C1:
				return "Bbc";
			case DEZ.Bstriska:
				return "Bca";
			case DEZ.B1ii:
				return "Bcb";
			case DEZ.Brovno:
				return "Bcc";
			case DEZ.B0ii:
				return "Bcd";
			case DEZ.B0iii:
				return "Bce";
			case DEZ.Dstriska:
				return "Bda";
			case DEZ.Dii:
				return "Bdb";
			case DEZ.Diii:
				return "Bdc";
			case DEZ.Drovno:
				return "Bdd";
			case DEZ.D0iii:
				return "Bde";
			case DEZ.Pstriska:
				return "Bea";
			case DEZ.Pii:
				return "Beb";
			case DEZ.Piii:
				return "Bec";
			case DEZ.Provno:
				return "Bed";
			case DEZ.P0iii:
				return "Bee";
			case DEZ.Viii:
				return "Bfa";
			case DEZ.Vrovno:
				return "Bfb";
			case DEZ.V0iii:
				return "Bfc";
				//ruka s vytr�en�mi n�kter�mi prsty
			case DEZ.T_O:
				return "Caa";
			case DEZ.Ga:
				return "Cba";
			case DEZ.Gastriska:
				return "Cbb";
			case DEZ.D:
				return "Cca";
			case DEZ.D0:
				return "Ccb";
			case DEZ.I:
				return "Cda";
			case DEZ.Iii:
				return "Cdb";
			case DEZ.P:
				return "Ce0";
			case DEZ.R:
				return "Cf0";
			case DEZ.V:
				return "Cga";
			case DEZ.V0:
				return "Cgb";
			case DEZ.Y:
				return "Cha";
				//otev�en� ruka
			case DEZ.B:
				return "Daa";
			case DEZ.B0:
				return "Dab";
			case DEZ.B1:
				return "Dac";
			case DEZ.B1iii:
				return "Dad";
			case DEZ.T_Bstriska:
				return "Dae";
			case DEZ.petka:
				return "Dba";
			case DEZ.petkaiii:
				return "Dbb";
			case DEZ.petkarovno:
				return "Dbc";
			case DEZ.ctyrka:
				return "Dbd";

			case DEZ.nic:
				return "000";
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� tvar ruky (DEZ)");
				//return "000";
				
		}
	}
		
	private static ORI unicodeToClassORI(String oriS)
	{
		switch(oriS)
		{
			case "p00":
				return ORI.dopredu;
			case "z00":
				return ORI.dozadu;
			case "l00":
				return ORI.doleva;
			case "r00":
				return ORI.doprava;
			case "n00":
				return ORI.nahoru;
			case "d00":
				return ORI.dolu;

			case "pl0":
				return ORI.dopreduDoleva;
			case "pr0":
				return ORI.dopreduDoprava;
			case "zl0":
				return ORI.dozaduDoleva;
			case "zr0":
				return ORI.dozaduDoprava;

			case "pn0":
				return ORI.dopreduNahoru;
			case "zn0":
				return ORI.dozaduNahoru;
			case "ln0":
				return ORI.dolevaNahoru;
			case "rn0":
				return ORI.dopravaNahoru;

			case "pd0":
				return ORI.dopreduDolu;
			case "zd0":
				return ORI.dozaduDolu;
			case "ld0":
				return ORI.dolevaDolu;
			case "rd0":
				return ORI.dopravaDolu;

			case "pln":
				return ORI.dopreduDolevaNahoru;
			case "prn":
				return ORI.dopreduDopravaNahoru;
			case "zln":
				return ORI.dozaduDolevaNahoru;
			case "zrn":
				return ORI.dozaduDopravaNahoru;

			case "pld":
				return ORI.dopreduDolevaDolu;
			case "prd":
				return ORI.dopreduDopravaDolu;
			case "zld":
				return ORI.dozaduDolevaDolu;
			case "zrd":
				return ORI.dozaduDopravaDolu;

			case "000":
				return ORI.nic;
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� orientace dlan�/prst� (ORI)");
				//return ORI.nic;

		}
	}
	private static String classToUnicodeORI(ORI oriC)
	{
		switch(oriC)
		{
			case ORI.dopredu:
				return "p00";
			case ORI.dozadu:
				return "z00";
			case ORI.doleva:
				return "l00";
			case ORI.doprava:
				return "r00";
			case ORI.nahoru:
				return "n00";
			case ORI.dolu:
				return "d00";

			case ORI.dopreduDoleva:
				return "pl0";
			case ORI.dopreduDoprava:
				return "pr0";
			case ORI.dozaduDoleva:
				return "zl0";
			case ORI.dozaduDoprava:
				return "zr0";

			case ORI.dopreduNahoru:
				return "pn0";
			case ORI.dozaduNahoru:
				return "zn0";
			case ORI.dolevaNahoru:
				return "ln0";
			case ORI.dopravaNahoru:
				return "rn0";

			case ORI.dopreduDolu:
				return "pd0";
			case ORI.dozaduDolu:
				return "zd0";
			case ORI.dolevaDolu:
				return "ld0";
			case ORI.dopravaDolu:
				return "rd0";

			case ORI.dopreduDolevaNahoru:
				return "pln";
			case ORI.dopreduDopravaNahoru:
				return "prn";
			case ORI.dozaduDolevaNahoru:
				return "zln";
			case ORI.dozaduDopravaNahoru:
				return "zrn";

			case ORI.dopreduDolevaDolu:
				return "pld";
			case ORI.dopreduDopravaDolu:
				return "prd";
			case ORI.dozaduDolevaDolu:
				return "zld";
			case ORI.dozaduDopravaDolu:
				return "zrd";

			case ORI.nic:
				return "000";
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� orientace dlan�/prst� (ORI)");
				//return "000";

		}
	}
		
		
	private static HA unicodeToClassHA(String haS)
	{
		//HA - vz�jemn� poloha rukou
			
		switch (haS)
		{
			case "p00":
				return HA.pred;
			case "z00":
				return HA.za;
			case "l00":
				return HA.vlevoOd;
			case "r00":
				return HA.vpravoOd;
			case "n00":
				return HA.nad;
			case "d00":
				return HA.pod;
			case "lp0":
				return HA.vlevoPred;
			case "rp0":
				return HA.vpravoPred;
			case "lz0":
				return HA.vlevoZa;
			case "rz0":
				return HA.vpravoZa;
			case "np0":
				return HA.nahorePred;
			case "nz0":
				return HA.nahoreZa;
			case "ln0":
				return HA.vlevoNahoreOd;
			case "rn0":
				return HA.vpravoNahoreOd;
			case "dp0":
				return HA.dolePred;
			case "dz0":
				return HA.doleZa;
			case "ld0":
				return HA.vlevoDoleOd;
			case "rd0":
				return HA.vpravoDoleOd;
			case "lnp":
				return HA.vlevoNahorePred;
			case "rnp":
				return HA.vpravoNahorePred;
			case "lnz":
				return HA.vlevoNahoreZa;
			case "rnz":
				return HA.vpravoNahoreZa;
			case "ldp":
				return HA.vlevoNahorePred;
			case "rdp":
				return HA.vpravoNahorePred;
			case "ldz":
				return HA.vlevoDoleZa;
			case "rdz":
				return HA.vpravoDoleZa;
									
			case "000":
				return HA.nic;

			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� vz�jemn� poloha rukou (HA)");
				//return HA.nic;

		}
			
	}		
		
	private static String classToUnicodeHA(HA haC)
	{
			
		switch (haC)
		{
			case HA.pred:
				return "p00";
			case HA.za:
				return "z00";
			case HA.vlevoOd:
				return "l00";
			case HA.vpravoOd:
				return "r00";
			case HA.nad:
				return "n00";
			case HA.pod:
				return "d00";
			case HA.vlevoPred:
				return "lp0";
			case HA.vpravoPred:
				return "rp0";
			case HA.vlevoZa:
				return "lz0";
			case HA.vpravoZa:
				return "rz0";
			case HA.nahorePred:
				return "np0";
			case HA.nahoreZa:
				return "nz0";
			case HA.vlevoNahoreOd:
				return "ln0";
			case HA.vpravoNahoreOd:
				return "rn0";
			case HA.dolePred:
				return "dp0";
			case HA.doleZa:
				return "dz0";
			case HA.vlevoDoleOd:
				return "ld0";
			case HA.vpravoDoleOd:
				return "rd0";
			case HA.vlevoNahorePred:
				return "lnp";
			case HA.vpravoNahorePred:
				return "rnp";
			case HA.vlevoNahoreZa:
				return "lnz";
			case HA.vpravoNahoreZa:
				return "rnz";
			case HA.vlevoDolePred:
				return "ldp";
			case HA.vpravoDolePred:
				return "rdp";
			case HA.vlevoDoleZa:
				return "ldz";
			case HA.vpravoDoleZa:
				return "rdz";
			case HA.nic:
				return "000";
			default :
				/*!*/	throw new NotationException("Chyba: Nezn�m� vz�jemn� poloha rukou (HA)");
				//return "000";
						
		} //switch
	}
		
	//Pozor, vrac� objekt
	private static SIG unicodeToClassSIG(String sigS)
	{
		if (sigS[0]=='0')
		{
			return null;
		}
		else
		{
			SIG sigLocal = new SIG();
			int pozice = 0; //pozice ve stringu, kde jsme
			while (pozice <= (delkaUniSIG-1))  //delka je delkaUniSIG, pozice 0-(delkaUniSIG-1)
			{
				if (SIG.zacatekAtomickeho(sigS[pozice])) //atomick� pohyb
				{
					SIG.AtomickyPohyb atomPohybLocal = SIG.unicodeToClassAtom(sigS, ref pozice);
					sigLocal.prvkyPohybu.Add(atomPohybLocal);
				} //endif atomick� pohyb
				else if(sigS[pozice]=='(')  //za��n� simult�nn� pohyb
				{
					pozice++;
					SIG.SimultanniPohyb simulPohybLocal = SIG.unicodeToClassSimul(sigS, ref pozice);
					sigLocal.prvkyPohybu.Add(simulPohybLocal);
				} //endif simult�nn� pohyb
				else if(sigS[pozice]=='{')  //za��n� sekvence pohyb�
				{
					pozice++;
					SIG.SekvencePohybu sekvenPohybLocal = new SIG.SekvencePohybu();
					while (sigS[pozice] != '}' && (pozice <=(delkaUniSIG-1)))
					{
						if (SIG.zacatekAtomickeho(sigS[pozice]))
						{
							SIG.AtomickyPohyb atomPohybLocal2 = SIG.unicodeToClassAtom(sigS, ref pozice);
							sekvenPohybLocal.prvkySekvencePohybu.Add(atomPohybLocal2);
						}
						else if(sigS[pozice]=='(')  //za��n� simult�nn� pohyb
						{
							pozice++;
							SIG.SimultanniPohyb simulPohybLocal2 = SIG.unicodeToClassSimul(sigS, ref pozice);
							sekvenPohybLocal.prvkySekvencePohybu.Add(simulPohybLocal2);
						}
						else //chyba
						{
							throw new NotationException("unicodeToClassSIG: Narazil jsem na nekorektn� znak: "+sigS[pozice].ToString());
							//return null;
						}
					}
					if (sigS[pozice] != '}')
					{
						throw new NotationException("unicodeToClassSIG: chyb� koncov� z�vorka '}' sekvence pohyb�.");
						//return null;
					}
					pozice++; //to byla z�vorka '}'
					//za z�vorkou je�t� mohou b�t modifik�tory
					bool jeTamM = false;
					while ((pozice<=(delkaUniSIG-1)) && (SIG.jeModif(sigS[pozice])))
					{
						sekvenPohybLocal.modifikatoryPohybu.Add(SIG.unicodeToClassModif(sigS[pozice]));
						pozice++;
						jeTamM = true;
					}
					if (!jeTamM) sekvenPohybLocal.modifikatoryPohybu.Add(SIG.ModifikatorPohybu.zadnyM);
					sigLocal.prvkyPohybu.Add(sekvenPohybLocal);
				} //endif sekvence pohyb�
				else if(sigS[pozice]=='0') //To je koncov� znak, p�edpokl�d�m, �e d�l ji� jen nuly.
				{
					break;
				}
			  
			} // while 
			return sigLocal;
		}
	}
	private static string classToUnicodeSIG(SIG sigC)
	{
		StringBuilder outSigS = new StringBuilder("");
		if (sigC != null)
		{
			foreach (SIG.PrvekPohybu pr in sigC.prvkyPohybu)
			{
				if (pr != null)
				{
					outSigS.Append(pr.classToUnicodePrvekPohybu(""));	
				}
				else
				{
					throw new NotationException("ClassToUnicodeSIG: Pole prvk� pohyb� obsahuje prvky, kter� jsou null.");
				}
			}
		}
		/* test*/ //MessageBox.Show("Jen pro zaj�mavost, pr�v� p�eveden� pohyb m� d�lku "+outSigS.Length+" z maxim�ln�ch "+delkaUniSIG);
		int doplnitNul = (delkaUniSIG-outSigS.Length); 
		for (int h=1; h<=doplnitNul; h++)
		{
			outSigS.Append("0");
		}
		return outSigS.ToString();
			
	}
		
	private static KdeRuka unicodeToClassKdeRuka(char kdeRukaS)
	{
		switch (kdeRukaS)
		{
			case 'a':
				return KdeRuka.spickaPalce;
			case 'e':
				return KdeRuka.spickaUkazovacku;
			case 'i':
				return KdeRuka.spickaProstrednicku;
			case 'o':
				return KdeRuka.spickaPrstenicku;
			case 'u':
				return KdeRuka.spickaMalicku;
			case 'A':
				return KdeRuka.upatiPalce;
			case 'E':
				return KdeRuka.upatiUkazovacku;
			case 'I':
				return KdeRuka.upatiProstrednicku;
			case 'O':
				return KdeRuka.upatiPrstenicku;
			case 'U':
				return KdeRuka.upatiMalicku;
			case 'p':
				return KdeRuka.horniCastPaze;
			case 'P':
				return KdeRuka.dolniCastPaze;
			case 'l':
				return KdeRuka.loket;
			case 'z':
				return KdeRuka.vnejsiZapesti;
			case 'Z':
				return KdeRuka.vnitrniZapesti;
			case 's':
				return KdeRuka.spickaPrstu;
			case 'd':
				return KdeRuka.delkaPrstu;
			case 'h':
				return KdeRuka.hranaRukyPalec;
			case 'H':
				return KdeRuka.hranaRukyMalicek;
			case 'r':
				return KdeRuka.povrchRukyHrbet;
			case '1':
				return KdeRuka.meziPrstyAe;
			case '2':
				return KdeRuka.meziPrstyEi;
			case '3':
				return KdeRuka.meziPrstyIo;
			case '4':
				return KdeRuka.meziPrstyOu;
			case 'R':
				return KdeRuka.povrchRukyDlan;

			case '0':
				/*!*/throw new NotationException("Chyba:Do t��dy zapisujeme v HA, kde nic, co� by nem�lo nastat, pole by m�lo b�t men��.");
				//return KdeRuka.nic;
			default:
				/*!*/ throw new NotationException("Chyba: Vz�jemn� poloha rukou (HA) obsahuje kontakt, v ��sti kde je nezn�m� znak.");
				//return KdeRuka.nic;

		}
	}
	private static String classToUnicodeKdeRuka(KdeRuka kdeRukaC)
	{
		switch (kdeRukaC)
		{
			case KdeRuka.spickaPalce:
				return "a";
			case KdeRuka.spickaUkazovacku:
				return "e";
			case KdeRuka.spickaProstrednicku:
				return "i";
			case KdeRuka.spickaPrstenicku:
				return "o";
			case KdeRuka.spickaMalicku:
				return "u";
			case KdeRuka.upatiPalce:
				return "A";
			case KdeRuka.upatiUkazovacku:
				return "E";
			case KdeRuka.upatiProstrednicku:
				return "I";
			case KdeRuka.upatiPrstenicku:
				return "O";
			case KdeRuka.upatiMalicku:
				return "U";
			case KdeRuka.horniCastPaze:
				return "p";
			case KdeRuka.dolniCastPaze:
				return "P";
			case KdeRuka.loket:
				return "l";
			case KdeRuka.vnejsiZapesti:
				return "z";
			case KdeRuka.vnitrniZapesti:
				return "Z";
			case KdeRuka.spickaPrstu:
				return "s";
			case KdeRuka.delkaPrstu:
				return "d";
			case KdeRuka.hranaRukyPalec:
				return "h";
			case KdeRuka.hranaRukyMalicek:
				return "H";
			case KdeRuka.povrchRukyHrbet:
				return "r";
			case KdeRuka.meziPrstyAe:
				return "1";
			case KdeRuka.meziPrstyEi:
				return "2";
			case KdeRuka.meziPrstyIo:
				return "3";
			case KdeRuka.meziPrstyOu:
				return "4";
			case KdeRuka.povrchRukyDlan:
				return "R";

			case KdeRuka.nic:
				/*!*/throw new NotationException("Chyba:Do t��dy zapisujeme v HA, 'kde' je nic, co� by nem�lo nastat, pole by m�lo b�t men��.");
				//return "0";
			default:
				/*!*/ throw new NotationException("Chyba: Vz�jemn� poloha rukou (HA) obsahuje kontakt, v ��sti 'kde' je nezn�m� znak.");
				//return "0";

		}
	}
		
	//pozdeji nebude existovat, nebo bude private
	private void naplnPrevodnikyNaString()
	{
		tabToString = new Hashtable();
		tabToString.Add(TAB.nic,"");
		tabToString.Add(TAB.neutralniProstor,"q");
		tabToString.Add(TAB.horniCastHlavy,"e");
		tabToString.Add(TAB.spanekL,".r");
		tabToString.Add(TAB.celo,"r");
		tabToString.Add(TAB.spanekP,"r-");
		tabToString.Add(TAB.celyOblicej,"w");
		tabToString.Add(TAB.podBradou,"i");
		tabToString.Add(TAB.celistL,".u");
		tabToString.Add(TAB.brada,"u");
		tabToString.Add(TAB.celistP,"u-");
		tabToString.Add(TAB.ustaRty,"o");
		tabToString.Add(TAB.nos,"z");
		tabToString.Add(TAB.krkL,".p");
		tabToString.Add(TAB.krk,"p");
		tabToString.Add(TAB.krkP,"p-");
		tabToString.Add(TAB.okoL,".t");
		tabToString.Add(TAB.okoP,"t-");
		tabToString.Add(TAB.tvarL,"a");
		tabToString.Add(TAB.tvarP,"s");
		tabToString.Add(TAB.uchoL,"d");
		tabToString.Add(TAB.uchoP,"f");
		tabToString.Add(TAB.ramenoL,"y");
		tabToString.Add(TAB.ramenoP,"x");
		tabToString.Add(TAB.horniCastTrupuL,"g");
		tabToString.Add(TAB.horniCastTrupuP,"h");
		tabToString.Add(TAB.hrudL,".g");
		tabToString.Add(TAB.hrudU,"I");
		tabToString.Add(TAB.hrudP,"h-");
		tabToString.Add(TAB.dolniCastTrupuL,"j");
		tabToString.Add(TAB.dolniCastTrupuP,"k");
		tabToString.Add(TAB.pasL,".j");
		tabToString.Add(TAB.pasU,"l");
		tabToString.Add(TAB.pasP,"k-");
		tabToString.Add(TAB.bokL,".b");
		tabToString.Add(TAB.bokP,"b-");
		tabToString.Add(TAB.hranaTrupuL,"c");
		tabToString.Add(TAB.hranaTrupuP,"v");
		tabToString.Add(TAB.stehnoL,".n");
		tabToString.Add(TAB.stehnoP,"n-");
		tabToString.Add(TAB.odKoleneKeKotnikuL,".m");
		tabToString.Add(TAB.odKoleneKeKotnikuP,"m-");

		dezToString = new Hashtable();
		dezToString.Add(DEZ.nic,"");
		dezToString.Add(DEZ.A,"a");
		dezToString.Add(DEZ.A0,"A");
		dezToString.Add(DEZ.Astriska,"S");
		dezToString.Add(DEZ.S_A,"s");
		dezToString.Add(DEZ.B,"b");
		dezToString.Add(DEZ.B0,"B");
		dezToString.Add(DEZ.B1,"n");
		dezToString.Add(DEZ.Bstriska,"N");
		dezToString.Add(DEZ.B1ii,"m");
		dezToString.Add(DEZ.B1iii,"M");
		dezToString.Add(DEZ.Brovno,"h");
		dezToString.Add(DEZ.B0ii,"H");
		dezToString.Add(DEZ.B0iii,"I");
		dezToString.Add(DEZ.T_Bstriska,"j");
		dezToString.Add(DEZ.C,"c");
		dezToString.Add(DEZ.C0,"C");
		dezToString.Add(DEZ.C1,"x");
		dezToString.Add(DEZ.O,"o");
		dezToString.Add(DEZ.T_O,"O");
		dezToString.Add(DEZ.D,"d");
		dezToString.Add(DEZ.D0,"D");
		dezToString.Add(DEZ.Dstriska,"R");
		dezToString.Add(DEZ.Dii,"f");
		dezToString.Add(DEZ.Drovno,"F");
		dezToString.Add(DEZ.Diii,"e");
		dezToString.Add(DEZ.D0iii,"E");
		dezToString.Add(DEZ.petka,"5");
		dezToString.Add(DEZ.petkaiii,"6");
		dezToString.Add(DEZ.petkarovno,"7");
		dezToString.Add(DEZ.V,"v");
		dezToString.Add(DEZ.V0,"V");
		dezToString.Add(DEZ.Vrovno,"g");
		dezToString.Add(DEZ.Viii,"G");
		dezToString.Add(DEZ.V0iii,"z");
		dezToString.Add(DEZ.Ga,"u");
		dezToString.Add(DEZ.Gastriska,"U");
		dezToString.Add(DEZ.I,"i");
		dezToString.Add(DEZ.Iii,"q");
		dezToString.Add(DEZ.Y,"y");
		dezToString.Add(DEZ.P,"p");
		dezToString.Add(DEZ.Pstriska,"P");
		dezToString.Add(DEZ.Pii,"I");
		dezToString.Add(DEZ.Piii,"k");
		dezToString.Add(DEZ.Provno,"L");
		dezToString.Add(DEZ.P0iii,"K");
		dezToString.Add(DEZ.R,"r");
		dezToString.Add(DEZ.ctyrka,"4");

		oriToString = new Hashtable();
		oriToString.Add(ORI.nic,"");
		oriToString.Add(ORI.dopredu,"w");
		oriToString.Add(ORI.dozadu,"x");
		oriToString.Add(ORI.doleva,"a");
		oriToString.Add(ORI.doprava,"d");
		oriToString.Add(ORI.nahoru,"g");
		oriToString.Add(ORI.dolu,"k");
		oriToString.Add(ORI.dopreduDoleva,"q");
		oriToString.Add(ORI.dopreduDoprava,"e");
		oriToString.Add(ORI.dozaduDoleva,"y");
		oriToString.Add(ORI.dozaduDoprava,"c");
		oriToString.Add(ORI.dopreduNahoru,"t");
		oriToString.Add(ORI.dozaduNahoru,"b");
		oriToString.Add(ORI.dolevaNahoru,"f");
		oriToString.Add(ORI.dopravaNahoru,"h");
		oriToString.Add(ORI.dopreduDolu,"i");
		oriToString.Add(ORI.dozaduDolu,",");
		oriToString.Add(ORI.dolevaDolu,"j");
		oriToString.Add(ORI.dopravaDolu,"l");
		oriToString.Add(ORI.dopreduDolevaNahoru,"r");
		oriToString.Add(ORI.dopreduDopravaNahoru,"z");
		oriToString.Add(ORI.dozaduDolevaNahoru,"v");
		oriToString.Add(ORI.dozaduDopravaNahoru,"n");
		oriToString.Add(ORI.dopreduDolevaDolu,"u");
		oriToString.Add(ORI.dopreduDopravaDolu,"o");
		oriToString.Add(ORI.dozaduDolevaDolu,"m");
		oriToString.Add(ORI.dozaduDopravaDolu,".");

		haToString = new Hashtable();
		haToString.Add(HA.nic,"");
		haToString.Add(HA.pred,"w");
		haToString.Add(HA.za,"x");
		haToString.Add(HA.vlevoOd,"a");
		haToString.Add(HA.vpravoOd,"d");
		haToString.Add(HA.nad,"g");
		haToString.Add(HA.pod,"k");
		haToString.Add(HA.vlevoPred,"q");
		haToString.Add(HA.vpravoPred,"e");
		haToString.Add(HA.vlevoZa,"y");
		haToString.Add(HA.vpravoZa,"c");
		haToString.Add(HA.nahorePred,"t");
		haToString.Add(HA.nahoreZa,"b");
		haToString.Add(HA.vlevoNahoreOd,"f");
		haToString.Add(HA.vpravoNahoreOd,"h");
		haToString.Add(HA.dolePred,"i");
		haToString.Add(HA.doleZa,",");
		haToString.Add(HA.vlevoDoleOd,"j");
		haToString.Add(HA.vpravoDoleOd,"l");
		haToString.Add(HA.vlevoNahorePred,"r");
		haToString.Add(HA.vpravoNahorePred,"z");
		haToString.Add(HA.vlevoNahoreZa,"v");
		haToString.Add(HA.vpravoNahoreZa,"n");
		haToString.Add(HA.vlevoDolePred,"u");
		haToString.Add(HA.vpravoDolePred,"o");
		haToString.Add(HA.vlevoDoleZa,"m");
		haToString.Add(HA.vpravoDoleZa,".");

		modifToString = new Hashtable();
		modifToString.Add(SIG.ModifikatorPohybu.zadnyM,"");
		modifToString.Add(SIG.ModifikatorPohybu.opakovanyPohyb,"1");
		modifToString.Add(SIG.ModifikatorPohybu.kratkyPohyb,"2");
		modifToString.Add(SIG.ModifikatorPohybu.prudkyPohyb,"3");

		castKruhuToString = new Hashtable();
		castKruhuToString.Add(SIG.CastKruhu.zadna,"");
		castKruhuToString.Add(SIG.CastKruhu.cely,"A");
		castKruhuToString.Add(SIG.CastKruhu.pul,"S");
		castKruhuToString.Add(SIG.CastKruhu.ctvrt,"D");

		cisloKruhovehoToString = new Hashtable();
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.zadne,"");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.jedna,"!");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.dve,"@");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.tri,"#");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.ctyri,"$");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.pet,"%");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.sest,"^");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.sedm,"&");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.osm,"*");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.devet,"O");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.deset,"!P");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.jedenact,"!!");
		cisloKruhovehoToString.Add(SIG.CisloKruhovehoPohybu.dvanact,"!@");

		castObloukuToString = new Hashtable();
		castObloukuToString.Add(SIG.CastKruhu.zadna,"");
		castObloukuToString.Add(SIG.CastKruhu.pul,"F");
		castObloukuToString.Add(SIG.CastKruhu.ctvrt,"G");
			
		JakKroutitZapestimToString = new Hashtable();
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.nijak,"");
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.zeStranyNaStranu,"C");
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.doprava,"d");
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.doleva,"a");
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.alfa,"`");
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.dokolaDoprava,"Ad");
		JakKroutitZapestimToString.Add(SIG.JakKroutitZapestim.dokolaDoleva,"Aa");
		
		KamOtacetPaziToString = new Hashtable();
		KamOtacetPaziToString.Add(SIG.KamOtacetPazi.nikam,"");
		KamOtacetPaziToString.Add(SIG.KamOtacetPazi.dovnitr,"�");
		KamOtacetPaziToString.Add(SIG.KamOtacetPazi.ven,"�");

		JakeKyvaniToString = new Hashtable();
		JakeKyvaniToString.Add(SIG.JakeKyvani.zadne,"");
		JakeKyvaniToString.Add(SIG.JakeKyvani.vertikalni,"V");
		JakeKyvaniToString.Add(SIG.JakeKyvani.horizontalni,"C");

		JakaAtomZmenaDEZToString = new Hashtable();
		JakaAtomZmenaDEZToString.Add(SIG.JakaAtomZmenaDEZ.zadna,"");
		JakaAtomZmenaDEZToString.Add(SIG.JakaAtomZmenaDEZ.mavani,"5");
		JakaAtomZmenaDEZToString.Add(SIG.JakaAtomZmenaDEZ.skrceniPrstu,"6");
		JakaAtomZmenaDEZToString.Add(SIG.JakaAtomZmenaDEZ.trepotani,"8");
		JakaAtomZmenaDEZToString.Add(SIG.JakaAtomZmenaDEZ.drobeniSpickamiPrstu,"7");
			
		otevritCiZavritRukuToString = new Hashtable();
		otevritCiZavritRukuToString.Add(SIG.OtevritCiZavritRuku.zadne,"");
		otevritCiZavritRukuToString.Add(SIG.OtevritCiZavritRuku.zavirani,"+");
		otevritCiZavritRukuToString.Add(SIG.OtevritCiZavritRuku.otvirani,"�");

		kdeRukaToString = new Hashtable();
		kdeRukaToString.Add(KdeRuka.nic,"");
		kdeRukaToString.Add(KdeRuka.spickaPalce,"Q");
		kdeRukaToString.Add(KdeRuka.spickaUkazovacku,"W");
		kdeRukaToString.Add(KdeRuka.spickaProstrednicku,"E");
		kdeRukaToString.Add(KdeRuka.spickaPrstenicku,"R");
		kdeRukaToString.Add(KdeRuka.spickaMalicku,"T");
		kdeRukaToString.Add(KdeRuka.upatiPalce,"UNDQUND"); //UND znamen�, �e se v RTBoxu mus� podtrhnout
		kdeRukaToString.Add(KdeRuka.upatiUkazovacku,"UNDWUND");
		kdeRukaToString.Add(KdeRuka.upatiProstrednicku,"UNDEUND");
		kdeRukaToString.Add(KdeRuka.upatiPrstenicku,"UNDRUND");
		kdeRukaToString.Add(KdeRuka.upatiMalicku,"UNDTUND");
		kdeRukaToString.Add(KdeRuka.horniCastPaze,"Y");
		kdeRukaToString.Add(KdeRuka.dolniCastPaze,"X");
		kdeRukaToString.Add(KdeRuka.loket,"C");
		kdeRukaToString.Add(KdeRuka.vnitrniZapesti,"F");
		kdeRukaToString.Add(KdeRuka.vnejsiZapesti,"D");
		kdeRukaToString.Add(KdeRuka.spickaPrstu,"A");
		kdeRukaToString.Add(KdeRuka.delkaPrstu,"S");
		kdeRukaToString.Add(KdeRuka.hranaRukyPalec,"J");
		kdeRukaToString.Add(KdeRuka.hranaRukyMalicek,"K");
		kdeRukaToString.Add(KdeRuka.povrchRukyHrbet,"H");
		kdeRukaToString.Add(KdeRuka.povrchRukyDlan,"G");
		kdeRukaToString.Add(KdeRuka.meziPrstyAe,"1");
		kdeRukaToString.Add(KdeRuka.meziPrstyEi,"2");
		kdeRukaToString.Add(KdeRuka.meziPrstyIo,"3");
		kdeRukaToString.Add(KdeRuka.meziPrstyOu,"4");
		
	}
		
	private void naplnPrevodnikyNaToolTipy()
	{
		tabToToolTip = new Hashtable();
		tabToToolTip.Add(TAB.nic,"Nic");
		tabToToolTip.Add(TAB.neutralniProstor,"Neutr�ln� prostor");
		tabToToolTip.Add(TAB.horniCastHlavy,"Horn� ��st hlavy");
		tabToToolTip.Add(TAB.spanekL,"Lev� sp�nek / strana �ela");
		tabToToolTip.Add(TAB.celo,"Horn� ��st obli�eje, �elo ");
		tabToToolTip.Add(TAB.spanekP,"Prav� sp�nek / strana �ela");
		tabToToolTip.Add(TAB.celyOblicej,"Cel� obli�ej");
		tabToToolTip.Add(TAB.podBradou,"Pod bradou");
		tabToToolTip.Add(TAB.celistL,"Lev� �elist / brada");
		tabToToolTip.Add(TAB.brada,"Doln� ��st obli�eje, brada");
		tabToToolTip.Add(TAB.celistP,"Prav� �elist / brada");
		tabToToolTip.Add(TAB.ustaRty,"�sta a rty");
		tabToToolTip.Add(TAB.nos,"Nos");
		tabToToolTip.Add(TAB.krkL,"Vlevo na krku");
		tabToToolTip.Add(TAB.krk,"Krk");
		tabToToolTip.Add(TAB.krkP,"Vpravo na krku");
		tabToToolTip.Add(TAB.okoL,"Lev� oko");
		tabToToolTip.Add(TAB.okoP,"Prav� oko");
		tabToToolTip.Add(TAB.tvarL,"Lev� tv��");
		tabToToolTip.Add(TAB.tvarP,"Prav� tv��");
		tabToToolTip.Add(TAB.uchoL,"Lev� ucho");
		tabToToolTip.Add(TAB.uchoP,"Prav� ucho");
		tabToToolTip.Add(TAB.ramenoL,"Lev� rameno");
		tabToToolTip.Add(TAB.ramenoP,"Prav� rameno");
		tabToToolTip.Add(TAB.horniCastTrupuL,"Lev� horn� ��st trupu");
		tabToToolTip.Add(TAB.horniCastTrupuP,"Prav� horn� ��st trupu");
		tabToToolTip.Add(TAB.hrudL,"Vlevo na hrudi");
		tabToToolTip.Add(TAB.hrudU,"Uprost�ed hrudi");
		tabToToolTip.Add(TAB.hrudP,"Vpravo na hrudi");
		tabToToolTip.Add(TAB.dolniCastTrupuL,"Lev� doln� ��st trupu");
		tabToToolTip.Add(TAB.dolniCastTrupuP,"Prav� doln� ��st trupu");
		tabToToolTip.Add(TAB.pasL,"Pas a t�sn� pod n�m - vlevo");
		tabToToolTip.Add(TAB.pasU,"Pas a t�sn� pod n�m");
		tabToToolTip.Add(TAB.pasP,"Pas a t�sn� pod n�m - vpravo");
		tabToToolTip.Add(TAB.bokL,"Lev� bok");
		tabToToolTip.Add(TAB.bokP,"Prav� bok");
		tabToToolTip.Add(TAB.hranaTrupuL,"Lev� hrana trupu - od podpa�d� k bok�m");
		tabToToolTip.Add(TAB.hranaTrupuP,"Prav� hrana trupu - od podpa�d� k bok�m");
		tabToToolTip.Add(TAB.stehnoL,"Lev� stehno");
		tabToToolTip.Add(TAB.stehnoP,"Prav� stehno");
		tabToToolTip.Add(TAB.odKoleneKeKotnikuL,"Od kolene ke kotn�ku - vlevo");
		tabToToolTip.Add(TAB.odKoleneKeKotnikuP,"Od kolene ke kotn�ku - vpravo");

	}

	public String vypisTest()
	{
		String venS;
		venS = "Typ:"+typ.ToString()+" tabL:"+tabL.ToString()+" dezL:"+dezL.ToString()+" ori1L:"+ori1L.ToString()+" ori2L:"+ori2L.ToString()+" ha:"+ha.ToString()+" tabP:"+tabP.ToString()+" dezP:"+dezP.ToString()+" ori1P:"+ori1P.ToString()+" ori2P:"+ori2P.ToString()+" ";
		if (sigL != null)
		{
			venS += "  "+"sigL: "+sigL.vypisSIG();
		}
			
		if (sigP != null)
		{
			venS += "  "+"sigP: "+sigP.vypisSIG();
		}
			
		return venS;
		//Console.WriteLine("sig:"+sig.ToString());
	}
	

	
	public class NotationException : Exception
	{
		public NotationException(string amessage):base(amessage){}
	}

	public virtual object Clone()
	{
		Notation lres = new Notation(this.ToUnicode());
		return lres;
	}

	public override bool Equals(object avalue)
	{
		if (avalue == null)
			return false;
		if(this.GetType() != avalue.GetType())
			return false;
		return ((Notation)avalue).ToUnicode().Equals(this.ToUnicode());
	}

}
