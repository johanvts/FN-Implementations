﻿Visual similarity in sign language
Jan Ulrych, Michal Kopecký
SISAP 2008


This is an example application of usage similarity evaluation of the signs in Czech Sign Language.


==========
References
==========
This is Microsoft Visual Studio 2005 solution. 
The code is written in C# programming language and requires .NET framework 2.0.
It also uses log4net library to perform debug outputs. It can be found at http://logging.apache.org/log4net/download.html


========
Contents
========
All the files are encoded using cp1250 character set (Microsoft Windows default).


log4net
 - contains compiled version of log4net

Project SimilarityImpl 
 - contains similarity evaluation algorithm that was described in the paper.


Projects Model and Notation 
 - perform transformation of the sign from textual notation into virtual 3D model of human. This code is reused from dictionary between Czech and Czech sign language. Comments are available only in Czech. 


Project VSSLTest
 - contains example application that uses similarity evaluation algorithm. 
 - Application VSSLTest\bin\Release\VSSLTest.exe outputs file output.tex. 
 - Then you can process file showOutput.tex by latex.exe or pdflatex.exe to see results of the similarity evaluation. Processed file contains table with colored cells. Grayed cells mean that these signs form a minimal pair (this signs shoul be similar); black cells shows pairs of signs which are evaluated to be more similar than signs from minimal pair (that is not good :-( ). White cells represent pairs of signs that were evaluated less similar than signs that form minimal pair (that is good :-) ). The less the column contains black cells, the better was the minimal pair recognized by the algorithm as the most similar pair of signs.


signs.txt 
 - contains testing signs represented in special notation.


min-pairs.txt
 - contains list of minimal pairs.
 - each line contains one minimal pair
 - first number on the line identifies the sign for wich the minimal pair is being defined
 - rest of the line contains list of the sign ids that form minimal pair with the first one


vrml_models
 - contains vrml animations of signs in testing database signs.min-pairs.txt 
 - Models can be previewed by opening file model.*.wrl in any VRML player, i.e. FluxPlayer (http://www.mediamachines.com/developer.php).


gpl-2.0.txt
 - GNU GPL 2.0 licence