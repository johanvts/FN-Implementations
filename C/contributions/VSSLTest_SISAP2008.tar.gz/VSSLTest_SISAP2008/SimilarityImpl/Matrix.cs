/*
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


using System;
using System.Collections.Generic;
using System.Text;

namespace SignSimilarity {

	/// <summary>
	/// Class implementing matrices and matrix operations.
	/// </summary>
	public class Matrix {

		/// <summary>
		/// 2D array of double values in matrix
		/// </summary>
		protected double[,] matrix;

		/// <summary>
		/// Matrix height and width
		/// </summary>
		private int height, width;

		protected Matrix() { }

		/// <summary>
		/// Creates new matrix of specified dimensions with undefined contents
		/// </summary>
		/// <param name="height">Matrix height</param>
		/// <param name="width">Matrix width</param>
		public Matrix(int height, int width) {
			init(height, width);
		}

		/// <summary>
		/// Creates new matrix of specified dimensions with undefined contents
		/// </summary>
		/// <param name="height">Matrix height</param>
		/// <param name="width">Matrix width</param>
		protected void init(int height, int width) {
			matrix = new double[height, width];
			this.width = width;
			this.height = height;
		}


		/// <summary>
		/// Returns matrix height (number of lines)
		/// </summary>
		/// <returns>Returns positive integer representing number of lines of matrix.</returns>
		public int getHeight() {
			return height;
		}


		/// <summary>
		/// Returns matrix width (number of columns)
		/// </summary>
		/// <returns>Returns positive integer representing number of columns of matrix.</returns>
		public int getWidth() {
			return width;
		}


		/// <summary>
		/// Multiplies two matrices.
		/// </summary>
		/// <exception cref="InvalidOperationException">
		/// If two matrices does not have compatible dimensions for multiplication, 
		/// i.e. this matrix <code>width</code> differs from <code>arg1.height</code>.
		/// </exception>
		/// <param name="arg1">Second matrix</param>
		/// <returns>Result of multiplication of this matrix by matrix <paramref name="arg1"/></returns>
		public Matrix mul(Matrix arg1) {
			if (width != arg1.height)
				throw new InvalidOperationException("Matrices can not be multiplied");

			Matrix result = new Matrix(height, arg1.width);
			for (int i = 0; i < result.height; i++)
				for (int j = 0; j < result.width; j++) {
					result.set(i, j, 0);
					for (int k = 0; k < width; k++)
						result.set(i, j, result.matrix[i, j] + matrix[i, k] * arg1.matrix[k, j]);
				}
			return result;
		}


		/// <summary>
		/// Multiplies matrix by real number. Does not modify current matrix.
		/// </summary>
		/// <param name="arg1">Multiplication factor.</param>
		/// <returns>New matrix obtained by multiplying every value in current 
		/// matrix by factor <paramref name="arg1"/>.</returns>
		public Matrix mul(double arg1) {
			Matrix res = new Matrix(height, width);
			for (int i = 0; i < height; i++)
				for (int j = 0; j < width; j++)
					res.set(i, j, matrix[i, j] * arg1);
			return res;
		}

		/// <summary>
		/// Adds matrix <paramref name="arg1"/> multiplied by factor 
		/// <paramref name="konst"> to the current matrix.
		/// </summary>
		/// <exception cref="InvalidOperationException">
		/// If two matrices does not have compatible dimensions for sumation, 
		/// i.e. this matrix <code>width</code> differs from <code>arg1.width</code> 
		/// or this matrix <code>height</code> differs from <code>arg1.height</code>.
		/// </exception>
		/// <param name="konst">Multiplication factor for second matrix</param>
		/// <param name="arg1">Second matrix</param>
		/// <returns>Returns new matrix which is sum of current matrix and matrix 
		/// <paramref name="arg1"/> multiplied by factor <paramref name="konst">.
		/// </returns>
		public Matrix add(double konst, Matrix arg1) {
			if (height != arg1.height || width != arg1.width)
				throw new InvalidOperationException("Matrices can not be added");

			Matrix res = new Matrix(height, width);
			for (int i = 0; i < height; i++)
				for (int j = 0; j < width; j++)
					res.set(i, j, matrix[i, j] + konst * arg1.matrix[i, j]);

			return res;
		}

		/// <summary>
		/// Same as <see cref="add"/> with <code>konst = 1</code>.
		/// </summary>
		public Matrix add(Matrix arg1) {
			return add(1, arg1);
		}

		/// <summary>
		/// Same as <see cref="add"/> with <code>konst = -1</code>.
		/// </summary>
		public Matrix sub(Matrix arg1) {
			return add(-1, arg1);
		}

		/// <summary>
		/// Set the value at index (<paramref name="x"/>, <paramref name="y"/>) to <paramref name="value"/>
		/// </summary>
		/// <param name="line">Column index</param>
		/// <param name="column">Line index</param>
		/// <param name="value">New value</param>
		public void set(int line, int column, double value) {
			//if (column < 0 || column >= width || line < 0 || line >= height)
			//	throw new IndexOutOfRangeException();

			matrix[line, column] = value;
		}

		/// <summary>
		/// Returns value for specified index in matrix.
		/// </summary>
		/// <param name="line">Line index</param>
		/// <param name="column">Column index</param>
		/// <returns></returns>
		public double get(int line, int column) {
			//if (column < 0 || column >= width || line < 0 || line >= height)
			//	throw new IndexOutOfRangeException();

			return matrix[line, column];
		}

		/// <summary>
		/// This metdod expects, that current matrix represents column vector. 
		/// This vector is rotated  around axis <code>axis</code> by angle 
		/// <code>alpha</code> clockwise.
		/// 
		/// <code>axis</code> has to be a column vector having Euclidean norm equal to 1.
		/// </summary>
		/// <param name="axis">Axis of rotation</param>
		/// <param name="alpha">Angle of rotation</param>
		/// <returns>Rotated vector</returns>
		public Matrix rotate(Matrix axis, double alpha) {
			alpha = -alpha;

			Matrix nnr = axis.mul(Matrix.dotProduct(axis, this));
			Matrix a1 = this.mul(Math.Cos(alpha));
			Matrix a2 = nnr.mul(1 - Math.Cos(alpha));
			Matrix a3 = Matrix.crossProduct3D(this, axis).mul(Math.Sin(alpha));
			return a1.add(a2).add(a3);
		}


		/// <summary>
		/// Returns textual representation of matrix.
		/// </summary>
		/// <returns></returns>
		public override string ToString() {
			StringBuilder str = new StringBuilder();
			for (int i = 0; i < height; i++) {
				for (int j = 0; j < width; j++)
					str.AppendFormat("{0:F2}", matrix[i, j]).Append("  ");
				str.Append("\n");
			}
			str.Append("\n");
			return str.ToString();
		}


		/// <summary>
		/// Evaluates scalar product of two vectors. This method expects that 
		/// <paramref name="v1"/> and <paramref name="v2"/> to be column vectors 
		/// (<code>width = 1</code>) of the same height.
		/// </summary>
		/// <exception cref="InvalidOperationException">Thrown if <paramref name="v1"/> 
		/// and <paramref name="v2"/> are not columns vectors or does not have the same height.
		/// </exception>
		/// <param name="v1">First vector in scalar product.</param>
		/// <param name="v2">Second vector in scalar product.</param>
		/// <returns>Scalar product of vectors <paramref name="v1"/> and <paramref name="v2"/>.</returns>
		public static double dotProduct(Matrix v1, Matrix v2) {
			if (v1.width > 1 || v2.width > 1 || v1.height != v2.height)
				throw new InvalidOperationException("invalid matrix dimensions for dotProduct");
			double s = 0;
			for (int i = 0; i < v1.height; i++)
				s += v1.matrix[i, 0] * v2.matrix[i, 0];
			return s;
		}

		/// <summary>
		/// Evaluates cross product of two vectors. This method expects that <paramref name="v1"/> 
		/// and <paramref name="v2"/> to be column vectors (<code>width = 1</code>) of height equal to 3.
		/// </summary>
		/// <exception cref="InvalidOperationException">Thrown if <paramref name="v1"/> 
		/// and <paramref name="v2"/> are not columns vectors or does not have the height 
		/// equal to 3.</exception>
		/// <param name="v1">First vector in cross product.</param>
		/// <param name="v2">Second vector in cross product.</param>
		/// <returns>Cross product of vectors <paramref name="v1"/> and 
		/// <paramref name="v2"/>.</returns>
		public static Vector3D crossProduct3D(Matrix v1, Matrix v2) {
			if (v1.width > 1 || v2.width > 1 || v1.height != v2.height || v1.height != 3)
				throw new InvalidOperationException("invalid matrix dimensions for dotProduct");

			return new Vector3D(
				v1.matrix[1, 0] * v2.matrix[2, 0] - v1.matrix[2, 0] * v2.matrix[1, 0],
				v1.matrix[2, 0] * v2.matrix[0, 0] - v1.matrix[0, 0] * v2.matrix[2, 0],
				v1.matrix[0, 0] * v2.matrix[1, 0] - v1.matrix[1, 0] * v2.matrix[0, 0]
			);
		}

		/// <summary>
		/// Returns Euclidean norm of the vector.
		/// </summary>
		/// <exception cref="InvalidOperationException">Thrown if this matrix does not 
		/// represent a column vector, <seealso cref="dotProduct"/>.</exception>
		public double euclideanNorm() {
			return Math.Sqrt(dotProduct(this, this));
		}


		/// <summary>
		/// Normalizes the vector to have the Euclidean length equal to 1. vrac� vektor se 
		/// stejn�m sm�rem, ale jednotkov� d�lky
		/// </summary>
		/// <exception cref="InvalidOperationException">Thrown if this matrix does not represent 
		/// a column vector, <seealso cref="dotProduct"/>.</exception>
		/// <returns>Returns a new vector having the same direction as current vector, but its 
		/// Euclidean length is equal to 1.</returns>
		public Matrix normalize() {
			double norm = euclideanNorm();
			Matrix res = new Matrix(height, width);
			for (int i = 0; i < height; i++)
				for (int j = 0; j < width; j++)
					res.set(i, j, matrix[i, j] / norm);
			return res;
		}

	}




	/// <summary>
	/// Class representing three-dimensional vector (x,y,z).
	/// </summary>
	public class Vector3D : Matrix {

		public Vector3D() {
			init(3, 1);
		}

		public Vector3D(Joint.Vector vect) {
			init(3, 1);
			set(0, 0, vect.x);
			set(1, 0, vect.y);
			set(2, 0, vect.z);
		}

		/// <summary>
		/// Instantiates new Vector3D and sets its values..
		/// </summary>
		/// <param name="x">x-coordinate value.</param>
		/// <param name="y">y-coordinate value.</param>
		/// <param name="z">z-coordinate value.</param>
		public Vector3D(double x, double y, double z) {
			init(3, 1);
			set(0, 0, x);
			set(1, 0, y);
			set(2, 0, z);
		}

		/// <summary>
		/// Instantiates new Vector3D with values (<code>r.x</code>,<code>r.y</code>,<code>r.z</code>) 
		/// representing axis of rotation.
		/// </summary>
		/// <param name="r"></param>
		public Vector3D(Joint.Rotation r) {
			init(3, 1);
			set(0, 0, r.x);
			set(1, 0, r.y);
			set(2, 0, r.z);
		}

		/// <summary>
		/// Subtracts vector <paramref name="v"/> from current vector.
		/// </summary>
		/// <param name="v">Subtrahend</param>
		public Vector3D sub(Vector3D v) {
			Matrix r = ((Matrix)this).sub(v);
			return new Vector3D(r.get(0, 0), r.get(1, 0), r.get(2, 0));
		}

		/// <summary>
		/// Adds vector <paramref name="v"/> to the current vector..
		/// </summary>
		/// <param name="v">Vector, that will be added to the vurrent vector.</param>
		public Vector3D add(Vector3D v) {
			Matrix r = ((Matrix)this).add(v);
			return new Vector3D(r.get(0, 0), r.get(1, 0), r.get(2, 0));
		}

		/// <summary>
		/// Converts <code>Vector3D</code> to the class <code>Joint.Vector</code>.
		/// </summary>
		public Joint.Vector getVector() {
			return new Joint.Vector(get(0, 0), get(1, 0), get(2, 0));
		}
	}

}