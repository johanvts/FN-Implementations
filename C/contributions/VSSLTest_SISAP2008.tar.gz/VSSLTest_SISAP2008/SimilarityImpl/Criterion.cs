/*
Copyright 2007 Jan Ulrych, Michal Kopeck�

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


using System;
using System.Collections.Generic;
using System.Text;
using log4net;



namespace SignSimilarity {


	/// <summary>
	/// Abstract class representing general criterion. This criterion is used for evaluation 
	/// of similarity of two model states.
	/// </summary>
	public abstract class Criterion {
		protected static readonly ILog log = LogManager.GetLogger(
			System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


		/// <summary>
		/// criterion id
		/// </summary>
		protected int id;


		/// <summary>
		/// criterion weight
		/// </summary>
		public double weight;


		/// <summary>
		/// Helper method for automatic generation of id for criteria.
		/// </summary>
		private static int criterionId = 1;
		protected static int getNewCriterionId() {
			return criterionId++;
		}


		/// <summary>
		/// Common proximal meassure constant.
		/// </summary>
		protected const double POWER = .5;


		/// <summary>
		/// Constructor, assignes unique id to the newly created criterion. Call this in every subclass.
		/// </summary>
		/// <param name="vaha">Weight assigned to this criteion.</param>
		protected Criterion(double weight) {
			id = getNewCriterionId();
			this.weight = weight;
		}


		/// <summary>
		/// Class representing criterion value.
		/// </summary>
		public class Data {
			public Vector3D v;
			public double val;

			public Data(Vector3D v, double val) {
				this.v = v;
				this.val = val;
			}
		}


		/// <summary>
		/// Evaluates this criterion using data passed in parameters
		/// </summary>
		/// <param name="sign1">Criterion status (result of method <c>preeval</c>) for the first sign.</param>
		/// <param name="sign2">Criterion status (result of method <c>preeval</c>) for the second sign.</param>
		/// <param name="diffed">Tell whether or not to use proximal measeure.</param>
		/// <returns>Returns real value in interval [0, 1], where value of 0 represents identity, 
		/// value of 1 represents nonsimilar signs states</returns>
		public abstract double eval(Dictionary<int, Data> sign1, Dictionary<int, Data> sign2, bool diffed);


		/// <summary>
		/// Evaluates criterion status.
		/// </summary>
		/// <param name="sign">Sign on which the criterion statuses will be evaluated.</param>
		/// <param name="hand">Hand for which the criterion status is evaluated</param>
		public abstract void preeval(Dictionary<int, Data> results, SignForSimilarity sign, 
			int rotationsIndex, Hand hand);


		/// <summary>
		/// For the criterion with specified Id it returns flag whether or not should the 
		/// <c>applyDiffForCriterionCache</c> method be called. Searches also criteria in 
		/// subsequent tree hierarchy. There this method needs to be called onlz on the 
        /// top level of the tree.
		/// </summary>
		/// <param name="criterionId">Criterion Id in which we are interested</param>
		/// <returns>Returns value -1 if in the subtree of the criterion, on which the 
        /// method was invoked, does not contain criterion with the specified Id.
        /// 
		/// Returns value 0 if the subtree of the criterion, on wich the method was invocated, 
        /// contains with specified Id and its <c>applyDiff</c> attribute value is <c>false</c>.
		/// 
        /// Returns value 1 if the subtree of the criterion, on wich the method was invocated, 
        /// contains with specified Id and its <c>applyDiff</c> attribute value is <c>true</c>.
        /// </returns>
        public abstract int getApplyDiff(int criterionId);


		/// <summary>
		/// Returns criterion weight.
		/// </summary>
		public double getWeight() {
			return weight;
		}


		/// <summary>
		/// Normalizes value <paramref name="value"/> into interval [0, 1].
		/// </summary>
		/// <param name="value">Value to be normalized.</param>
		/// <returns>Returns 0 if the <paramref name="value"/> is less than 0;
		///          returns 1 if the <paramref name="value"/> is greater than 1;
		///          otherwise returns <paramref name="value"/> unchanged. 
		/// </returns>
		protected double normalize(double value) {
			return Math.Max(0, Math.Min(1, value));
		}


		/// <summary>
		/// Normalizes value <paramref name="value"/> into interval [-1, 1].
		/// </summary>
		/// <param name="value">Value to be normalized.</param>
		/// <returns>Returns -1 if the <paramref name="value"/> is less than -1;
		///          returns 1 if the <paramref name="value"/> is greater than 1;
		///          otherwise returns <paramref name="value"/> unchanged. 
		/// </returns>
		protected double normalizeOO(double value) {
			return Math.Max(-1, Math.Min(1, value));
		}


		/// <summary>
		/// Returns index of the begining of the section of joints for left and right hand. 
		/// This method is used in <c>eval</c> method.
		/// </summary>
		/// <param name="hand">Hand for which we need an offset</param>
		/// <returns></returns>
		protected int getOffsetForHand(Hand hand) {
			return (hand == Hand.Left) ? 0 : 18;
		}


		/// <summary>
		/// Bone lengths of human 3D model. The value itself is not significant; 
		/// more important are rates between them.
		/// </summary>
		protected double[] w = {
			0.6, 0.5, 0.4, // shoulder, elbow, wrist
			0.3, 0.2, 0.1, // 1. finger
			0.3, 0.2, 0.1, // 2. finger
			0.3, 0.2, 0.1, // 3. finger
			0.3, 0.2, 0.1, // 4. finger
			0.3, 0.2, 0.1  // 5. finger
		};


		/// <summary>
		/// Similarity based on Paice model.
		/// </summary>
		/// <param name="d">List of criterion values.</param>
		/// <param name="p">Weight of the worst criterion.</param>
		/// <returns></returns>
		protected double Paice(double[] d, double p) {
			// Sort the list upwards
			List<double> x = new List<double>(d);
			x.Sort();
			double sum = 0.0;
			double pom = p;
			for (int i = x.Count - 1; i >= 0; i--) {
				sum += x[i] * pom;
				pom = pom * p; // next criterion is added with the p-times lower weight
			}

			// modiffication to the Paice model
			return Math.Max(0, 1 - 2 * sum * sum); 
		}

	}




	/// <summary>
	/// Common ancestor for criteria that access skeleton of the sign model.
	/// </summary>
	public abstract class CriterionSimple : Criterion {
		/// <summary>
		/// Skeleton segment on which the criterion will be evaluated.
		/// </summary>
		public int beg, end;

		/// <summary>
		/// attribute telling whether or not to apply method <see cref="applyDiffForCriterionCache"/>.
		/// </summary>
		public int applyDiff;


		public CriterionSimple(bool applyDiff, double weight, int beg, int end)
			: base(weight) {
			this.applyDiff = applyDiff ? 1 : 0;
			this.beg = beg;
			this.end = end;
		}

		/// <summary>
		/// Finds out whether the normal or proximal meassure should be used to evaluate the criterion.
		/// </summary>
		/// <param name="criterionId">criterion id in which we are interested</param>
		/// <returns>Returns value -1 if this criterion does not have id equal to 
		/// <paramref name="criterionId"/>. 
		/// Otherwise, if normal meassure should be used the method returns value 0; 
		/// if proximal meassure should be used the method returns value 1.
		/// </returns>
		public override int getApplyDiff(int criterionId) {
			if (id != criterionId)
				return -1;
			else
				return applyDiff;
		}
	}


	/// <summary>
	/// Criterion evaluating distance of endpoints of the skeleton segment. 
	/// Beginings of the segments have the same position.
	/// </summary>
	public class CriterionDistance : CriterionSimple {

		public CriterionDistance(bool applyDiff, double weight, int beg, int end)
			: base(applyDiff, weight, beg, end) { }

		override public double eval(Dictionary<int, Data> sign1, Dictionary<int, Data> sign2, bool diffed) {
			// distance of the endpoints of the skeleton segment while the beginings are colocated
			Matrix dv = sign1[id].v.sub(sign2[id].v);
			double sw = sign1[id].val;	// total length of the bones in the skeleton segment

			// the largest possible distance is 2*sw, i.e. the bones are in the line and the 
			// line segments endpoints are heading in opposite directions. The distance is 
			// normalized to the interval [0,1]
			double result;
			if(diffed)
				result = Math.Pow(dv.euclideanNorm(), POWER) / Math.Pow(2 * sw, POWER);
			else
				result = dv.euclideanNorm() / (2 * sw);
			return normalize(result);
		}


		override public void preeval(Dictionary<int, Data> results, SignForSimilarity sign, 
			int rotationsIndex, Hand hand) {
			int offset = getOffsetForHand(hand);
			// distance of the endpoints of the skeleton segment while the beginings are colocated
			Matrix dv = new Vector3D(0, 0, 0);
			Matrix k1 = new Vector3D(0, 1, 0);
			double sw = 0.0;	// total length of the bones in the skeleton segment
			Joint.Rotation[] rots = sign.rotations.Values[rotationsIndex];

			for (int j = end; j >= beg; j--) {
				// Rotate skeleton after j-th joint
				k1 = k1.rotate(new Vector3D(rots[j + offset]), rots[j + offset].angle);
				dv = dv.add(w[j], k1);
				sw = sw + w[j];
			}
			results.Add(id, new Data(new Vector3D(dv.get(0, 0), dv.get(1, 0), dv.get(2, 0)), sw));
		}
	}



	/// <summary>
	/// Criterion evaluating angle between the vectors in the endpoints of the skeleton
	/// </summary>
	public class CriterionAngle : CriterionSimple {
		/// <summary>
		/// The diversion of this vector in two model states will be evaluated
		/// </summary>
		Vector3D v;

		public CriterionAngle(bool applyDiff, double weight, int beg, int end, Vector3D v)
			: base(applyDiff, weight, beg, end) {
			this.v = v;
		}

		override public double eval(Dictionary<int, Data> sign1, Dictionary<int, Data> sign2, bool diffed) {
			// Similarity of the directions of two vectors
			Matrix k1 = sign1[id].v;
			Matrix k2 = sign2[id].v;

			// k1 and k2 are  the unit vectors so their dotProduct is is in interval [-1,1].
			// We will transform it into interval [0,1].
			double result;
			if (diffed)
				result = Math.Pow(Math.Acos(normalizeOO(Matrix.dotProduct(k1, k2) 
					/ k1.euclideanNorm() / k2.euclideanNorm())) / Math.PI, POWER);
			else
				result = (1-normalizeOO(Matrix.dotProduct(k1, k2))) / 2;
			return normalize(result);
		}

		override public void preeval(Dictionary<int, Data> results, SignForSimilarity sign, 
			int rotationsIndex, Hand hand) {
			int offset = getOffsetForHand(hand);

            // Similarity of the directions of two vectors
			Joint.Rotation[] rots = sign.rotations.Values[rotationsIndex];
			Matrix k1 = v;
			for (int j = end; j >= beg; j--) {
                // Rotate skeleton after j-th joint
                k1 = k1.rotate(new Vector3D(rots[j + offset]), rots[j + offset].angle);
			}

			results.Add(id, new Data(new Vector3D(k1.get(0, 0), k1.get(1, 0), k1.get(2, 0)), 0));
		}
	}


	/// <summary>
	/// Criterion evaluating mutual hands arrangement similarity
    /// 
    /// Similarity of two Hands arrangement vectors
	/// </summary>
	public class CriterionHandsAngle : CriterionSimple {
		public CriterionHandsAngle(bool applyDiff, double weight, int beg, int end)
			: base(applyDiff, weight, beg, end) { }

		override public double eval(Dictionary<int, Data> sign1, Dictionary<int, Data> sign2, bool diffed) {

            // Similarity of the direction of two vectors
            Matrix k1 = sign1[id].v;
			Matrix k2 = sign2[id].v;

            // k1 and k2 are  the unit vectors so their dotProduct is is in interval [-1,1].
            // We will transform it into interval [0,1].
            double result;
			if (diffed)
				result = Math.Pow(Math.Acos(normalizeOO(Matrix.dotProduct(k1, k2) 
					/ k1.euclideanNorm() / k2.euclideanNorm())) / Math.PI, POWER);
			else
				result = (1-normalizeOO(Matrix.dotProduct(k1, k2))) / 2;
			return normalize(result);
		}

		override public void preeval(Dictionary<int, Data> results, SignForSimilarity sign, 
			int rotationsIndex, Hand hand) {
			int offsetL = getOffsetForHand(Hand.Left);
			int offsetR = getOffsetForHand(Hand.Right);

            // distance of the endpoints of the skeleton segment while the beginings are colocated
            Matrix dvL = new Vector3D(0, 0, 0);
			Matrix dvR = new Vector3D(0, 0, 0);
			Matrix kL = new Vector3D(0, 1, 0);
			Matrix kR = new Vector3D(0, 1, 0);
            double sw = 0.0;	// total length of the bones in the skeleton segment
			Joint.Rotation[] rots = sign.rotations.Values[rotationsIndex];

			for (int j = end; j >= beg; j--) {
                // Rotate skeleton after j-th joint
                kL = kL.rotate(new Vector3D(rots[j + offsetL]), rots[j + offsetL].angle);
				kR = kR.rotate(new Vector3D(rots[j + offsetR]), rots[j + offsetR].angle);
				dvL = dvL.add(w[j], kL);
				dvR = dvR.add(w[j], kR);
				sw = sw + w[j];
			}
			
			Matrix res = dvL.sub(dvR);
			res = res.mul(1 / res.euclideanNorm());		// normalize vector
			results.Add(id, new Data(new Vector3D(res.get(0, 0), res.get(1, 0), res.get(2, 0)), 0));
		}
	}



	/// <summary>
	/// This criterion is used to consolidate values from more criteria into one value.
	/// </summary>
	public class CriterionComplex : Criterion {
		public Criterion[] criteria;

		public CriterionComplex(double weight, Criterion[] criteria)
			: base(weight) {
			this.criteria = criteria;
		}

		override public double eval(Dictionary<int, Data> sign1, Dictionary<int, Data> sign2, bool diffed) {
			double[] xHand = new double[criteria.Length];	// values of the associated criteria

			for (int i = 0; i < criteria.Length; i++)
				xHand[i] = criteria[i].getWeight() * criteria[i].eval(sign1, sign2, diffed);
			
			
			double result;
			if(diffed)
				result = normalize(1 - weight * Paice(xHand, 0.9));
			else
				result = normalize(1 - weight * Paice(xHand, 0.5));

			return result;
		}

		override public void preeval(Dictionary<int, Data> results, SignForSimilarity sign, 
			int rotationsIndex, Hand hand) {
			for (int i = 0; i < criteria.Length; i++) {
				criteria[i].preeval(results, sign, rotationsIndex, hand);
			}
		}


		/// <summary>
		/// Finds out whether proximal or normal meassure will be used for criterion 
		/// <paramref name="criterionId"/> evaluation. 
		/// </summary>
		/// <param name="criterionId">Criterion Id.</param>
		/// <returns>Returns -1 if the criterion with id equal to <paramref name="criterionId"/> 
		/// was not found;
		/// Returns 0 if the criterion with id equal to <paramref name="criterionId"/> 
		/// was found and normal meassure should be used;
		/// Returns 1 if the criterion with id equal to <paramref name="criterionId"/> 
		/// was found and proximal meassure should be used.</returns>
		public override int getApplyDiff(int criterionId) {
			int result = -1;
			for (int i = 0; i < criteria.Length; i++) {
				result = criteria[i].getApplyDiff(criterionId);

				if (result != -1) {
					// subtree containing the criterion with specified id was found, return its value
					return result;
				}
			}
			// criterion with specified id was not found, return value -1
			return result;
		}
	}

}