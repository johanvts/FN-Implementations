/*
Copyright 2007 Jan Ulrych

This file is part of 'VSSLTest' [Demo application to show usage of Similarity evaluation algorithm 
for Czech Sign Language]. This is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software Foundation; either 
version 2 of the License, or (at your option) any later version. This program is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. You should have received a copy of the GNU General Public License along with 'VSSLTest'; 
if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, 
MA 02110-1301 USA 
*/


using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Text;
using log4net;

namespace SignSimilarity {

	public class SimilarityImpl {
		private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		private int diffSignId;
		SortedDictionary<int, SignForSimilarity> signCache = new SortedDictionary<int, SignForSimilarity>();


		public SimilarityImpl(int diffSignId) {
			this.diffSignId = diffSignId;
		}


		private void fillSignCache() {
			// load all the test signs into cache
			ArrayList al = DataInput.getSignsFromFile("signs.txt");
			log.InfoFormat("generating 3D models for signs ...");

			foreach (Hashtable ht in al) {
				int idSign = (int)ht["id"];

				try {
					SignForSimilarity sign = new SignForSimilarity(idSign, (string)ht["jmeno"], (string)ht["form_notace"]);
					sign.generate3DModel();
					SignForSimilarity.signCache.Add(idSign, sign.signKriterias);
					signCache.Add(idSign, sign);
				} catch (Exception e) {
					log.WarnFormat("generating sign #{0} failed.\nReason: {1}", idSign, e.Message);
				}
			}
			if(!SignForSimilarity.prepareDiffedCriterias(diffSignId))
				throw new Exception("diffSign could not be set to sign with id " + diffSignId);

		}


		private int rebuildSign(int idSign) {
			// Pokud se novy znak nepodarilo nacist (v db neexistuje),
			// nebo se pro nej nepodarilo vytvorit 3D model, koncim 
			SortedList<int, List<Dictionary<int, Criterion.Data>>> idSignCache;
			try {
				idSignCache = SignForSimilarity.signCache[idSign];
			} catch (KeyNotFoundException) {
				log.DebugFormat("Sign {0} not found in the cache", idSign);
				return 0;
			}

			SortedDictionary<int, double> sim = new SortedDictionary<int, double>();

			// loop through all signs and evaluate theirs similarities
			ArrayList args = new ArrayList(8);
			foreach (KeyValuePair<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>> de in SignForSimilarity.signCache) {
				int secondSignId = de.Key;
				if (secondSignId > idSign)
					continue;		// similarity is symetric

				try {
					log.InfoFormat("Signs {0} ({1}), {2} ({3}):", idSign, signCache[idSign].Name, secondSignId, signCache[secondSignId].Name);
					double similarity = SignForSimilarity.getSimilarity(idSignCache, de.Value);

					// save result into temporary array
					sims[idSign, secondSignId] = similarity;
					sims[secondSignId, idSign] = similarity;
				} catch (Exception e) {
					log.WarnFormat("Evaluating similarity for signs #{0} and #{1} failed.\nReason: {2}", idSign, secondSignId, e.Message);
				}
			}

			return 1;
		}

		public double[,] rebuild() {
			log.InfoFormat("evaluating signs similarities started");
			log.InfoFormat("  preparing signCache");
			fillSignCache();
			log.InfoFormat("  evaluating signs similarities");

			// fill array of pair of signs
			createSims();
			foreach (KeyValuePair<int, SignForSimilarity> de in signCache) {
				int idSign = de.Key;
				log.InfoFormat("  evaluating similarities for sign #{0}", idSign);
				rebuildSign(idSign);
			}
			SignForSimilarity.signCache.Clear();
			log.InfoFormat("evaluating signs similarities finished.");
			return sims;
		}

		public string getSignType(int signId) {
			return signCache[signId].getSignType();
		}

		public string getSignName(int signId) {
			return signCache[signId].Name;
		}

		private double[,] sims;
		protected void createSims() {
			int maxid = 0;
			foreach (int id in signCache.Keys)
				if (id > maxid) maxid = id;
			sims = new double[maxid + 1, maxid + 1];

			for (int i = 0; i < maxid + 1; i++) {
				for (int j = 0; j < maxid + 1; j++)
					sims[i, j] = -1;
			}
		}

	}
}