/*
Copyright 2007 Jan Ulrych

This file is part of 'VSSLTest' [Demo application to show usage of Similarity evaluation algorithm 
for Czech Sign Language]. This is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software Foundation; either 
version 2 of the License, or (at your option) any later version. This program is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. You should have received a copy of the GNU General Public License along with 'VSSLTest'; 
if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, 
MA 02110-1301 USA 
*/

using System;
using System.Collections;
using System.Text;
using System.IO;

namespace SignSimilarity {
	/// <summary>
	/// Helper class used to load testing data from file on the disk. This class is here only for testing purposes.
	/// 
	/// Data file syntax:
	/// First line contains tabular-delimited column names: sign_id, sign_name, notation, note;
	/// second line contains tabular-delimited names column types (supported "int" and "string"): int, string, string, string;
	/// rest of file contains data. 
	/// 
	/// Sample file:
	/// id	jmeno	form_notace	poznamka
	/// int	string	string	string
	/// 1	PES	AXAj0Bca000000zn0pln000000000X[TAj0,e]$(@p9$X[TBeu,e]$)00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	Notace odvozena z videa.
	/// 2	K��	AXAb0Daa000000zldln0000000000X[TAb0,e]$(@p9$X[TAj0,e]$)Ppd0$000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	Notace je odvozena z videa.
	/// ...
	/// </summary>
	public class DataInput {
		/// <summary>
		/// Loads data from the file.
		/// </summary>
		/// <param name="filename">File name including path.</param>
		/// <returns>List of Hashtables. Each hashtable represents one sign. Key is the column name, valu is the column value.</returns>
		public static ArrayList getSignsFromFile(string filename) {
			using (StreamReader sr = File.OpenText(filename)) {
				ArrayList res = new ArrayList();
				char[] delims = { '	' };	// tabulator character
				string[] colNames = sr.ReadLine().Split(delims);
				string[] colTypes = sr.ReadLine().Split(delims);
				String input;
				while ((input = sr.ReadLine()) != null) {
					Hashtable ht = new Hashtable();
					string[] data = input.Split(delims);
					int i = 0;
					foreach (string str in data) {
						if (colTypes[i].Equals("string"))
							ht.Add(colNames[i], str);
						else if (colTypes[i].Equals("int"))
							ht.Add(colNames[i], int.Parse(str));

						i++;
					}
					res.Add(ht);
				}
				sr.Close();
				return res;
			}
		}
	}
}