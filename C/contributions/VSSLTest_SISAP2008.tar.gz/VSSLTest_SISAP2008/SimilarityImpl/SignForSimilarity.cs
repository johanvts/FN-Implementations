/*
Copyright 2007 Jan Ulrych

This file is part of 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk�
znakov� jazyk s v�ukov�mi prvky' [Computer dictionary Czech Sign Language - Czech and Czech Czech
Sign Language with instructional features]. This is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later version. This program
is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details. You should have received a copy of the GNU General Public License
along with 'Po��ta�ov� slovn�k �esk� znakov� jazyk - �esk� jazyk a �esk� jazyk - �esk� znakov�
jazyk s v�ukov�mi prvky'; if not, write to the Free Software Foundation, Inc., 51 Franklin St,
Fifth Floor, Boston, MA 02110-1301 USA 
*/


using System;
using System.Collections.Generic;
using System.Text;
using log4net;


namespace SignSimilarity {

	public enum Hand {
		Left,
		Right
	};

	/// <summary>
	/// Class storing one sign of the sign language. This class is designed to store the sign only 
	/// for purposes of the sign similarity evaluation.
    /// 
    /// Contains all the methods neccessary to evaluate similaritz of two sign models (except from 
    /// Criteria that are implemented in Criterio.cs).
	/// </summary>
	public class SignForSimilarity {
		private static readonly ILog log = LogManager.GetLogger(
			System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		/// <summary>
		/// Sign id in the database
		/// </summary>
		private int id;
		public int Id {
			get { return id; }
			protected set { id = value; }
		}

		/// <summary>
		/// Sign name
		/// </summary>
		private string name;
		public string Name {
			get { return name; }
			protected set { name = value; }
		}

		/// <summary>
		/// Sign notation
		/// </summary>
		string form_notation;
		Notation notation;

		/// <summary>
		/// Generated 3D model of the sign.
		/// </summary>
		public GenResult model;


		/// <summary>
		/// Interpolated 3D model of the sign.
		/// 
		/// [time, {hand, joint number, rotation number}]
		/// </summary>
		public SortedList<int, Joint.Rotation[]> rotations;

		/// <summary>
		/// Criterion statuses for this sign
		///                time, hand,         criterion id,data
		/// </summary>
		public SortedList<int, List<Dictionary<int, Criterion.Data>>> signKriterias = null;


		/// <summary>
		/// Main criterion; used to evaluate similarity of two signs.
		/// </summary>
		static CriterionComplex criteriaMain;


		/// <summary>
		/// Criterion status cache
		///                    [sign id,        [time,[hand,        [criterion id,data]]]]
		/// </summary>
		public static Dictionary<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>> signCache = 
			new Dictionary<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>>();

		public SignForSimilarity(int id, string name, string notation) {
			this.id = id;
			this.name = name;
			this.form_notation = notation;
		}

		/// <summary>
		/// Initializes criteria that will be used to evaluate similarity of signs statuses
		/// </summary>
		static SignForSimilarity() {
			Criterion[] criteriaHand = {
				// little-finger-tips distance; wrists are co-located and co-oriented
				new CriterionDistance(true, 1, 3, 5),
				// ring-finger-tips distance; wrists have the same position and orientation
				new CriterionDistance(true, 1, 6, 8),
				// middle-finger-tips distance; wrists have the same position and orientation
				new CriterionDistance(true, 1, 9, 11),
				// index-finger-tips distance; wrists have the same position and orientation
				new CriterionDistance(true, 1, 12, 14),
				// thumb-tips distance; wrists have the same position and orientation
				new CriterionDistance(true, 1, 15, 17)
			};

			List<Criterion> ks = new List<Criterion>(4);
			// wrists distance; shoulders are co-located
			ks.Add(new CriterionDistance(true, 3, 0, 1));
			// wrists arrangement
			ks.Add(new CriterionHandsAngle(true, 1, 0, 1));
			// metacarpus orientation
			ks.Add(new CriterionAngle(true, 1, 0, 2, new Vector3D(0, 1, 0)));
			// palm orientation
			ks.Add(new CriterionAngle(true, 1, 0, 2, new Vector3D(0, 0, 1)));
			// hand shape similarity
			ks.Add(new CriterionComplex(1, criteriaHand));
			// final similarity value
			criteriaMain = new CriterionComplex(1, ks.ToArray());
		}

		/// <summary>
		/// Returns sign type.
        /// 
        /// This characteristic is not used in the similarity evaluation.
		/// </summary>
		/// <returns><c>"AX"</c> for one-handed sign, <c>"B1"</c> for two-handed sign with both 
		/// hands active and <c>"B2"</c> for two-handedsign with only one hand active.</returns>
		public string getSignType() {
			return form_notation.Substring(0, 2);
		}


		/// <summary>
		/// Transforms sign from notation into 3D model represented by joint rotations. 
		/// This model is saved in attribute <paramref name="model"/>. Moreover, performs 
		/// interpolation of sign model acording to the time instants in the list of 
		/// rotations in <paramref name="model"/>.
		/// 
		/// If an error occurs, the exception is thrown and attribute <paramref name="model"/> 
		/// is set to <c>null</c>.
		/// </summary>
		public void generate3DModel() {
			notation = new Notation(form_notation);
			GenResult res = Gen_main.generateModel(notation, false, true);

			// are there any error messages?
			StringBuilder lmessage = new StringBuilder();
			if (res.messagesToUser.Count > 0) {
				foreach (string lstring in res.messagesToUser)
					lmessage.Append(lstring + "\n");
			}
			// animation could not be created
			if (res.moveTime < 0) {
				throw new GenException.ComputingException(lmessage.ToString() + ";\nmoveTime < 0");
			}
			model = res;


			rotations = new SortedList<int, Joint.Rotation[]>();
			fillRotationsList(Hand.Left, model.leftHand);
			fillRotationsList(Hand.Right, model.rightHand);
			finalizeRotationsList();
			return;
		}


		/// <summary>
		/// Multiplicative factor for transformation of the time instants in 
		/// <code>Joint.interpolatorKey</code> from <c>double</c> to <c>int</c>.
		/// </summary>
		private const int rotationsTimeMult = 1000000;


		/// <summary>
		/// Transforms generated 3D model into convenient data structure.
		/// </summary>
		/// <param name="handType">Which hand will be processed</param>
		/// <param name="hand">List of Joints with its rotations from 
		/// <see cref="Notation.GenResult"/> method.</param>
		/// <returns></returns>
		private void fillRotationsList(Hand handType, Joint[] hand) {

			int offset = (handType == Hand.Left) ? 0 : 18;

			if (!rotations.ContainsKey(-1)) {
				//initial position, will be left as is.
				rotations.Add(-2, new Joint.Rotation[36]);
				//initial position, will be adjusted against another sign model
				rotations.Add(-1, new Joint.Rotation[36]);
			}

			for (int i = 0; i < hand.Length; i++) {
				rotations.Values[0][i + offset] = hand[i].vrmlRotation;	//-2
				rotations.Values[1][i + offset] = new Joint.Rotation();
				rotations.Values[1][i + offset].copyRotation(hand[i].vrmlRotation);	//-1

				for (int j = 0; j < hand[i].interpolatorFinalMoveRotations.Count; j++) {
					int time = (int)(((double)hand[i].interpolatorKey[j]) * rotationsTimeMult);
					int idxx = rotations.IndexOfKey(time);
					Joint.Rotation[] state;
					if (idxx == -1) {
						state = new Joint.Rotation[36];
						rotations.Add(time, state);
					} else {
						state = rotations.Values[idxx];
					}
					state[i + offset] = (Joint.Rotation)hand[i].interpolatorFinalMoveRotations[j];
				}
			}
		}

		/// <summary>
		/// Performs linear interpolation of the joint's rotations for time instants for 
		/// which there is not defined rotation of the joint. 
		/// 
		/// Performs evaluation of the criterion statuses (calls method 
		/// <see cref="criteriaMain.preeval"/>) for this sign and saves the results 
		/// into attribute <see cref="signCache"/> <see cref="Id"/> of this sign.
		/// </summary>
		private void finalizeRotationsList() {
			for (int i = 0; i < rotations.Values[0].Length; i++) {
				// defined rotation - interpolation starts here
				int knownStart = 0;
				// defined rotation - interpolation ends here. There is no defined 
				// rotation between these two indeces => they will be interpolated.
				int knownEnd = 1;

				while (knownEnd < rotations.Count) {
					while (knownEnd < rotations.Count && rotations.Values[knownEnd][i] == null)
						knownEnd++;

					// if the last rotation contains null value
					if (knownEnd >= rotations.Count) {
						for (int j = knownStart + 1; j < rotations.Count; j++)
							rotations.Values[j][i] = rotations.Values[knownStart][i];
						break;	// there are no more rotations
					}

					// there are no defined rotations between knownStart and knownEnd. They will be interpolated.
					Joint.Rotation diff = Joint.Rotation.subRotations(
						rotations.Values[knownStart][i], rotations.Values[knownEnd][i]);

					double angleOff = diff.angle / (rotations.Keys[knownEnd] - rotations.Keys[knownStart]);
					for (int j = knownStart + 1; j < knownEnd; j++) {
						diff.angle = angleOff * (rotations.Keys[j] - rotations.Keys[knownStart]);
						rotations.Values[j][i] = 
							Joint.Rotation.composeRotation(diff, rotations.Values[knownStart][i], 1);
					}

					// interpolation is done, continue with next time instant
					knownStart = knownEnd;
					knownEnd = knownStart + 1;

				}
			}

			// Evaluate criterion statuses for the sign and save them into cache.
			signKriterias = new SortedList<int, List<Dictionary<int, Criterion.Data>>>();
			for (int i = 0; i < rotations.Count; i++) {
				List<Dictionary<int, Criterion.Data>> criterionCache = new List<Dictionary<int, Criterion.Data>>();
				
				// left hand
				Dictionary<int, Criterion.Data> lH = new Dictionary<int, Criterion.Data>();
				criteriaMain.preeval(lH, this, i, Hand.Left);
				criterionCache.Add(lH);
				
				// right hand
				Dictionary<int, Criterion.Data> rH = new Dictionary<int, Criterion.Data>();
				criteriaMain.preeval(rH, this, i, Hand.Right);
				criterionCache.Add(rH);

				signKriterias.Add(rotations.Keys[i], criterionCache);
			}
		}


		/// <summary>
		/// Performs adjustment of sign models to have the same initial position as 
		/// the model with id <paramref name="diffSignId"/>.
		/// </summary>
		/// <param name="diffSignId">Id of the sign model, that will be used as common 
		/// universal model for evaluating differences.</param>
		/// <returns>Returns <code>true</code> if method completed successfuly, 
		/// <code>false</code> otherwise</returns>
		public static bool prepareDiffedCriterias(int diffSignId) {
			// find common sign
			if (signCache == null || !signCache.ContainsKey(diffSignId))
				return false;
			List<Dictionary<int, Criterion.Data>> signD = signCache[diffSignId].Values[0];

			// looping through all signs  ...
			Dictionary<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>> nSignCache = 
				new Dictionary<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>>();
			foreach (KeyValuePair<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>> signKriterias 
				in signCache) {
				// ... through all time instants
				SortedList<int, List<Dictionary<int, Criterion.Data>>> nSignKriteriasForTime = 
					new SortedList<int, List<Dictionary<int, Criterion.Data>>>();
				nSignCache.Add(signKriterias.Key, nSignKriteriasForTime);
				List<Dictionary<int, Criterion.Data>> diff = 
					getDiffForCriterionCache2(signD, signKriterias.Value.Values[0]);
				foreach (KeyValuePair<int, List<Dictionary<int, Criterion.Data>>> signKriteriasForTime 
					in signKriterias.Value) {
					if (signKriteriasForTime.Key == -2) {
						nSignKriteriasForTime.Add(signKriteriasForTime.Key, signKriteriasForTime.Value);
					} else {
						// create adjusted models
						List<Dictionary<int, Criterion.Data>> res = 
							applyDiffForCriterionCache(signKriteriasForTime.Value, diff);
						nSignKriteriasForTime.Add(signKriteriasForTime.Key, res);
					}
				}
			}
			signCache = nSignCache;
			return true;
		}



		/// <summary>
		/// Evaluates similarity of two signs.
		/// </summary>
		/// <param name="sign1">Result of the method <see cref="preeval"/> performed on the instance 
		///    of the <see cref="SignForSimilarity"/> class that represents first sign.</param>
		/// <param name="sign2">Result of the method <see cref="preeval"/> performed on the instance 
		///    of the <see cref="SignForSimilarity"/> class that represents second sign.</param>
		/// <returns>Similarity of two signs. 0 = dissimilar signs, 1 = most similar signs.</returns>
		public static double getSimilarity(SortedList<int, List<Dictionary<int, Criterion.Data>>> sign1,
										   SortedList<int, List<Dictionary<int, Criterion.Data>>> sign2) {

			// ensure that model sign1 has at least the same number of the states as model sign2
			if (sign1.Keys.Count > sign2.Keys.Count) {
				SortedList<int, List<Dictionary<int, Criterion.Data>>> signx = sign1;
				sign1 = sign2;
				sign2 = signx;
			}

			// Implementation of the method of dynamic programming - 
			// - maximizing average similarity of pairing between models sign1 and sign2

			// prepare matrix of auxiliary similarity values
			int s1 = sign1.Keys.Count;
			int s2 = sign2.Keys.Count;
			double[,] m = new double[2, s2];	// similarity

			// fill-in the first line
			for (int j = 1; j < s2; j++) {
				m[1, j] = ZnakSim(sign1.Values[1], sign2.Values[j], true, true);
			}

			// fill-in the rest of the matrix
			int best_i, best_j;
			for (int i = 2; i < s1; i++) {
				for (int j = i; j < s2; j++) {
					double s_ij = ZnakSim(sign1.Values[i], sign2.Values[j], true, true);

					if (i == j || (s_ij + m[(i - 1) % 2, j - 1]) > m[i % 2, j - 1]) {
						best_i = i - 1;
						best_j = j - 1;
						m[i % 2, j] = m[(i - 1) % 2, j - 1] + s_ij;
					} else {
						best_i = i;
						best_j = j - 1;
						m[i % 2, j] = m[i % 2, j - 1];
					}
				}
			}

			// find optimal value x for x \in [m.GetLength(0)-1; m.GetLength(1)-1]
			int edgesFinal = s1 - 1;//the first value is initial state which we do not use
			double maxijFinal = 0;
			best_i = s1 - 1;
			best_j = s2 - 1;
			for (int j = s1 - 1; j < s2; j++) {
				if (m[(s1 - 1) % 2, j] > maxijFinal) {
					maxijFinal = m[(s1 - 1) % 2, j];
					best_j = j;
				}
			}

			double penalization;
			double sdiff = s2 - s1;
			const double cnt = 100;
			const int maxPenalty = 10;
			if (sdiff > cnt)
				penalization = maxPenalty;
			else
				penalization = 1 + 9 * Math.Pow(Math.Abs(sdiff) / ((double)(s2 + s1 - 2)), 3);

			// arithmetic average of similarity of the motion
			double resMove = maxijFinal / edgesFinal / penalization;

			// similarity of the initial positions
			double resStatic = ZnakSim(sign1.Values[0], sign2.Values[0], false, false);

			// final value of the similarity of sign1 and sign2
			return .75 * Math.Min(resMove, resStatic) + .25 * Math.Max(resMove, resStatic);
		}


		/// <summary>
		/// Returns difference between <paramref name="criterionCache1"/> and the 
		/// <paramref name="criterionCache2"/>. 
		/// 
		/// If this difference is added to the <paramref name="criterionCache2"/> we obtain
		/// <paramref name="criterionCache1"/>.
		/// </summary>
		/// <param name="criterionCache1">Criterion statuses for the first sign</param>
		/// <param name="criterionCache2">Criterion statuses for the second sign</param>
		/// <returns>Returns data in the same form as the parameters have.</returns>
		private static List<Dictionary<int, Criterion.Data>> getDiffForCriterionCache2(
			List<Dictionary<int, Criterion.Data>> criterionCache1,
			List<Dictionary<int, Criterion.Data>> criterionCache2) {

			List<Dictionary<int, Criterion.Data>> kC2Diff = new List<Dictionary<int, Criterion.Data>>();
			for (int i = 0; i < criterionCache1.Count; i++) {
				Dictionary<int, Criterion.Data> krits = new Dictionary<int, Criterion.Data>();
				kC2Diff.Add(krits);
				foreach (KeyValuePair<int, Criterion.Data> kv in criterionCache1[i]) {
					Criterion.Data kv2 = criterionCache2[i][kv.Key];
					Vector3D diffV = kv.Value.v.sub(kv2.v);
					double diffVal = kv.Value.val - kv2.val;
					krits.Add(kv.Key, new Criterion.Data(diffV, diffVal));
				}
			}
			return kC2Diff;
		}


		/// <summary>
		/// Adds <paramref name="diff"/> to the <paramref name="criterionCache"/>.
		/// </summary>
		/// <param name="criterionCache">Criterion statuses for the left and right hand 
		///     to which the <paramref name="diff"/> will be added</param>
		/// <param name="diff">Difference (usualy initial positions of the sign model) 
		///     that will be added. It is a return value of the method 
		///     <see cref="getDiffForCriterionCache2"/></param>
		/// <returns>Returns data in the same form as the parameters have.</returns>
		private static List<Dictionary<int, Criterion.Data>> applyDiffForCriterionCache(
			List<Dictionary<int, Criterion.Data>> criterionCache,
			List<Dictionary<int, Criterion.Data>> diff) {

			List<Dictionary<int, Criterion.Data>> kCDiffed = new List<Dictionary<int, Criterion.Data>>();
			for (int i = 0; i < criterionCache.Count; i++) {
				Dictionary<int, Criterion.Data> krits = new Dictionary<int, Criterion.Data>();
				Dictionary<int, Criterion.Data> diffi = diff[i];
				kCDiffed.Add(krits);
				foreach (KeyValuePair<int, Criterion.Data> kv in criterionCache[i]) {
					int kvKey = kv.Key;
					Criterion.Data kvValue = kv.Value;
					Criterion.Data kv2 = diffi[kvKey];
					Vector3D newV = kvValue.v.add(kv2.v);
					double newVal = kvValue.val + kv2.val;
					krits.Add(kvKey, new Criterion.Data(newV, newVal));
				}
			}
			return kCDiffed;
		}




		/// <summary>
		/// Similarity of two model states.
		/// </summary>
		/// <param name="criterionCache1">Criteria statuses for the left and right 
		/// hand for the first sign model</param>
		/// <param name="criterionCache2">Criteria statuses for the left and right 
		/// hand for the second sign model</param>
		/// <param name="diffedL">If <code>true</code> then the normal meassure will 
		/// be used for similarity evaluation; if <code>false</code> then proximal 
		/// meassure will be used for left hand similarity evaluation.</param>
		/// <param name="diffedR">If <code>true</code> then the normal meassure will 
		/// be used for similarity evaluation; if <code>false</code> then proximal 
		/// meassure will be used for right hand similarity evaluation.</param>
		/// <returns>1 = similar model states, 0 = dissimilar model states</returns>
		static double ZnakSim(List<Dictionary<int, Criterion.Data>> criterionCache1,
							  List<Dictionary<int, Criterion.Data>> criterionCache2,
							  bool diffedL, bool diffedR) {

			double zsLeftHand = 1 - criteriaMain.eval(criterionCache1[0], criterionCache2[0], diffedL);
			double zsRightHand = 1 - criteriaMain.eval(criterionCache1[1], criterionCache2[1], diffedR);

			//combine similarities for the left and right hand into one number using AND from MinMax model
			return 0.75 * Math.Min(zsLeftHand, zsRightHand) + 0.25 * Math.Max(zsLeftHand, zsRightHand);
		}

	}

}