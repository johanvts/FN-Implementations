/*
Copyright 2007 Jan Ulrych

This file is part of 'VSSLTest' [Demo application to show usage of Similarity evaluation algorithm 
for Czech Sign Language]. This is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software Foundation; either 
version 2 of the License, or (at your option) any later version. This program is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. You should have received a copy of the GNU General Public License along with 'VSSLTest'; 
if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, 
MA 02110-1301 USA 
*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.IO;
using SignSimilarity;

namespace Similarity {

	/// <summary>
	/// Helper class used for analysis and output of the results.
	/// </summary>
	class AnalyzeOutput {

		/// <summary>
		/// Defines the order in which the signs will be send to output.
		/// </summary>
		private static List<int> order;


		/// <summary>
		/// Stores the number of wrongly classified signs for each sign.
		/// </summary>
		private static int[] res;


		/// <summary>
		/// List of minimal pairs, which is used to format output.
		/// </summary>
		private static Dictionary<int, MinP> mps = new Dictionary<int, MinP>();




		/// <summary>
		/// Loads list of minimal pairs from the file. The list of minimal pairs is saved into 
		/// <code>mps</code> attribute of this class.
		/// 
		/// Every line of the file contains one minimal pair in form:
		/// 
		///    sign_id	sign1_id,sign2_id,...
		/// 
		/// where the first sign_id is the sign for which the minimal pair is being defined,
		/// followed by the tabulator character and comma delimited list of sign_id�, that 
		/// form a minimal pair with the sign_id.
		/// 
		/// The ordering of lines in file defines contents of <code>order</code> attribute.
		/// </summary>
		/// <param name="filename">File name including full path.</param>
		public static void getMinPairsFromFile(string filename) {
			order = new List<int>();
			using (StreamReader sr = File.OpenText(filename)) {
				char[] mpDelim = { '	', ',' };	// Delimiter of sign and minimal pair; tabulator character
				String input;
				while ((input = sr.ReadLine()) != null) {
					input = input.Trim();
					if (input == "")
						continue;

					string[] data = input.Split(mpDelim);
					int[] dataI = new int[data.Length];
					for (int i = 0; i < data.Length; i++)
						dataI[i] = int.Parse(data[i]);
					MinP mp = new MinP(dataI);
					order.Add(dataI[0]);
					mps.Add(dataI[0], mp);
				}
				sr.Close();
			}
		}


		/// <summary>
		/// Initializes array of output values
		/// </summary>
		/// <param name="sims"></param>
		private static void prepareRes(double[,] sims) {
			res = new int[sims.GetLength(0)];
			for (int i = 0; i < res.Length; i++)
				res[i] = 0;
		}





		/// <summary>
		/// Prints results of evaluation similarity of signs as a table as LaTeX input file.
		/// </summary>
		/// <param name="filename">Name of the output filename</param>
		/// <param name="sim">Class with cache of signs - contains sign names</param>
		/// <param name="sims">Similarity evaluation results</param>
		public static void analyzeAndWriteSimsLatex(string filename, SimilarityImpl sim, double[,] sims) {
			prepareRes(sims);
			StreamWriter s = new StreamWriter(new FileStream(filename, FileMode.Create), Encoding.Default);

			// LaTeX table heading
			s.WriteLine("\\begin{table}");
			s.Write("\\begin{tabular}{|l|");
			for (int i = 0; i < order.Count - 1; i++)
				s.Write("cG");
			s.Write("c");
			s.WriteLine("|}\\hline");

			// table headings
			for (int i = 0; i < order.Count; i++)
				s.Write("&\\begin{{sideways}}\\testSign{{{0}}}\\hbox to .5ex{{}}\\end{{sideways}}",
					sim.getSignName(order[i]));
			s.WriteLine("\\\\");
			s.WriteLine("\\hline");

			// table data - similarities of pairs of signs
			for (int i = 0; i < order.Count; i++) {
				s.Write("{1} \\testSign{{{0}}}", sim.getSignName(order[i]), order[i]);
				for (int j = 0; j < order.Count; j++) {
					MinP x;
					try {
						x = mps[order[j]];
					} catch (KeyNotFoundException) {
						continue;
					}

					if (sims[order[i], order[j]] == -1)
						continue;

					bool nextSign = false;
					for (int k = 0; k < x.minPar.Length; k++) {
						if (x.minPar[k] == order[i]) {
							nextSign = true;
							s.Write("&\\testMP{{{0}}}", getFormattedNumber(sims[order[i], order[j]]));
							break;
						}
					}
					if (nextSign)
						continue;

					bool isOK = true;
					for (int k = 0; k < x.minPar.Length; k++) {
						if (sims[x.minPar[k], order[j]] <= sims[order[i], order[j]]) {
							isOK = false;
							s.Write("&\\testBad{{{0}}}", getFormattedNumber(sims[order[i], order[j]]));
							break;
						}
					}
					if (isOK)
						s.Write("&\\testOK{{{0}}}", getFormattedNumber(sims[order[i], order[j]]));

					res[order[j]] += isOK ? 0 : 1;
				}
				s.WriteLine("\\\\");
				if (i < order.Count - 1)
					s.WriteLine("\\bhline");
			}

			// final statistic
			s.WriteLine("\\hline");
			int cnt = 0;
			for (int i = 0; i < order.Count; i++)
				cnt += res[order[i]];
			s.Write("\\testOK{{Celkem {0}}}", cnt);
			for (int i = 0; i < order.Count; i++)
				s.Write("&\\testOK{{{0}}}", res[order[i]]);

			s.WriteLine("\\\\");
			s.WriteLine("\\hline");
			s.WriteLine("\\end{tabular}");
			s.WriteLine("\\caption{{{0}}}\\label{{tb:test:{0}}}", filename);
			s.WriteLine("\\end{table}");
			s.Close();
		}







		/// <summary>
		/// Special number formatting.
		/// </summary>
		/// <param name="number"></param>
		/// <returns></returns>
		private static string getFormattedNumber(double number) {
			double one = 1;
			if (number.ToString("0.00").Equals(one.ToString("0.00")))
				return one.ToString("0.0");
			else
				return number.ToString(".00");
		}



















		public static void analyzeAndWriteSims(string filename, SimilarityImpl sim, double[,] sims) {
			prepareRes(sims);
			for (int j = 0; j < order.Count; j++) {
				MinP x;
				try {
					x = mps[order[j]];
				} catch (KeyNotFoundException) {
					continue;
				}

				for (int i = 0; i < order.Count; i++) {
					if (sims[order[i], order[j]] == -1)
						continue;

					bool nextSign = false;
					for (int k = 0; k < x.minPar.Length; k++) {
						if (x.minPar[k] == order[i]) {
							nextSign = true;
							break;
						}
					}
					if (nextSign)
						continue;

					bool isOK = true;
					for (int k = 0; k < x.minPar.Length; k++) {
						if (sims[x.minPar[k], order[j]] <= sims[order[i], order[j]]) {
							isOK = false;
							break;
						}
					}
					res[order[j]] += isOK ? 0 : 1;
				}
			}


			// open file
			StreamWriter s = new StreamWriter(new FileStream(filename, FileMode.Create), Encoding.Default);

			// table header
			s.Write("  ;  ;");
			for (int i = 0; i < order.Count; i++)
				s.Write("{0};", order[i]);
			s.WriteLine("");
			s.Write("  ;  ;");
			for (int i = 0; i < order.Count; i++)
				s.Write("{0} {1};", sim.getSignType(order[i]), sim.getSignName(order[i]));
			s.WriteLine("");

			// table data - similarities of pairs of signs
			for (int i = 0; i < order.Count; i++) {
				s.Write("{0};{1} {2};", order[i], sim.getSignType(order[i]), sim.getSignName(order[i]));
				for (int j = 0; j < order.Count; j++)
					s.Write(sims[order[i], order[j]].ToString() + ";");
				s.WriteLine("");
			}

			// final statistic
			int cnt = 0;
			for (int i = 0; i < order.Count; i++)
				cnt += res[order[i]];
			s.Write("{0};{1};", filename, cnt);
			for (int i = 0; i < order.Count; i++)
				s.Write("{0};", res[order[i]]);
			s.WriteLine("");
			s.Close();
		}
	}


	/// <summary>
	/// Class representing a minimal pair
	/// </summary>
	public class MinP {
		public int[] minPar;
		public MinP(int[] minPar) {
			this.minPar = minPar;
		}
	}
}


