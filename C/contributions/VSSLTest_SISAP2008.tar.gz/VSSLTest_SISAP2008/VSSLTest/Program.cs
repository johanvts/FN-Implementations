/*
Copyright 2007 Jan Ulrych

This file is part of 'VSSLTest' [Demo application to show usage of Similarity evaluation algorithm 
for Czech Sign Language]. This is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software Foundation; either 
version 2 of the License, or (at your option) any later version. This program is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. You should have received a copy of the GNU General Public License along with 'VSSLTest'; 
if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, 
MA 02110-1301 USA 
*/

using System;
using System.IO;
using System.Reflection;
using System.Text;
using log4net;
using System.Collections.Generic;
using System.Globalization;

namespace Similarity {
	/// <summary>
	/// Demo application to demonstrate usage of similarity evaluation algorithm.
	/// </summary>
	class Program {
		private static readonly ILog log = LogManager.GetLogger(
			System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		/// <summary>
		/// Main class of the demo application. Runs the similarity evaluation on whole database.
		/// </summary>
		/// <param name="args">Takes no command line arguments.</param>
		static void Main(string[] args) {
			// get model path
			string exePath = Assembly.GetExecutingAssembly().CodeBase;
			exePath = exePath.Substring(0, exePath.Length - Path.GetFileName(exePath).Length - 1);
			// ... on windows, abolute path starts with c:/, not /c:/
			string xexePath = exePath.Substring("file:///".Length, exePath.Length - "file:///".Length);
			if (!Directory.Exists(xexePath + "/model/"))
				// ... on unix, absolute path starts with /
				xexePath = exePath.Substring("file://".Length, exePath.Length - "file://".Length);
			log.Debug(xexePath);
			Gen_main.initModelFilePaths(xexePath + "/model/vrml/", xexePath + "/model/data/");

			// initialize minimal pairs
			AnalyzeOutput.getMinPairsFromFile("min-pairs.txt");

			// initialize common auxiliary model, here it is the model for the sign with id 66
			int diffSignId = 66;
			SimilarityImpl sim = new SimilarityImpl(diffSignId);
			
			// evaluate similarities of minimal pairs
			double[,] sims = sim.rebuild();

			// output results as LaTeX source
			AnalyzeOutput.analyzeAndWriteSimsLatex("output.tex", sim, sims);

			// output results as collon delimited text file
			//AnalyzeOutput.analyzeAndWriteSims("output.csv", sim, sims);
			return;

		}

	}

}