/*
Copyright 2007 Jan Ulrych

This file is part of 'VSSLTest' [Demo application to show usage of Similarity evaluation algorithm 
for Czech Sign Language]. This is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software Foundation; either 
version 2 of the License, or (at your option) any later version. This program is distributed in 
the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more 
details. You should have received a copy of the GNU General Public License along with 'VSSLTest'; 
if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, 
MA 02110-1301 USA 
*/


using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using SignSimilarity;
using System.Text;
using log4net;

namespace Similarity {

	/// <summary>
	/// This class defines higher functions that use similarity evaluation algorithm.
	/// </summary>
	public class SimilarityImpl {
		private static readonly ILog log = LogManager.GetLogger(
			System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

		private int diffSignId;
		SortedDictionary<int, SignForSimilarity> signCache = new SortedDictionary<int, SignForSimilarity>();


		public SimilarityImpl(int diffSignId) {
			this.diffSignId = diffSignId;
		}

		/// <summary>
		/// Loads testing data from file on the disk. This method is here for testing purposes only.
		/// 
		/// Data file syntax:
		/// First line contains tabular-delimited column names: sign_id, sign_name, notation, note;
		/// second line contains tabular-delimited names column types (supported "int" and "string"): int, string, string, string;
		/// rest of file contains data. 
		/// 
		/// Sample file:
		/// id	jmeno	form_notace	poznamka
		/// int	string	string	string
		/// 66	SPORT	B1BerChaBelChad00pl0d00pr0rz0{Pzl0$Ppr0$}.00000000000000000000000000000000000000000000000{Ppl0$Pzr0$}.000000000000000000000000000000000000000000000000	
		/// 58	V�D�T	AXAcrBdc000000z00ln0000000000{Pz00$X[TAcr,e]$}.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	
		/// ...
		/// </summary>
		/// <param name="filename">File name including path.</param>
		/// <returns>List of Hashtables. Each hashtable represents one sign. 
		/// Key is the column name, valu is the column value.</returns>
		public static ArrayList getSignsFromFile(string filename) {
			using (StreamReader sr = File.OpenText(filename)) {
				ArrayList res = new ArrayList();
				char[] delims = { '	' };	// tabulator character
				string[] colNames = sr.ReadLine().Split(delims);
				string[] colTypes = sr.ReadLine().Split(delims);
				String input;
				while ((input = sr.ReadLine()) != null) {
					Hashtable ht = new Hashtable();
					string[] data = input.Split(delims);
					int i = 0;
					foreach (string str in data) {
						if (colTypes[i].Equals("string"))
							ht.Add(colNames[i], str);
						else if (colTypes[i].Equals("int"))
							ht.Add(colNames[i], int.Parse(str));

						i++;
					}
					res.Add(ht);
				}
				sr.Close();
				return res;
			}
		}

		
		/// <summary>
		/// Loads all the test signs into cache and generates 3D models.
		/// </summary>
		private void fillSignCache() {
			ArrayList al = getSignsFromFile("signs.txt");
			log.InfoFormat("generating 3D models for signs ...");

			foreach (Hashtable ht in al) {
				int idSign = (int)ht["id"];

				try {
					SignForSimilarity sign = new SignForSimilarity(
						idSign, (string)ht["jmeno"], (string)ht["form_notace"]);
					sign.generate3DModel();
					SignForSimilarity.signCache.Add(idSign, sign.signKriterias);
					signCache.Add(idSign, sign);
				} catch (Exception e) {
					log.WarnFormat("generating sign #{0} failed.\nReason: {1}", idSign, e.Message);
				}
			}
			if(!SignForSimilarity.prepareDiffedCriterias(diffSignId))
				throw new Exception("diffSign could not be set to sign with id " + diffSignId);

		}


		/// <summary>
		/// Evaluate similarities with all other signs for the sign with id <code>signId</code>
		/// </summary>
		/// <param name="idSign">Id of the sign that whose similarity to other signs will be evaluated</param>
		/// <returns>1 in case of success; 0 otherwise</returns>
		private int rebuildSign(int idSign) {
			// Pokud se novy znak nepodarilo nacist (v db neexistuje),
			// nebo se pro nej nepodarilo vytvorit 3D model, koncim 
			SortedList<int, List<Dictionary<int, Criterion.Data>>> idSignCache;
			try {
				idSignCache = SignForSimilarity.signCache[idSign];
			} catch (KeyNotFoundException) {
				log.DebugFormat("Sign {0} not found in the cache", idSign);
				return 0;
			}

			SortedDictionary<int, double> sim = new SortedDictionary<int, double>();

			// loop through all signs and evaluate theirs similarities
			ArrayList args = new ArrayList(8);
			foreach (KeyValuePair<int, SortedList<int, List<Dictionary<int, Criterion.Data>>>> de 
				in SignForSimilarity.signCache) {
				int secondSignId = de.Key;

				try {
					log.InfoFormat("Signs {0} ({1}), {2} ({3}):", 
						idSign, signCache[idSign].Name, secondSignId, signCache[secondSignId].Name);
					double similarity = SignForSimilarity.getSimilarity(idSignCache, de.Value);

					// save result into temporary array
					sims[idSign, secondSignId] = similarity;
				} catch (Exception e) {
					log.WarnFormat("Evaluating similarity for signs #{0} and #{1} failed.\nReason: {2}", 
						idSign, secondSignId, e.Message);
				}
			}

			return 1;
		}

		/// <summary>
		/// Evaluates similarity of all pairs of signs in the database.
		/// </summary>
		/// <returns>Array of similarities of pairs of signs. The array is indexed by Ids of the signs.</returns>
		public double[,] rebuild() {
			log.InfoFormat("evaluating signs similarities started");
			log.InfoFormat("  preparing signCache");
			fillSignCache();
			log.InfoFormat("  evaluating signs similarities");

			// fill array of similarities of pairs of signs
			createSims();
			foreach (KeyValuePair<int, SignForSimilarity> de in signCache) {
				int idSign = de.Key;
				log.InfoFormat("  evaluating similarities for sign #{0}", idSign);
				rebuildSign(idSign);
			}
			SignForSimilarity.signCache.Clear();
			log.InfoFormat("evaluating signs similarities finished.");
			return sims;
		}


		/// <summary>
		/// Every sign is assigned a sign type.
		/// 
		/// This feature is not used.
		/// </summary>
		/// <param name="signId">Id of sign for which the sign type will be returned</param>
		/// <returns><see cref="getSignType"/></returns>
		public string getSignType(int signId) {
			return signCache[signId].getSignType();
		}


		/// <summary>
		/// Returns name of the sign
		/// </summary>
		/// <param name="signId">Id of the sign</param>
		/// <returns>String representing name of the sign</returns>
		public string getSignName(int signId) {
			return signCache[signId].Name;
		}


		/// <summary>
		/// Private attribute used to store array of similarities
		/// </summary>
		private double[,] sims;


		/// <summary>
		/// Initializes array <code>sims</code> to square array with the 
		/// dimensions equal to the maximum id of sign in signCache.
		/// </summary>
		protected void createSims() {
			int maxid = 0;
			foreach (int id in signCache.Keys)
				if (id > maxid) maxid = id;
			sims = new double[maxid + 1, maxid + 1];

			for (int i = 0; i < maxid + 1; i++) {
				for (int j = 0; j < maxid + 1; j++)
					sims[i, j] = -1;
			}
		}

	}
}